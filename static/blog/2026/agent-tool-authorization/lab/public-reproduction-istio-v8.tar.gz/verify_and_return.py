"""Record a strict checker child natural exit and drain before returning evidence."""

import argparse
import hashlib
import pathlib
import subprocess
import sys
import time
from public_common import atomic_json, export_binding, package_boundary, read_json, regular_path, require, sha, validate_receipt


def timeout(deadline):
    value = min(180, deadline - time.monotonic())
    require(value > 0, 'original lifecycle deadline before verifier operation')
    return value


def checker_child(argv, deadline):
    allowance = timeout(deadline) - 5
    require(allowance > 0, 'checker requires drain time within original deadline')
    process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        stdout, stderr = process.communicate(timeout=min(allowance, timeout(deadline)))
        require(time.monotonic() < deadline, 'checker drained within original deadline')
        require(process.returncode == 0, 'actual checker child natural exit zero')
        require(max(len(stdout), len(stderr)) <= 1048576, 'unchanged checker output ceiling')
        return dict(actual_exit=process.returncode, natural_exit=process.returncode, drained=True, timed_out=False,
                    stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest())
    except BaseException:
        process.kill()
        process.communicate(timeout=timeout(deadline))
        raise


def return_verified(archive, run_id, destination, receipt_target, package):
    archive, destination, receipt_target = map(regular_path, [archive, destination, receipt_target])
    require(archive.is_file(), 'regular export archive')
    require(not destination.exists() and not receipt_target.exists(), 'fresh verifier destination and receipt')
    request = read_json(receipt_target.parent / ('request-' + run_id + '.json'))
    require(request['archive'] == str(archive) and request['receipt_target'] == str(receipt_target), 'exact emitted exchange request')
    package_boundary(package, request['public_manifest_sha256'])
    sys.path.insert(0,str(package / 'v8/source'))
    require(archive.stat().st_size <= 1024 ** 3, 'unchanged export byte ceiling')
    expected = export_binding(archive, run_id)
    require(expected['archive_sha256'] == request['archive_sha256'], 'actual independently observed archive SHA')
    deadline = min(request['original_deadline'], time.monotonic() + 180)
    timeout(deadline)
    argv = [sys.executable, '-B', str(package / 'v8/source/verify_export.py'), str(archive), str(destination), run_id,
            '--archive-sha256', expected['archive_sha256']]
    closure = checker_child(argv, deadline)
    receipt_path = destination / 'verified-export-receipt.json'
    receipt = read_json(receipt_path)
    validate_receipt(receipt, run_id.removesuffix('-before-teardown'), expected)
    require(sha(archive) == expected['archive_sha256'], 'archive unchanged after actual checker drain')
    closure.update(archive_sha256=expected['archive_sha256'], receipt_sha256=sha(receipt_path),
                   public_manifest_sha256=request['public_manifest_sha256'], checker_sha256=sha(package / 'v8/source/verify_export.py'))
    timeout(deadline)
    print('VERIFIED_CHECKER ' + str(closure), flush=True)
    atomic_json(receipt_target, dict(receipt=receipt, checker=closure))
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', required=True, type=pathlib.Path)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--fresh-destination', required=True, type=pathlib.Path)
    parser.add_argument('--receipt-target', required=True, type=pathlib.Path)
    args = parser.parse_args()
    package = pathlib.Path(__file__).absolute().parent
    return_verified(args.archive, args.run_id, args.fresh_destination, args.receipt_target, package)


if __name__ == '__main__':
    main()
