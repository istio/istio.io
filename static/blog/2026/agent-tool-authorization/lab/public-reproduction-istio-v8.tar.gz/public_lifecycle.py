"""Neutral whole lifecycle around the explicit public V8 derivative. No SSH or implicit grants."""

import argparse
import json
import os
import pathlib
import shutil
import signal
import sys
import time
from public_common import atomic_json, archive_boundary, authorization, check_file, operator, package_boundary
from public_common import read_json, regular_path, require, sha, source_boundary, validate_receipt
from public_budget import enforce_budget, install_enforcement, measure, read_budget
from public_host import capture
from public_supervisor import Bridge, make_monitor

PHASES = [('prepare', 1200), ('setup', 1200), ('runtime-serial', 4560), ('delete', 60)]
LIFECYCLE_SECONDS = 7080


def imported_source(package):
    sys.path.insert(0, str(package / 'v8/source'))
    import resources
    import runtime
    return resources, runtime


def input_gate(config_path, auth_path, exchange, package):
    config_path, auth_path, exchange = map(regular_path, [config_path, auth_path, exchange])
    config = read_json(config_path)
    root = operator(config)
    require(not root.exists() and not exchange.exists(), 'strict fresh staging and exchange paths')
    require(exchange.parent.is_dir(), 'existing exchange parent')
    paths = [package, exchange, root]
    for left in paths:
        for right in paths:
            require(left == right or not left.is_relative_to(right), 'disjoint package/staging/exchange')
    manifest = package_boundary(package, config['public_manifest_sha256'])
    archive = regular_path(config['package_archive'])
    archive_boundary(archive, config['package_archive_sha256'], package, manifest)
    grant = read_json(auth_path)
    authorization(grant, sha(config_path), package)
    budget_path = regular_path(config['budget_file'])
    check_file(budget_path, config['budget_sha256'])
    budget = read_budget(budget_path, config['hostname'])
    return dict(config=config, root=root, grant=grant, budget=budget, config_path=config_path,
                auth_path=auth_path, budget_path=budget_path, exchange=exchange, package=package)


def immutable_inputs(inputs):
    config = inputs['config']
    package_boundary(inputs['package'], config['public_manifest_sha256'])
    require(read_json(inputs['config_path']) == config, 'operator config unchanged across phases')
    require(read_json(inputs['auth_path']) == inputs['grant'], 'launcher grant unchanged across phases')
    check_file(inputs['budget_path'], config['budget_sha256'])
    require(read_budget(inputs['budget_path'], config['hostname']) == inputs['budget'], 'original budget unchanged')


def stage(inputs, monitor):
    root, package, config = inputs['root'], inputs['package'], inputs['config']
    monitor.check()
    immutable_inputs(inputs)
    root.mkdir(mode=0o700)
    source = package / 'v8'
    files = read_json(source / 'SOURCE_MANIFEST.json')['files']
    for name in ['SOURCE_MANIFEST.json', *files]:
        monitor.check()
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with (source / name).open('rb') as incoming, target.open('xb') as outgoing:
            shutil.copyfileobj(incoming, outgoing)
    for source_name, name in [('launcher/launcher.lock.json', 'launcher.lock.json'), ('launcher/kind-linux-amd64', 'approved-kind-linux-amd64')]:
        monitor.check()
        shutil.copyfile(package / source_name, root / name)
    shutil.copyfile(inputs['auth_path'], root / 'launcher-authorization.json')
    atomic_json(root / 'ownership.json', dict(remote_root=str(root), expected_hostname=config['hostname'], runs=config['runs']))
    source_boundary(root)
    monitor.check()


def launch_state(inputs, foreign, resource, deadline):
    return dict(schema='istio-public-launch-state-v1', supervisor_pid=os.getpid(), config_sha256=sha(inputs['config_path']),
                authorization_sha256=sha(inputs['auth_path']), budget_sha256=sha(inputs['budget_path']),
                public_manifest_sha256=inputs['config']['public_manifest_sha256'],
                package_archive_sha256=inputs['config']['package_archive_sha256'],
                original_budget=inputs['budget'], current_foreign=foreign, pre_prepare_resource=resource,
                initial_free=resource['root']['available'], deadline=deadline)


def bind_phase(config_path, auth_path, exchange, package, phase):
    config = read_json(config_path)
    root = operator(config)
    state = read_json(exchange / 'launch-state.json')
    require(os.getppid() == state['supervisor_pid'], 'phase must be an owned child of the same live supervisor')
    require(time.monotonic() < state['deadline'], 'original lifecycle deadline before phase')
    check_file(config_path, state['config_sha256'])
    check_file(auth_path, state['authorization_sha256'])
    check_file(regular_path(config['budget_file']), state['budget_sha256'])
    package_boundary(package, state['public_manifest_sha256'])
    authorization(read_json(auth_path), state['config_sha256'], package)
    check_file(root / 'launcher-authorization.json', state['authorization_sha256'])
    check_file(root / 'launcher.lock.json', sha(package / 'launcher/launcher.lock.json'))
    check_file(root / 'approved-kind-linux-amd64', sha(package / 'launcher/kind-linux-amd64'))
    require(read_json(root / 'ownership.json') == dict(remote_root=str(root), expected_hostname=config['hostname'], runs=config['runs']), 'immutable declared staging ownership')
    budget = read_budget(regular_path(config['budget_file']), config['hostname'])
    require(budget == state['original_budget'], 'same original budget in child phase')
    resources, runtime = imported_source(package)
    install_enforcement(budget, resources, state['initial_free'], state['deadline'])
    os.environ['DOCKER_CONFIG'] = str(root / 'docker-config')
    from prepare import host_guard
    host_guard(config['hostname'])
    source_boundary(root, phase in {'runtime-serial', 'delete'})
    resources.enforce(dict(root=resources.filesystem('/'), available_memory=resources.available_memory()), state['initial_free'])
    return config, root, runtime


def interrupted(number, frame):
    raise InterruptedError('whole lifecycle cancelled by signal')


def child_phase(args, package):
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    config, root, runtime = bind_phase(args.operator_config, args.launcher_authorization, args.exchange_dir, package, args.phase)
    from prepare import prepare
    from delete_staging import delete
    operations = {'prepare': prepare, 'setup': runtime.setup, 'runtime-serial': runtime.serial_lifecycle, 'delete': delete}
    arguments = [root, config['hostname']]
    if args.phase in {'setup', 'runtime-serial'}:
        arguments.insert(1, config['runs'][0])
    operations[args.phase](*arguments)


def run_phase(inputs, phase, seconds, monitor):
    from evidence import Recorder, digest
    immutable_inputs(inputs)
    root = inputs['root']
    source_boundary(root, phase in {'runtime-serial', 'delete'})
    recorder = Recorder(inputs['exchange'] / ('phase-' + phase), supervisor=monitor)
    argv = ['/usr/bin/python3', '-B', str(inputs['package'] / 'public_lifecycle.py'), '_phase', phase,
            '--operator-config', str(inputs['config_path']), '--launcher-authorization', str(inputs['auth_path']),
            '--exchange-dir', str(inputs['exchange'])]
    result = recorder.run(argv, seconds)
    monitor.check()
    if phase != 'delete':
        source_boundary(root, phase != 'prepare')
    immutable_inputs(inputs)
    record = dict(actual_exit=result.returncode, natural_exit=result.returncode, drained=True, timed_out=False,
                  stdout_sha256=digest(result.stdout), stderr_sha256=digest(result.stderr))
    atomic_json(inputs['exchange'] / (phase + '.completion.json'), record)
    return record


def suite_ids(matrix):
    ids = [case['id'] for case in matrix['cases']]
    ids += ['IS17-after-' + group for group in matrix['IS17']['after_groups']]
    require(len(ids) == 63 and len(set(ids)) == 63, 'exact reviewed 63-request suite inventory')
    return set(ids)


def serial_evidence(inputs, bridge):
    root = inputs['root']
    require(len(bridge.completed) == 3, 'all three independent verified receipts')
    expected = suite_ids(read_json(root / 'case-expectations.json'))
    suites = {}
    for run in inputs['config']['runs']:
        records = read_json(root / 'runs' / run['id'] / 'results.json')
        require(len(records) == 63 and {item['id'] for item in records} == expected, 'exact completed suite')
        require(all(item['status'] == 'PASSED' for item in records), 'every reviewed assertion passed')
        suites[run['id']] = dict(requests=len(records), results_sha256=sha(root / 'runs' / run['id'] / 'results.json'))
    require(read_json(root / 'cleanup-verification.json')['nodes_absent'] is True, 'actual owned cleanup verified')
    for item in bridge.completed:
        entry = next(entry for entry in bridge.entries if entry[0] == item['export_id'])
        require(read_json(entry[2]) == item['receipt'], 'returned receipt unchanged before staging deletion')
    return suites


def execute(inputs, monitor, bridge, phase_runner):
    phases = {}
    for phase, seconds in PHASES[:3]:
        monitor.check()
        phases[phase] = phase_runner(inputs, phase, seconds, monitor)
        natural_phase(phases[phase])
    monitor.check()
    suites = serial_evidence(inputs, bridge)
    phases['delete'] = phase_runner(inputs, 'delete', 60, monitor)
    natural_phase(phases['delete'])
    require(not inputs['root'].exists(), 'exact staging deletion actually completed')
    monitor.check()
    return phases, suites


def natural_phase(receipt):
    require(receipt['actual_exit'] == receipt['natural_exit'] == 0, 'actual natural phase exit zero')
    require(receipt['drained'] is True and receipt['timed_out'] is False, 'actual phase output fully drained without timeout')


def completion(inputs, phases, suites, bridge, monitor):
    record = dict(schema='istio-public-lifecycle-completion-v1', status='COMPLETED',
                  public_manifest_sha256=inputs['config']['public_manifest_sha256'],
                  package_archive_sha256=inputs['config']['package_archive_sha256'],
                  original_budget_sha256=inputs['config']['budget_sha256'], original_budget=inputs['budget'],
                  phase_exits_verified=True, external_supervisor_completion_required=True, phases=phases, suites=suites,
                  verified_exports=bridge.completed, peaks=monitor.peaks, staging_absent=not inputs['root'].exists(),
                  current_foreign_sha256=sha(inputs['exchange'] / 'current-foreign.json'), foreign_preserved=True,
                  resource_samples_sha256=sha(inputs['exchange'] / 'whole-lifecycle-resources.jsonl'))
    monitor.base_check()
    print(json.dumps(record, sort_keys=True), flush=True)
    monitor.base_check()
    atomic_json(inputs['exchange'] / 'lifecycle.completion.json', record)


def final_drain(monitor, deadline):
    monitor.stop.set()
    if monitor.started and monitor.thread.is_alive():
        monitor.thread.join(timeout=max(0,min(40,deadline-time.monotonic())))
        require(not monitor.thread.is_alive(),'original deadline final monitor drain')
    monitor.journal.close()


def run(args, package):
    started = time.monotonic()
    os.environ['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
    inputs = input_gate(args.operator_config, args.launcher_authorization, args.exchange_dir, package)
    resources, runtime = imported_source(package)
    os.environ['DOCKER_CONFIG'] = str(inputs['root'] / 'docker-config')
    deadline = started + LIFECYCLE_SECONDS
    resources.lifecycle_deadline = deadline
    before, resource = capture(inputs['config'], resources)
    initial = resource['root']['available']
    resources.enforce(resource, initial, bootstrap=True)
    enforce_budget(inputs['budget'], measure())
    require(time.monotonic() < deadline, 'original pre-prepare deadline')
    inputs['exchange'].mkdir(mode=0o700)
    atomic_json(inputs['exchange'] / 'current-foreign.json', before)
    atomic_json(inputs['exchange'] / 'launch-state.json', launch_state(inputs, before, resource, deadline))
    original = install_enforcement(inputs['budget'], resources, initial, deadline)
    bridge = Bridge(inputs['root'], inputs['exchange'], inputs['config'], inputs['config']['public_manifest_sha256'])
    monitor = make_monitor(runtime, inputs['root'], inputs['exchange'], initial, inputs['config'], before, inputs['budget'], deadline, bridge)
    previous = {sig: signal.signal(sig, interrupted) for sig in [signal.SIGTERM, signal.SIGINT]}
    try:
        monitor.start()
        stage(inputs, monitor)
        phases, suites = execute(inputs, monitor, bridge, run_phase)
        monitor.close()
        completion(inputs, phases, suites, bridge, monitor)
    except BaseException as error:
        monitor.cancel(error)
        atomic_json(inputs['exchange'] / 'lifecycle.failure.json', dict(status='FAILED', error=str(monitor.error or error), completion=False))
        raise
    finally:
        final_drain(monitor, deadline)
        resources.enforce = original
        for sig, handler in previous.items():
            signal.signal(sig, handler)


def main():
    parser = argparse.ArgumentParser()
    operations = parser.add_subparsers(dest='operation', required=True)
    for name in ['run', '_phase']:
        operation = operations.add_parser(name)
        if name == '_phase':
            operation.add_argument('phase', choices=[item[0] for item in PHASES])
        operation.add_argument('--operator-config', required=True, type=pathlib.Path)
        operation.add_argument('--launcher-authorization', required=True, type=pathlib.Path)
        operation.add_argument('--exchange-dir', required=True, type=pathlib.Path)
    args = parser.parse_args()
    package = pathlib.Path(__file__).absolute().parent
    operations = {'run': run, '_phase': child_phase}
    operations[args.operation](args, package)


if __name__ == '__main__':
    main()
