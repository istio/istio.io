import pathlib
import json
import time
from evidence import save


class Context:
    def __init__(self, root, config, recorder):
        self.root = pathlib.Path(root)
        self.config = config
        self.recorder = recorder
        self.kubeconfig = str(self.root / "kubeconfig")
        self.context = config["context"]
        self.bin = self.root.parent.parent / "bin"
        self.identity = None
        self.deadline = None

    def kubectl(self, args, timeout=30, check=True):
        argv = [str(self.bin / "kubectl"), "--kubeconfig", self.kubeconfig,
                "--context", self.context] + args
        return self.recorder.run(argv, self.command_timeout(timeout), check, deadline=self.deadline)

    def istio(self, args, timeout=30, check=True):
        argv = [str(self.bin / "istioctl"), "--kubeconfig", self.kubeconfig,
                "--context", self.context] + args
        return self.recorder.run(argv, self.command_timeout(timeout), check, deadline=self.deadline)

    def command_timeout(self, timeout):
        if self.deadline is None:
            return timeout
        remaining = self.deadline - time.monotonic()
        assert remaining > 0, "absolute context observation deadline expired"
        return min(timeout, remaining)

    def obj(self, args, timeout=30):
        return json.loads(self.kubectl(args + ["-o", "json"], timeout).stdout)

    def guard_file(self):
        view = self.obj(["config", "view"])
        assert [x["name"] for x in view["contexts"]] == [self.context]
        assert [x["name"] for x in view["clusters"]] == [self.context]
        assert view["current-context"] == self.context
        server = view["clusters"][0]["cluster"]["server"]
        assert server == "https://127.0.0.1:%d" % self.config["api_port"]
        assert view["contexts"][0]["context"]["cluster"] == self.context

    def guard(self):
        self.guard_file()
        nodes = self.obj(["get", "nodes"])["items"]
        assert len(nodes) == 1
        assert nodes[0]["metadata"]["name"] == self.config["node"]
        system = self.obj(["get", "namespace", "kube-system"])
        identity = dict(node_uid=nodes[0]["metadata"]["uid"],
                        namespace_uid=system["metadata"]["uid"],
                        context=self.context, endpoint="https://127.0.0.1:%d" % self.config["api_port"])
        if self.identity is not None:
            assert identity == self.identity
        self.identity = identity
        save(self.root, "runtime/context-identity.json", identity)

    def mutate(self, args, timeout=30):
        self.guard()
        return self.kubectl(args, timeout)

    def pods(self):
        items = self.obj(["get", "pods", "-n", "agent-tools"])["items"]
        return {item["metadata"]["labels"]["app"]: item for item in items}

    def exec(self, pod, args, container="app"):
        return self.kubectl(["exec", "-n", "agent-tools", pod, "-c", container, "--"] + args)
