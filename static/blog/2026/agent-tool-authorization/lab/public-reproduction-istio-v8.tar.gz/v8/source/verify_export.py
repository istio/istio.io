import argparse
import hashlib
import json
import pathlib
import re
import tarfile
from evidence import digest, publish_json
from export import ROOT_FILES, source_file, run_file
from verify import require
from public_projection import validate


def archive_binding(path, expected):
    require(re.fullmatch(r'[0-9a-f]{64}', expected) is not None, 'independent archive SHA256 required')
    require(path.stat().st_size <= 1024 ** 3, 'archive byte ceiling')
    hashed = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(65536), b''):
            hashed.update(chunk)
    require(hashed.hexdigest() == expected, 'independent archive binding')


def unique_object(pairs):
    result = {}
    for name, value in pairs:
        require(name not in result, 'duplicate JSON key')
        result[name] = value
    return result


def safe_members(archive):
    members = archive.getmembers()
    require(len(members) <= 10000, 'archive member count ceiling')
    names = set()
    total = 0
    for member in members:
        path = pathlib.PurePosixPath(member.name)
        require(not path.is_absolute() and '..' not in path.parts, 'unsafe archive path')
        require(path.as_posix() == member.name and bool(path.parts), 'canonical member path')
        require(member.isfile() and not member.issparse(), 'only regular nonsparse export files')
        require(member.name not in names, 'duplicate archive member')
        require(0 <= member.size <= 16777216, 'single export file ceiling')
        names.add(member.name)
        total += member.size
    require(total < 1024 ** 3, 'expanded evidence ceiling')
    return {member.name: member for member in members}


def permitted(name, runs):
    parts = pathlib.PurePosixPath(name).parts
    if len(parts) == 1:
        return name in ROOT_FILES
    if parts[0] == 'source':
        return source_file(parts)
    if len(parts) >= 3 and parts[0] == 'runs':
        return parts[1] in runs and run_file(parts[2:])
    return False


def validated_snapshot(archive, members, run_id):
    manifest_name = 'export-manifest-' + run_id + '.json'
    require(manifest_name in members, 'exact export manifest required')
    require(members[manifest_name].size <= 1048576, 'manifest ceiling')
    raw = archive.extractfile(members[manifest_name]).read()
    manifest = json.loads(raw, object_pairs_hook=unique_object)
    require(set(manifest) == {'files','bytes','time'}, 'exact export manifest schema')
    require(type(manifest['bytes']) is int and manifest['bytes'] >= 0, 'exact manifest bytes')
    require(isinstance(manifest['files'],dict) and bool(manifest['files']), 'nonempty manifest inventory')
    require(set(members) == set(manifest['files']) | {manifest_name}, 'exact declared archive inventory')
    runs = declared_runs(archive, members)
    snapshot = {}
    for name, expected in manifest['files'].items():
        require(permitted(name, runs), 'export allowlist path: ' + name)
        data = archive.extractfile(members[name]).read()
        require(digest(data) == expected, 'export hash ' + name)
        validate(name, data)
        snapshot[name] = data
    require(sum(len(data) for data in snapshot.values()) == manifest['bytes'], 'declared export byte count')
    snapshot[manifest_name] = raw
    return snapshot, manifest_name


def declared_runs(archive, members):
    if 'ownership.json' not in members:
        return set()
    require(members['ownership.json'].size <= 1048576, 'ownership ceiling')
    owner = json.loads(archive.extractfile(members['ownership.json']).read(), object_pairs_hook=unique_object)
    validate('ownership.json', json.dumps(owner).encode())
    return {run['id'] for run in owner['data']['runs']}


def verify_export(archive_path, destination, run_id, expected_sha256):
    require(re.fullmatch(r'[a-zA-Z0-9_-]{1,100}', run_id) is not None, 'safe export ID')
    require(not destination.exists(), 'fresh export verification directory')
    for ancestor in (destination, *destination.parents):
        require(not ancestor.is_symlink(), 'no extraction symlink ancestor')
    archive_binding(archive_path, expected_sha256)
    with tarfile.open(archive_path) as archive:
        snapshot, manifest_name = validated_snapshot(archive, safe_members(archive), run_id)
    destination.mkdir(parents=True)
    for name, raw in snapshot.items():
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(raw)
    receipt = dict(run_id=run_id.removesuffix('-before-teardown'), verified=True,
                   archive_sha256=expected_sha256, files=len(snapshot) - 1,
                   manifest_sha256=digest(snapshot[manifest_name]))
    return publish_json(destination, 'verified-export-receipt.json', receipt)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=pathlib.Path)
    parser.add_argument('destination', type=pathlib.Path)
    parser.add_argument('run_id')
    parser.add_argument('--archive-sha256', required=True)
    args = parser.parse_args()
    print(verify_export(args.archive, args.destination, args.run_id, args.archive_sha256))


if __name__ == '__main__':
    main()
