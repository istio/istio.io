import argparse
import copy
import pathlib
from evidence import load, save
from policy_gate import check_rules
from runtime import check_node_logging
from verify import require, verify


def check_observed_health(root, matrix):
    results = []
    for name in ("IS02-alpha", "IS02-untrusted"):
        case = load(root / "cases" / name / "case.json")
        observation = load(root / "cases" / name / "observation.json")
        result = verify(case, observation, matrix["layers"], observation["source_hash"])
        result["status"] = "RECORDED_COMPARISON_ONLY"
        result["acceptance_credit"] = False
        result["limit"] = "preliminary bootstrap capture; resource prerequisite failed; no policy/identity/no-effect claim"
        results.append(result)
    return results


def reject(call, argument):
    try:
        call(argument)
    except AssertionError as error:
        return dict(rejected=True, error=str(error))
    raise AssertionError("checker accepted corrupted/unsafe input")


def log_control(config):
    check_node_logging(config)


def control_mutation(case, observation, matrix, name):
    changed = copy.deepcopy(observation)
    layers = copy.deepcopy(matrix["layers"])
    if name == "wrong-expected-status":
        layers[case["layer"]]["status"] = 201
    if name == "unexpected-row":
        changed["after"]["ledger"]["count"] += 1
    if name == "missing-peer":
        changed["proxy"][0]["peer"] = ""
    if name == "source-hash":
        changed["source_hash"] = "0" * 64
    try:
        verify(case, changed, layers, observation["source_hash"])
    except AssertionError as error:
        return dict(name=name, rejected=True, error=str(error), checker_only=True,
                    limit="health evidence; mandatory IS18 denied-call mutation control remains unrun")
    raise AssertionError("verifier accepted corruption: " + name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=pathlib.Path)
    parser.add_argument("matrix")
    parser.add_argument("output", type=pathlib.Path)
    args = parser.parse_args()
    matrix = load(args.matrix)
    health = check_observed_health(args.run_root, matrix)
    listeners = load(args.run_root / "runtime/gateway-empty/attempt-001/active-listeners.json")
    rules = check_rules(listeners, False)
    node = load(args.run_root / "runtime/node-cap.json")
    unsafe = reject(log_control, node["host_config"]["LogConfig"])
    case = load(args.run_root / "cases/IS02-alpha/case.json")
    observation = load(args.run_root / "cases/IS02-alpha/observation.json")
    controls = [control_mutation(case, observation, matrix, name) for name in ("wrong-expected-status", "unexpected-row", "missing-peer", "source-hash")]
    save(args.output.parent, args.output.name, dict(checker_only=True, health=health, unsatisfiable_allow=rules, logging_gate=unsafe, controls=controls))


if __name__ == "__main__":
    main()
