import json
import os
import pathlib
import shutil
import subprocess
from evidence import gst, save
from verify import require

CONTAINER_FORMAT = '{"id":{{json .Id}},"name":{{json .Name}},"running":{{json .State.Running}}}'


def container_records(recorder, ids):
    if not ids:
        return []
    raw = recorder.run(["docker", "inspect", "--format", CONTAINER_FORMAT] + ids).stdout
    records = [json.loads(line) for line in raw.splitlines()]
    for item in records:
        require(set(item) == {"id", "name", "running"}, "constrained baseline fields")
        require(isinstance(item["running"], bool), "baseline running boolean")
    return records


def available_memory():
    entries = pathlib.Path("/proc/meminfo").read_text().splitlines()
    values = dict(line.split(":", 1) for line in entries)
    return int(values["MemAvailable"].split()[0]) * 1024


def filesystem(location):
    state = os.statvfs(location)
    total = state.f_blocks * state.f_frsize
    free = state.f_bavail * state.f_frsize
    used = (state.f_blocks - state.f_bfree) * state.f_frsize
    return dict(total=total, available=free, used=used,
                used_percent=100 * used / (used + free),
                inodes_free=state.f_favail, inodes_total=state.f_files)


def docker_json(recorder, args):
    return json.loads(recorder.run(["docker"] + args).stdout)


def baseline(root, config, recorder):
    require("DOCKER_CONFIG" in os.environ, "owned Docker config environment required")
    info = docker_json(recorder, ["info", "--format", "{{json .}}"])
    ids = recorder.run(["docker", "ps", "-aq", "--no-trunc"]).stdout.decode().split()
    containers = container_records(recorder, ids)
    networks = recorder.run(["docker", "network", "ls", "--format", "{{.Name}}"]).stdout.decode().split()
    require(config["network"] not in networks, "network collision")
    names = [item["name"].lstrip("/") for item in containers]
    require(config["node"] not in names, "node collision")
    require(not any(name.startswith("technical-blogs-20261009-opensearch") for name in names), "OpenSearch lab runtime collision")
    require(info["MemoryLimit"] and info["SwapLimit"] and info["CpuCfsQuota"], "Docker cgroup caps supported")
    require(info["CgroupVersion"] == "2", "cgroup v2")
    result = dict(time=gst(), docker_version=info["ServerVersion"], docker_root=info["DockerRootDir"],
                  root=filesystem("/"), docker=filesystem(info["DockerRootDir"]),
                  available_memory=available_memory(), baseline_containers=containers,
                  networks=networks, vm_max_map_count=pathlib.Path("/proc/sys/vm/max_map_count").read_text().strip())
    save(root, "preflight.json", result)
    enforce(result, result["root"]["available"], bootstrap=True)
    return result


def enforce(sample, initial_free, bootstrap=False):
    require(sample["root"]["available"] >= 25 * 1024 ** 3, "25 GiB host free guard")
    require(sample["root"]["used_percent"] < 94, "94% disk stop guard")
    require(initial_free - sample["root"]["available"] <= 8 * 1024 ** 3, "combined 8 GiB incremental disk guard")
    memory = 2 * 1024 ** 3
    if bootstrap:
        memory = 10 * 1024 ** 3
    require(sample["available_memory"] >= memory, "available RAM guard")
    require(sample["root"]["inodes_free"] > 100000, "inode exhaustion guard")


def sample(root, initial_free, node_id=None, sink=None):
    record = dict(time=gst(), root=filesystem("/"), available_memory=available_memory())
    if node_id:
        cgroup = pathlib.Path("/sys/fs/cgroup/system.slice/docker-" + node_id + ".scope")
        record["cgroup_memory"] = int((cgroup / "memory.current").read_text())
        record["cgroup_events"] = (cgroup / "memory.events").read_text()
    if sink is None:
        with (root / "resource-samples.jsonl").open("a") as output:
            output.write(json.dumps(record) + "\n")
    else:
        sink.write(json.dumps(record) + "\n")
        sink.flush()
    enforce(record, initial_free)
    return record


def same_baseline(before, recorder):
    running = [x["id"] for x in before["baseline_containers"] if x["running"]]
    states = container_records(recorder, running)
    require(all(x["running"] for x in states), "unrelated baseline containers still running")
    require(sorted(x["id"] for x in states) == sorted(running), "same unrelated container IDs")
    return states


def initial_baseline(root):
    from evidence import digest, load
    path = root / "preflight-initial.json"
    state = load(path)
    binding = load(root / "runtime-source-binding.json")
    require(digest(path.read_bytes()) == binding["initial_baseline_sha256"], "immutable initial baseline hash")
    for item in state["baseline_containers"]:
        require(set(item) == {"id", "name", "running"}, "initial baseline constrained schema")
    return state
