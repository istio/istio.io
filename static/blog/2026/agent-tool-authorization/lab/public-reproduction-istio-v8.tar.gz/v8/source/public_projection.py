"""Closed public artifact schemas; producer projection and independent validation."""

import ast
import base64
import functools
import json
import pathlib
import re
from evidence import digest
from verify import require

MODELS = {}


def obj(name, fields, required=()):
    MODELS[name] = dict(type='object', fields=fields, required=list(required))
    return name


def seq(item):
    return dict(type='array', item=item, maximum=10000)


def mapping(item, pattern='[A-Za-z0-9_.:/|\[\]@-]{1,200}'):
    return dict(type='map', item=item, pattern=pattern, maximum=1000)


obj('run', dict(id='name', cluster='name', network='name', node='name', context='name', api_port='int'), ('id', 'cluster', 'network', 'node', 'context', 'api_port'))
obj('owner', dict(runs=seq('run')), ('runs',))
obj('filesystem', dict(total='int', available='int', used='int', used_percent='number', inodes_free='int', inodes_total='int'))
obj('container', dict(id='identifier', name='name', running='bool'), ('id', 'name', 'running'))
obj('preflight', dict(time='time', docker_version='token', root='filesystem', docker='filesystem', available_memory='int', baseline_containers=seq('container'), networks=seq('name'), vm_max_map_count='token'))
obj('sample', dict(time='time', root='filesystem', available_memory='int', cgroup_memory='int', cgroup_events='events'), ('time', 'root', 'available_memory'))
obj('caps', dict(Memory='int', MemorySwap='int', NanoCpus='int', log_driver='token', log_max_size='token', log_max_files='token'), ('Memory', 'MemorySwap', 'NanoCpus', 'log_driver', 'log_max_size', 'log_max_files'))
obj('nodecap', dict(created_utc='time', observed='time', capped='time', node_id='identifier', caps='caps', limit='startup_limit'), ('node_id', 'caps'))
obj('ownednode', dict(id='identifier', node='name', cluster='name', network='name', volumes=seq('name')), ('id', 'node', 'cluster', 'network', 'volumes'))
obj('network', dict(Id='identifier', Name='name', Driver='token'), ('Id', 'Name', 'Driver'))
obj('sourcebinding', dict(files=mapping('hash'), sha256='hash'), ('files', 'sha256'))
obj('binding', dict(source='sourcebinding', initial_baseline_sha256='hash', build_sha256='hash', versions_lock_sha256='hash'), ('source', 'initial_baseline_sha256', 'build_sha256', 'versions_lock_sha256'))
obj('build',dict(tag='image',id='identifier',source='sourcebinding',image_id='identifier',image_size='int',rootfs_diff_ids=seq('identifier'),time='time',preexisting='bool',ownership_proven='bool'),('tag','id','source','image_id'))
obj('image', dict(image='image', key='name', size='int', ownership_proven='bool', pre_pull_existed='bool', time='time', id='identifier', existed='bool', preexisting='bool', repository='token', reference='token', index_digest='identifier', manifest_digest='identifier', config_digest='identifier', architecture='token', os='token', rootfs_diff_ids=seq('identifier'), layers=seq(obj('layer',dict(digest='identifier',compressed='int',unpacked_tar_bytes='int'))), unpacked_tar_bytes='int', retrieved='time', base='image', tag='image', source='sourcebinding'))
obj('download',dict(status='int',sha256='hash',bytes='int',retrieved='time'))
obj('binary', dict(download='download',checksum='download',custom='bool', binary_sha256='hash', contract_sha256='hash', upstream_release='token', version='token', official_release_binary_is_distinct='bool', expected='hash'))
obj('binaries',dict(kind_official='binary',kind='binary',kubectl='binary',istio='binary'))
obj('versions', dict(binaries='binaries', images=mapping('image'),version_outputs_sha256=mapping('hash')), ('binaries', 'images'))
obj('row', dict(tenant_id='token', resource_id='token', operation='token', request_id='name'), ('tenant_id', 'resource_id', 'operation', 'request_id'))
obj('audit', dict(event='token', correlation='name', time='time', method='token', target='target', body_sha256='hash', status='int', reason='token', arguments='row'), ('event', 'correlation', 'time'))
obj('ledger', dict(rows=seq('row'), count='int', sha256='hash'), ('rows', 'count', 'sha256'))
obj('snapshot', {'tool-gateway':seq('audit'),'action-sink':seq('audit'),'scope-witness':seq('audit'),'ledger':'ledger'}, ('tool-gateway','action-sink','scope-witness','ledger'))
obj('proxy', dict(correlation='name', path='target', method='token', peer='token', tls='token', status='token', details='token', flags='token', upstream='token'))
obj('response', dict(sent='time', status='nullable_int', error='nullable_token', body_base64='body', completed='time', headers=seq(seq('token')), message_sha256='hash'))
obj('expected', dict(status='nullable_int', row_delta='int', handler_delta='int', accepted_delta='int', downstream_delta='int', sink_handler_delta='int', allowed_transport_errors=seq('token')))
obj('result', dict(id='name', status='token', expected='expected', actual='response', observation_sha256='hash', error='approved_error'), ('id','status'))
obj('repeat', dict(utf8='body_text', count='int'), ('utf8','count'))
obj('case', dict(id='name', source='name', destination='name', address='token', layer='token', stage='token', method='token', target='target', content_type='token', body_utf8='body_text', body_repeat='repeat', port='int', fresh_connection='bool', attempts='int', headers=mapping('token'), status='int'), ('id',))
obj('request', dict(host='token', method='token', target='target', headers=mapping('token'), body_base64='body'), ('host','method','target','headers','body_base64'))
obj('metadata', dict(name='name', namespace='name', uid='token', generation='int', labels=mapping('token')))
obj('condition', dict(type='token', status='token', reason='token'))
obj('containerstatus', dict(name='name', image='image', imageID='image', ready='bool', restartCount='int'))
obj('containerpin', dict(name='name', image='image', restartPolicy='token', resources=obj('limits',dict(requests=mapping('token'),limits=mapping('token')))))
obj('podspec', dict(serviceAccountName='name', hostNetwork='bool', containers=seq('containerpin'), initContainers=seq('containerpin')))
obj('podstatus', dict(podIP='token', containerStatuses=seq('containerstatus'), initContainerStatuses=seq('containerstatus'), conditions=seq('condition'), nodeInfo=obj('nodeinfo',dict(kubeletVersion='token', containerRuntimeVersion='token'))))
obj('pod', dict(apiVersion='token', kind='token', metadata='metadata', spec='podspec', status='podstatus'))
obj('observation', dict(correlation='name', source_hash='hash', response='response', before='snapshot', after='snapshot', proxy=seq('proxy'), sink_proxy=seq('proxy'), source='pod', destination='pod', readback='time'), ('correlation','source_hash','response','before','after','proxy','sink_proxy','source','destination'))
obj('operation', dict(ports=seq('token'), methods=seq('token'), paths=seq('target')))
obj('rule', {'from':seq(obj('fromrule',dict(source=obj('principal',dict(principals=seq('token')))))), 'to':seq(obj('torule',dict(operation='operation')))})
obj('policyspec', dict(selector=obj('selector',dict(matchLabels=mapping('token'))),action='token',rules=seq('rule'),mtls=obj('mtls',dict(mode='token'))))
obj('policy', dict(apiVersion='token',kind='token',metadata='metadata',spec='policyspec'))
obj('policylist', dict(apiVersion='token',kind='token',items=seq('policy')))
obj('sync_columns', dict(NAME='proxy_name', CLUSTER='proxy_cluster', CDS='sync_state', LDS='sync_state', EDS='sync_state',
                        RDS='sync_state', ECDS='sync_state', ISTIOD='istiod_name', VERSION='istio_version'),
    ('NAME', 'CLUSTER', 'CDS', 'LDS', 'EDS', 'RDS', 'ECDS', 'ISTIOD', 'VERSION'))
obj('sync_status', dict(rows=seq('sync_columns'), output_sha256='hash'), ('rows', 'output_sha256'))
obj('sync_comparison', dict(Clusters='comparison_state', Listeners='comparison_state', Routes='comparison_state', output_sha256='hash'),
    ('Clusters', 'Listeners', 'Routes', 'output_sha256'))
obj('readiness', dict(pod='name',container='token',time='time',values=mapping('int'),stats_sha256='hash'))
obj('rbac',dict(action='token', policies=mapping('rbac_policy')))
obj('rbac_policy',dict(permissions=seq('rbac_atom'),principals=seq('rbac_atom')))
obj('rbac_atom',dict(any='bool',notRule='rbac_atom',notId='rbac_atom',andRules=obj('andrules',dict(rules=seq('rbac_atom'))),orRules='andrules',andIds=obj('andids',dict(ids=seq('rbac_atom'))),orIds='andids',destinationPort='int',header=obj('header',dict(name='token',stringMatch=obj('exact',dict(exact='token')))),urlPath=obj('urlpath',dict(path='exact')),authenticated=obj('authenticated',dict(principalName='exact'))))
obj('gate',dict(specs=mapping('policyspec'),rules=seq('rbac'),time='time',sync_columns='sync_columns',listeners_hash='hash',listener_readiness='readiness'))
obj('read_only',dict(before='snapshot',after='snapshot',gate='gate'))
obj('identity',dict(uid='token',ip='token'))
obj('continuity',dict(initial='snapshot',snapshot='snapshot',pods=mapping('identity'),strict='policy',retained=mapping('policyspec'),narrow='policyspec',inventory='policylist'))
obj('routeidentity',dict(name='name',uid='token',ip='token',sa='name',spiffe='token'))
obj('routeproof',dict(source='routeidentity',target='routeidentity',authority='token',cluster='token',endpoint=obj('endpoint',dict(address='token',port_value='int')),source_spiffe='token',target_spiffe='token',selected_sha256='hash',selected='selectedroute'))
obj('routestate',dict(time='time',proof='routeproof',sync_columns=mapping('sync_columns'),listener_readiness=mapping('readiness'),config_sha256='hash',source_certificate_metadata_sha256='hash',target_certificate_metadata_sha256='hash',retained='invariants'))
obj('attempt',dict(time='time',error='approved_error',message_sha256='hash'))
obj('routegate',dict(attempts=seq('attempt'),accepted='nullable_routestate',read_only_snapshot=obj('routesnapshot',dict(before='snapshot',after='snapshot'))))
obj('certleaf',dict(subject_alt_names=seq(obj('san',dict(uri='token'))),valid_from='time',expiration_time='time'),('subject_alt_names','valid_from','expiration_time'))
obj('cert',dict(certificates=seq(obj('certchain',dict(cert_chain=seq('certleaf'))))))
obj('failure',dict(error='token',message='approved_error',time='time',status='token',message_sha256='hash'))
obj('command',dict(operation='token',exit='nullable_int',timeout='number',start='time',end='time',argv_sha256='hash'))
obj('errorproof',dict(message='approved_error',message_sha256='hash'),('message_sha256',))
obj('cleanup',dict(acceptance_restored='bool',node_deleted='identifier',network_deleted='identifier',node_id='identifier',stop_attempted='bool',stopped='bool',stop_exit='int',images_removed=seq('image'),time='time',baseline=seq('container'),commands=seq('command'),errors=seq('errorproof'),nodes_absent='bool',networks_absent='bool',owned_volumes_absent=seq('name'),second_cluster_never_created='nullable_bool'))
obj('abortfailure',dict(outcome='cleanup',errors=seq('errorproof'),time='time'))
obj('receipt',dict(run_id='name',verified='bool',archive_sha256='hash',files='int',manifest_sha256='hash'),('run_id','verified','archive_sha256','files','manifest_sha256'))
obj('teardown',dict(node_id='identifier',time='time',final_node_sample='sample',host_monitor_continues='bool'))
obj('is20',dict(source='sourcebinding',baseline=seq('container'),time='time'))
obj('version',dict(clientVersion=obj('versionfields',dict(gitVersion='token',gitCommit='token',platform='token')),serverVersion='versionfields'))
obj('context',dict(node_uid='token',namespace_uid='token',context='name',endpoint='token'))
obj('wrongcontext',dict(rejected='bool',mutated='bool',wrong_context='name'))
obj('statrow',dict(name='token',value='int'),('name','value'))
obj('stats',dict(pod='name',container='token',time='time',stats=obj('statsraw',dict(stats=seq('statrow'))),stats_sha256='hash'))
obj('sync',dict(time='time',status='sync_status',comparison='sync_comparison'),('status','comparison'))
obj('deletion',dict(time='time',object='token',authored_hash='hash'))
obj('projection',dict(image_tar_bytes='int',build_evidence_reserve='int',ceiling='int'))
obj('runownership',dict(runs=mapping('token')))
obj('mutation',dict(checker_only='bool',rejected='bool',mutation_sha256='hash',proof='negative_observation'),('checker_only','rejected','mutation_sha256','proof'))
obj('proofhash',dict(original_sha256='hash'))

FILES = {
 'ownership.json':'owner','preflight-initial.json':'preflight','preflight.json':'preflight','versions.lock.json':'versions',
 'disk-projection.json':'projection','build.json':'build','runtime-source-binding.json':'binding','owned-images.json':seq('image'),
 'owned-node-index.json':'image','node-index-pre-pull.json':'image','run-ownership.json':'runownership','cleanup.json':'cleanup',
 'cleanup-verification.json':'cleanup','final-export-receipt.json':'receipt','export-receipt.json':'receipt',
 'resource-stop.json':'failure','resource-abort.json':'cleanup','resource-abort-failure.json':'abortfailure',
 'results.json':seq('result'),'assertions.json':seq('result'),'failure.json':'failure','IS20-before-export.json':'is20',
 'monitor-teardown.json':'teardown','node-cap.json':'nodecap','owned-node.json':'ownednode','owned-network.json':'network',
 'kubernetes-version.json':'version','nodes.json':obj('nodelist',dict(items=seq('pod'))),'istio-version.json':obj('istiover',dict(clientVersion=obj('istioclient',dict(version='token',revision='token',golang_version='token',status='token',tag='token')),meshVersion=seq(obj('istiocomponent',dict(Component='token',Info='istioclient'))),dataPlaneVersion=seq(obj('istioplane',dict(istioVersion='token',istioProxyVersion='token',revision='token'))))),
 'services.json':'servicelist','endpoints.json':'endpointlist','podip-routes.json':'routeobjects','podip-route-binding.json':'routebinding',
 'context-identity.json':'context','wrong-context-control.json':'wrongcontext','case.json':'case','request.json':'request',
 'observation.json':'observation','comparison.json':'result','baseline-inventory.json':'policylist','authored-manifest.json':'policy',
 'restored-object.json':'policy','deletion-receipt.json':'deletion','restoration-receipt.json':'deletion',
 'read-only-ledger.json':'read_only','policies.json':'policylist','active-listeners.json':obj('listeners',dict(rules=seq('rbac'))),
 'sync.json':'sync','gate.json':'gate','error.json':'failure','continuity-baseline.json':'continuity','final-continuity.json':'continuity',
 'pod-route-gate.json':'routegate','listener-stats.json':'stats','wrong-status.json':'mutation','denied-row-added.json':'mutation',
 'missing-peer.json':'mutation','source-hash.json':'mutation','resource-samples.jsonl':seq('sample')}

obj('serviceport',dict(name='token',port='int',targetPort='int',appProtocol='token',protocol='token'))
obj('servicespec',dict(selector=mapping('token'),ports=seq('serviceport'),type='token',clusterIP='token',clusterIPs=seq('token')))
obj('service',dict(apiVersion='token',kind='token',metadata='metadata',spec='servicespec'))
obj('servicelist',dict(items=seq('service')))
obj('endpointaddress',dict(addresses=seq('token'),conditions=obj('endpointconditions',dict(ready='bool',serving='bool',terminating='bool')),targetRef=obj('targetref',dict(kind='token',namespace='name',name='name',uid='token'))))
obj('endpointslice',dict(metadata='metadata',addressType='token',ports=seq('serviceport'),endpoints=seq('endpointaddress')))
obj('endpointlist',dict(items=seq('endpointslice')))
obj('specidentity',dict(uid='nullable_token',spec='policyspec'))
obj('serviceidentity',dict(uid='token',spec='servicespec'))
obj('invariants',dict(pods=mapping('identity'),services=mapping('serviceidentity'),policies=mapping('specidentity'),strict='specidentity'))
obj('routeobject',dict(apiVersion='token',kind='token',metadata='metadata',spec='routespec'))
obj('routespec',dict(hosts=seq('token'),addresses=seq('token'),location='token',resolution='token',exportTo=seq('token'),ports=seq(obj('routeport',dict(number='int',name='token',protocol='token',targetPort='int'))),endpoints=seq(obj('routeendpoint',dict(address='token',ports=mapping('int')))),subjectAltNames=seq('token'),host='token',trafficPolicy=obj('trafficpolicy',dict(portLevelSettings=seq(obj('portsettings',dict(port=obj('port',dict(number='int')),tls=obj('tls',dict(mode='token',sni='token',subjectAltNames=seq('token')))))))),gateways=seq('token'),http=seq(obj('httproute',dict(retries=obj('retries',dict(attempts='int')),route=seq(obj('destination',dict(destination=obj('routedestination',dict(host='token',port='port'))))))))))
obj('routeobjects',dict(apiVersion='token',kind='token',items=seq('routeobject')))
obj('routeidentityspec',dict(uid='token',spec='routespec'))
obj('routebinding',dict(time='time',original='invariants',objects=mapping('routeidentityspec'),manifest_sha256='hash',targets=mapping('routeidentity')))

obj('negative_row',dict(tenant_id='token',resource_id='token',operation='token',request_id='name'))
obj('negative_ledger',dict(rows=seq('negative_row'),count='int',sha256='hash'))
obj('negative_snapshot',dict(MODELS['snapshot']['fields'],ledger='negative_ledger'))
obj('negative_observation',dict(MODELS['observation']['fields'],before='negative_snapshot',after='negative_snapshot'))

obj('socketaddress',dict(address='token',port_value='int'))
obj('address',dict(socket_address='socketaddress'))
obj('empty',{})
obj('ads',dict(ads='empty'))
obj('rds',dict(route_config_name='token',config_source='ads'))
obj('hcm',{'@type':'token','rds':'rds'})
obj('filter',dict(name='token',typed_config='hcm'))
obj('chainmatch',dict(application_protocols=seq('token'),transport_protocol='token'))
obj('chain',dict(filter_chain_match='chainmatch',filters=seq('filter')))
obj('selectedlistener',dict(name='token',address='address',filter_chains=seq('chain')))
obj('routematch',dict(prefix='target'))
obj('routeaction',dict(cluster='token',timeout='token',max_grpc_timeout='token'))
obj('selectedrouteentry',dict(name='token',match='routematch',route='routeaction'))
obj('virtualhost',dict(name='token',domains=seq('token'),routes=seq('selectedrouteentry')))
obj('grpc',dict(envoy_grpc=obj('envoygrpc',dict(cluster_name='token'))))
obj('sdssource',dict(api_config_source=obj('apiconfig',dict(grpc_services=seq('grpc')))))
obj('sds',dict(name='token',sds_config='sdssource'))
obj('validationsan',dict(match_subject_alt_names=seq('exact')))
obj('validationcontext',dict(default_validation_context='validationsan',validation_context_sds_secret_config='sds'))
obj('commontls',dict(tls_certificate_sds_secret_configs=seq('sds'),combined_validation_context='validationcontext'))
obj('upstreamtls',{'@type':'token','sni':'token','common_tls_context':'commontls'})
obj('transportsocket',dict(name='token',typed_config='upstreamtls'))
obj('eds',dict(service_name='token',eds_config='ads'))
obj('selectedcluster',dict(name='token',type='token',eds_cluster_config='eds',transport_socket='transportsocket'))
obj('lbendpoint',dict(health_status='token',endpoint=obj('endpointbody',dict(address='address'))))
obj('locality',dict(lb_endpoints=seq('lbendpoint')))
obj('selectedendpoints',dict(cluster_name='token',endpoints=seq('locality')))
obj('selectedroute',dict(listener='selectedlistener',route='virtualhost',cluster='selectedcluster',endpoint='selectedendpoints'),('listener','route','cluster','endpoint'))

PATTERNS = dict(hash='[0-9a-f]{64}', identifier='(?:sha256:)?[0-9a-f]{64}', name='/?[A-Za-z0-9_.-]{1,160}',
 token='[A-Za-z0-9_.:/|@=,%+\[\]{}() !?-]{0,2048}', image='[A-Za-z0-9_.:/@-]{1,300}',
 target='[A-Za-z0-9_./%?=&+-]{1,2048}', time='[0-9T:. +ZGSTM-]{1,80}',
 events='(?:[a-z_]+ [0-9]+\n){1,20}')


@functools.lru_cache(maxsize=1)
def errors():
    values = set()
    for name in ['runtime.py','verify.py','policy_gate.py','pod_route.py','e2e.py','resources.py','verify_cleanup.py']:
        tree = ast.parse(pathlib.Path(__file__).with_name(name).read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'require' and len(node.args) == 2:
                if isinstance(node.args[1], ast.Constant) and isinstance(node.args[1].value, str):
                    values.add(node.args[1].value)
    return values | {'ConnectionResetError','RemoteDisconnected','BrokenPipeError','literal route required','headers/body size','duplicate key','JSON object required','exact required keys','bounded strings required','unsafe request ID','arguments unauthorized','incomplete body'}


def scalar(kind, value):
    if kind.startswith('nullable_') and value is None:
        return value
    kind = kind.removeprefix('nullable_')
    numeric = {'int':int,'bool':bool,'number':(int,float)}
    if kind in numeric:
        require(type(value) in (numeric[kind] if isinstance(numeric[kind],tuple) else (numeric[kind],)), 'public scalar type')
        return value
    require(isinstance(value,str), 'public text type')
    require(len(value) <= 1048576, 'public text ceiling')
    textual(kind, value)
    return value


def textual(kind, value):
    if kind in PATTERNS:
        require(re.fullmatch(PATTERNS[kind],value) is not None, 'public lexical domain: '+kind)
        return
    operations = {'startup_limit':startup_limit,'approved_error':literal_error,'body':approved_body,'body_text':approved_body,
                  'proxy_name':proxy_name,'proxy_cluster':stream_enum,'sync_state':stream_enum,'istiod_name':istiod_name,
                  'istio_version':stream_enum,'comparison_state':stream_enum}
    require(kind in operations,'declared public scalar')
    operations[kind](kind,value)


def startup_limit(kind,value):
    require(value=='startup before Docker update was not bounded by this cap','retained startup cap qualification')


def literal_error(kind,value):
    require(value in errors(),'only approved literal failure output')


def stream_enum(kind,value):
    domains = dict(proxy_cluster={'Kubernetes'},sync_state={'SYNCED','STALE','NOT_SENT','ERROR'},
                   istio_version={'1.31.1'},comparison_state={'MATCH','DIFFERENT'})
    require(value in domains[kind], 'closed public stream domain: '+kind)


def proxy_name(kind,value):
    names = {'tool-gateway','action-sink','scope-witness','agent-alpha','agent-untrusted','plaintext-client'}
    require(value in {name+'.agent-tools' for name in names}, 'declared public proxy identity')


def istiod_name(kind,value):
    require(re.fullmatch(r'istiod-[a-z0-9]{1,32}-[a-z0-9]{5}',value) is not None, 'structured Istiod controller identity')


def sync_status(value):
    from policy_gate import normalize_synced_age
    require(isinstance(value,str), 'raw proxy-status producer input')
    rows = value.splitlines()
    require(2 <= len(rows) <= 100 and all(0 < len(row) < 1024 for row in rows), 'bounded complete proxy-status stream')
    columns = list(MODELS['sync_columns']['fields'])
    require(rows[0].split() == columns, 'exact supported proxy-status header')
    result = []
    for row in rows[1:]:
        normalized = re.sub(r'\bSYNCED \(([^()\s]*)\)(?=\s|$)',normalize_synced_age,row)
        fields = normalized.replace('NOT SENT','NOT_SENT').split()
        require(len(fields) == len(columns), 'complete structured proxy-status row')
        result.append(transform('sync_columns',dict(zip(columns,fields)),strict=True))
    require(len({row['NAME'] for row in result}) == len(result), 'unique public proxy-status rows')
    return dict(rows=result,output_sha256=digest(value.encode()))


def sync_comparison(value):
    require(isinstance(value,str), 'raw comparison producer input')
    approved = {name+' '+state:(name,verdict) for name in ['Clusters','Listeners','Routes']
                for state,verdict in [('Match','MATCH'),("Don't Match",'DIFFERENT')]}
    rows = value.splitlines()
    require(len(rows) == 3 and all(row in approved for row in rows), 'complete approved xDS comparison')
    result = dict(approved[row] for row in rows)
    require(set(result) == {'Clusters','Listeners','Routes'}, 'unique xDS comparison domains')
    return dict(result,output_sha256=digest(value.encode()))


def sync_artifact(value):
    return dict(value,status=sync_status(value['status']),comparison=sync_comparison(value['comparison']))


@functools.lru_cache(maxsize=1)
def approved_cases():
    matrix = json.loads(pathlib.Path(__file__).parents[1].joinpath('case-expectations.json').read_text())
    result = [dict(matrix['defaults'],**case) for case in matrix['cases']]
    for group in matrix['IS17']['after_groups']:
        item = dict(matrix['defaults'],id='IS17-after-'+group,layer='accepted',stage='narrow',body_utf8=matrix['IS17']['body_template_utf8'].replace('{group}',group))
        if group == 'IS08':
            item['address'] = 'pod'
        result.append(item)
    return result


def approved_body(kind,value):
    from e2e import body_bytes
    bodies = {body_bytes(case) for case in approved_cases()}
    if kind == 'body_text':
        pieces = {case['body_repeat']['utf8'].encode() for case in approved_cases() if 'body_repeat' in case}
        require(value.encode() in bodies | pieces, 'exact reviewed workload text')
        return
    decoded = base64.b64decode(value,validate=True)
    require(decoded in bodies | approved_replies(), 'exact reviewed body or bounded approved application response')


@functools.lru_cache(maxsize=1)
def approved_replies():
    replies = {b'',b'RBAC: access denied'}
    for error in errors():
        replies.add(json.dumps(dict(error=error),separators=(',',':')).encode())
    for case in approved_cases():
        add_reply(replies,case)
    return replies


def add_reply(replies,case):
    if 'body_utf8' not in case:
        return
    try:
        row = json.loads(case['body_utf8'])
        if isinstance(row,dict) and set(row)=={'tenant_id','resource_id','operation','request_id'}:
            replies.add(json.dumps(row,separators=(',',':')).encode())
    except ValueError:
        pass


def model(spec):
    if isinstance(spec,str) and spec.removeprefix('nullable_') in MODELS:
        return MODELS[spec.removeprefix('nullable_')]
    return spec


def transform(spec, value, strict=False, depth=0):
    require(depth <= 40, 'public schema depth')
    if isinstance(spec,str) and spec.startswith('nullable_') and value is None:
        return value
    shape = model(spec)
    if isinstance(shape,str):
        return scalar(shape,value)
    operations = {'object':object_value,'map':map_value,'array':array_value}
    return operations[shape['type']](shape,value,strict,depth)


def object_value(spec,value,strict,depth):
    require(isinstance(value,dict), 'public object')
    if not strict and spec is MODELS['response'] and 'message' in value:
        value = dict(value,message_sha256=digest(value['message'].encode()))
    require(set(spec['required']) <= set(value), 'required public proof fields')
    if strict:
        require(set(value) <= set(spec['fields']), 'undeclared public object fields')
    return {key:transform(child,value[key],strict,depth+1) for key,child in spec['fields'].items() if key in value}


def map_value(spec,value,strict,depth):
    require(isinstance(value,dict) and len(value)<=spec['maximum'], 'bounded public map')
    for key in value:
        require(re.fullmatch(spec['pattern'],key) is not None, 'public map key')
    return {key:transform(spec['item'],child,strict,depth+1) for key,child in value.items()}


def array_value(spec,value,strict,depth):
    require(isinstance(value,list) and len(value)<=spec['maximum'], 'bounded public array')
    return [transform(spec['item'],child,strict,depth+1) for child in value]


def kind_for(name):
    path = pathlib.PurePosixPath(name)
    if 'pods' in path.parts:
        return 'pod'
    if 'public-certificates' in path.parts:
        return 'cert'
    require(path.name in FILES, 'declared public artifact schema: '+name)
    return FILES[path.name]


def approved_failure(value):
    result = dict(value)
    if 'message' in result and result['message'] not in errors():
        result['message_sha256'] = digest(result.pop('message').encode())
    if 'error' in result and result['error'] not in errors() and not re.fullmatch('[A-Za-z]+Error',result['error']):
        result['message_sha256'] = digest(result.pop('error').encode())
    return result


def commands(value):
    result = dict(value)
    if 'commands' in result:
        result['commands'] = [dict(operation=approved_command(row['argv']),exit=row['exit'],timeout=row['timeout'],start=row['start'],end=row['end'],argv_sha256=digest(json.dumps(row['argv']).encode())) for row in result['commands']]
    if 'errors' in result:
        result['errors'] = [error_proof(item) for item in result['errors']]
    return result


def approved_command(argv):
    require(isinstance(argv,list) and 2<=len(argv)<=30, 'bounded approved command')
    name = pathlib.Path(argv[0]).name
    require(name in {'docker','kubectl','kind','istioctl'}, 'approved evidence command tool')
    require(argv[1] in {'inspect','stop','image','network','volume','--kubeconfig','delete'}, 'approved evidence command operation')
    return name+':'+argv[1]


def versions(value):
    images = {}
    for name,item in value['images'].items():
        config = item['config']
        images[name] = dict(item,architecture=config['architecture'],os=config['os'],rootfs_diff_ids=config['rootfs']['diff_ids'])
    binaries={name:item for name,item in value['binaries'].items() if name in {'kind_official','kind','kubectl','istio'}}
    outputs={name:digest(item.encode()) for name,item in value['binaries'].items() if name in {'kind_version','kubectl_version','istioctl_version'}}
    return dict(value,images=images,binaries=binaries,version_outputs_sha256=outputs)


def node_cap(value):
    limits = value['host_config']
    logs = limits['LogConfig']
    caps = dict(Memory=limits['Memory'],MemorySwap=limits['MemorySwap'],NanoCpus=limits['NanoCpus'],log_driver=logs['Type'],log_max_size=logs['Config']['max-size'],log_max_files=logs['Config']['max-file'])
    return dict(value,caps=caps)


def active_listeners(value):
    from policy_gate import enforced_rules
    return dict(rules=enforced_rules(value))


def mutation(value):
    original = value['mutation']
    return dict(value,mutation_sha256=digest(json.dumps(original,sort_keys=True).encode()),proof=original)


def abort_failure(value):
    return dict(value,outcome=commands(value['outcome']),errors=[error_proof(item) for item in value['errors']])


def error_proof(value):
    require(isinstance(value,str) and len(value) <= 1048576, 'bounded original failure message')
    result = dict(message_sha256=digest(value.encode()))
    if value in errors():
        result['message'] = value
    return result


def adapt(name,value,raw):
    kind = kind_for(name)
    operations = {'nodecap':node_cap,'listeners':active_listeners,'routegate':route_gate,'mutation':mutation,
                  'failure':approved_failure,'cleanup':commands,'abortfailure':abort_failure,'sync':sync_artifact}
    if kind == 'build':
        value = dict(value,image_id=value['image']['Id'],image_size=value['image']['Size'],rootfs_diff_ids=value['image']['RootFS']['Layers'])
    elif kind == 'versions':
        value = versions(value)
    elif kind == 'proofhash':
        value = dict(original_sha256=digest(raw))
    elif isinstance(kind,str) and kind in operations:
        value = operations[kind](value)
    return transform(kind,value)


def route_gate(value):
    result = dict(value)
    if result.get('accepted') is not None:
        accepted = dict(result['accepted'])
        proof = dict(accepted['proof'])
        proof['selected_sha256'] = digest(json.dumps(proof['selected'],sort_keys=True).encode())
        accepted['proof'] = proof
        result['accepted'] = accepted
    result['attempts'] = [approved_failure(row) for row in result.get('attempts',[])]
    return result


def source_pin(name,raw):
    manifest = json.loads(pathlib.Path(__file__).parents[1].joinpath('SOURCE_MANIFEST.json').read_text())
    require(name in manifest['files'], 'declared public source file')
    if digest(raw) == manifest['files'][name]:
        return
    require(name in {'source/istio-install.json','source/workloads.json'}, 'exact public source bytes')
    validate_rendered(name,raw)


def validate_rendered(name,raw):
    import render
    value = json.loads(raw)
    class Capture:
        def __init__(self):
            self.result = None
        def save(self,root,filename,data):
            self.result = data
            return data
    capture = Capture()
    original = render.save
    try:
        render.save = capture.save
        rendered(capture,name,value,render)
    finally:
        render.save = original
    require(capture.result == value, 'exact authored rendered public manifest shape')


def rendered(capture,name,value,render):
    if name.endswith('workloads.json'):
        pods = [item for item in value['items'] if item['kind']=='Pod']
        image = pods[0]['spec']['containers'][0]['image']
        proxy = pods[0]['metadata']['annotations']['sidecar.istio.io/proxyImage']
        scalar('image',image)
        scalar('image',proxy)
        render.workloads(None,image,proxy)
    else:
        images = value['spec']['values']
        proxy = images['global']['proxy']['image']
        pilot = images['pilot']['image']
        scalar('image',proxy)
        scalar('image',pilot)
        render.install(None,dict(images=dict(proxy=dict(image=proxy),pilot=dict(image=pilot))))


def project(name,raw):
    if name.startswith('source/') or name == 'case-expectations.json':
        source_pin(name,raw)
        return raw
    if name.endswith('request-body.bin'):
        value = dict(original_sha256=digest(raw))
        kind = 'proofhash'
    else:
        value = json.loads(raw) if not name.endswith('.jsonl') else [json.loads(line) for line in raw.splitlines()]
        kind = kind_for(name)
        value = adapt(name,value,raw)
    result = dict(schema='istio-public-evidence-v1',path=name,original_sha256=digest(raw),data=value)
    return (json.dumps(result,sort_keys=True,indent=2)+'\n').encode()


def validate(name,raw):
    if name.startswith('source/') or name == 'case-expectations.json':
        source_pin(name,raw)
        return
    value = json.loads(raw)
    require(set(value)=={'schema','path','original_sha256','data'}, 'exact public projection envelope')
    require(value['schema']=='istio-public-evidence-v1' and value['path']==name, 'public projection identity')
    scalar('hash',value['original_sha256'])
    kind = 'proofhash' if name.endswith('request-body.bin') else kind_for(name)
    forbidden(value['data'])
    transform(kind,value['data'],strict=True)
    semantic(kind,value['data'])


def forbidden(value):
    if isinstance(value,dict):
        banned={'Config','HostConfig','Env','host_config','Binds','cert','certificate','private_key','approval','approved','actor','argv','cwd','environment'}
        require(not set(value)&banned,'raw private evidence fields forbidden')
        for child in value.values():
            forbidden(child)
    elif isinstance(value,list):
        for child in value:
            forbidden(child)
    elif isinstance(value,str):
        require(not any(item in value for item in ['/Users/','/private/','BEGIN CERTIFICATE','BEGIN PRIVATE KEY','--operator-config','--launcher-authorization']),'private command/certificate text forbidden')


def ledger(value):
    encoded=json.dumps(value['rows'],separators=(',',':'),sort_keys=True).encode()
    require(value['count']==len(value['rows']) and value['sha256']==digest(encoded),'public ledger count/hash proof')


def semantic(kind,value):
    if kind == 'nodecap':
        limits = value['caps']
        require((limits['Memory'],limits['MemorySwap'],limits['NanoCpus'])==(8589934592,8589934592,3000000000),'retained exact node caps')
        require((limits['log_driver'],limits['log_max_size'],limits['log_max_files'])==('json-file','4m','2'),'retained exact log caps')
    if kind == 'observation':
        ledger(value['before']['ledger'])
        ledger(value['after']['ledger'])
    if kind == 'case':
        require(value in approved_cases(),'exact reviewed case semantics')
    if kind == 'mutation':
        require(value['checker_only'] is True and value['rejected'] is True,'retained negative checker proof')
    if kind == 'sync':
        rows = value['status']['rows']
        require(1 <= len(rows) <= 99, 'nonempty bounded structured proxy-status evidence')
        require(len({row['NAME'] for row in rows}) == len(rows), 'unique structured proxy-status evidence')


def schema_document():
    return dict(schema='istio-public-projection-schema-v1',models=MODELS,artifacts=FILES,lexical_domains=PATTERNS,
                static_sources='Exact current SOURCE_MANIFEST or exact render output shape',
                command_output='Closed structured proxy-status/comparison with original stream SHA; literal reviewed assertion output only; no raw argv or environment',
                unknown_public_fields='REJECT',producer_unknown_private_fields='OMIT',source_only=True)
