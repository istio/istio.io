import argparse
import base64
import copy
import json
import math
import pathlib
import time
from context import Context
from pod_route import wait_route
from policy_gate import policy_specs, wait_gate, remaining
from evidence import Recorder, digest, gst, load, save
from verify import require, verify, check_is21_step, check_is21_end


def body_bytes(case):
    if "body_repeat" in case:
        repeat = case["body_repeat"]
        return (repeat["utf8"] * repeat["count"]).encode()
    return case["body_utf8"].encode()


def proxy_lines(context, pod, correlation):
    raw = context.kubectl(["logs", "-n", "agent-tools", pod, "-c", "istio-proxy"]).stdout
    parsed = []
    for line in raw.splitlines():
        if not line.startswith(b"{"):
            continue
        item = json.loads(line)
        if item.get("correlation") == correlation:
            parsed.append(item)
    return parsed


def target_gate_deadline(previous, matrix):
    """Cap target diagnostics by the existing monotonic context and matrix bounds."""
    require(type(matrix) in {int, float} and math.isfinite(matrix), "required monotonic matrix deadline malformed")
    require(previous is None or type(previous) in {int, float} and math.isfinite(previous), "carried monotonic context deadline malformed")
    deadline = min(time.monotonic() + 60, matrix)
    if previous is not None:
        deadline = min(deadline, previous)
    remaining(deadline)
    return deadline


class Suite:
    def __init__(self, context, matrix, source_hash, resource_guard):
        resource_guard()
        self.resource_guard = resource_guard
        self.context = context
        self.matrix = matrix
        self.source_hash = source_hash
        self.pods = context.pods()
        self.results = []
        self.deadline = time.monotonic() + 900

    def snapshot(self):
        result = {}
        for role in ("tool-gateway", "action-sink", "scope-witness"):
            pod = self.pods[role]["metadata"]["name"]
            raw = self.context.exec(pod, ["python", "/app/observer.py", "audit", "/data/audit.jsonl"]).stdout
            result[role] = json.loads(raw)
        sink = self.pods["action-sink"]["metadata"]["name"]
        result["ledger"] = json.loads(self.context.exec(sink, ["python", "/app/observer.py", "ledger", "/data/ledger.sqlite"]).stdout)
        return result

    def resolve(self, case):
        pod = self.pods[case["destination"]]
        if case["address"] == "pod":
            return pod["status"]["podIP"]
        return case["destination"] + ".agent-tools.svc.cluster.local"

    def call(self, case, root):
        self.resource_guard()
        require(time.monotonic() < self.deadline, "15 minute matrix deadline")
        raw = body_bytes(case)
        correlation = case["id"]
        if case["id"].startswith("IS21"):
            correlation = json.loads(raw)["request_id"]
        headers = dict(case.get("headers", {}))
        headers.update({"Content-Type": case["content_type"], "X-Lab-Request-ID": correlation})
        spec = dict(host=self.resolve(case), method=case["method"], target=case["target"],
                    headers=headers, body_base64=base64.b64encode(raw).decode())
        save(root, "request.json", spec)
        (root / "request-body.bin").write_bytes(raw)
        if case["address"] == "pod" and case["source"] != "plaintext-client":
            before = self.pod_route_gate(case, root)
        else:
            before = self.snapshot()
        source = self.pods[case["source"]]
        encoded = base64.b64encode(json.dumps(spec).encode()).decode()
        response = json.loads(self.context.exec(source["metadata"]["name"], ["python", "/app/client.py", encoded]).stdout)
        after = self.snapshot()
        observation = self.observation(case, correlation, response, before, after)
        save(root, "observation.json", observation)
        save(root, "case.json", case)
        try:
            result = verify(case, observation, self.matrix["layers"], self.source_hash)
        except AssertionError as error:
            result = dict(id=case["id"], status="FAILED", error=str(error), actual=response)
        save(root, "comparison.json", result)
        self.results.append(result)
        save(self.context.root, "assertions.json", self.results)
        return result

    def pod_route_gate(self, case, root):
        previous = self.context.deadline
        deadline = min(time.monotonic() + 60, self.deadline, previous if previous is not None else float("inf"))
        self.context.deadline = deadline
        try:
            before = self.snapshot()
            gate = wait_route(self.context, self.pods[case["source"]], self.pods[case["destination"]], root, deadline)
            after = self.snapshot()
            require(after == before, "read-only literal PodIP gate changed full audit/ledger snapshot")
            remaining(deadline)
            gate["read_only_snapshot"] = dict(before=before, after=after)
            save(root, "pod-route-gate.json", gate)
            return before
        finally:
            self.context.deadline = previous

    def observation(self, case, correlation, response, before, after):
        destination = self.pods[case["destination"]]
        proxy = proxy_lines(self.context, destination["metadata"]["name"], correlation)
        sink_pod = self.pods["action-sink"]["metadata"]["name"]
        sink_proxy = proxy_lines(self.context, sink_pod, correlation)
        return dict(correlation=correlation, source_hash=self.source_hash, response=response,
                    before=before, after=after, proxy=proxy, sink_proxy=sink_proxy,
                    source=self.pods[case["source"]], destination=destination, readback=gst())

    def run_case(self, raw, root=None):
        case = dict(self.matrix["defaults"])
        case.update(raw)
        location = root or self.context.root / "cases" / case["id"]
        location.mkdir(parents=True, exist_ok=True)
        return self.call(case, location)

    def liveness(self, group):
        control = self.matrix["IS17"]
        case = dict(id="IS17-after-" + group, layer="accepted", stage="narrow",
                    body_utf8=control["body_template_utf8"].replace("{group}", group))
        if group == "IS08":
            case["address"] = "pod"
        self.run_case(case)

    def policy(self, name):
        self.context.mutate(["apply", "-f", str(self.context.root.parent.parent / "source/policies" / (name + ".json"))])

    def narrow_gate(self, present, root):
        previous = self.context.deadline
        deadline = target_gate_deadline(previous, self.deadline)
        self.context.deadline = deadline
        try:
            inventory = self.context.obj(["get", "authorizationpolicies", "-n", "agent-tools"], timeout=remaining(deadline))
            retained = policy_specs(inventory["items"])
            retained.pop("gateway-alpha-followups", None)
            pod = self.pods["tool-gateway"]["metadata"]["name"]
            gate = wait_gate(self.context, pod, present, root, retained, deadline=deadline)
            remaining(deadline)
            return gate
        finally:
            self.context.deadline = previous

    def run_stages(self):
        for stage in ("strict-only", "gateway-empty", "narrow"):
            self.prepare_stage(stage)
            self.run_stage(stage)

    def prepare_stage(self, stage):
        if stage == "gateway-empty":
            self.policy("gateway-allow-nothing")
            self.narrow_gate(False, self.context.root / "runtime/gateway-empty")
        if stage == "narrow":
            for name in ("sink-allow-nothing", "sink-gateway-effects", "gateway-alpha-followups"):
                self.policy(name)
            self.sink_gate()
            self.narrow_gate(True, self.context.root / "runtime/narrow")

    def sink_gate(self):
        previous = self.context.deadline
        deadline = target_gate_deadline(previous, self.deadline)
        self.context.deadline = deadline
        try:
            inventory = self.context.obj(["get", "authorizationpolicies", "-n", "agent-tools"], timeout=remaining(deadline))
            retained = policy_specs(inventory["items"])
            retained.pop("gateway-alpha-followups", None)
            pod = self.pods["action-sink"]["metadata"]["name"]
            target = dict(policy="sink-gateway-effects", principal="cluster.local/ns/agent-tools/sa/tool-gateway", path="/effects")
            wait_gate(self.context, pod, True, self.context.root / "runtime/sink-narrow", retained, target, deadline=deadline)
            remaining(deadline)
        finally:
            self.context.deadline = previous

    def run_stage(self, stage):
        cases = [x for x in self.matrix["cases"] if x["stage"] == stage]
        for index, case in enumerate(cases):
            self.run_case(case)
            group = case["id"].split("-")[0]
            next_group = ""
            if index + 1 < len(cases):
                next_group = cases[index + 1]["id"].split("-")[0]
            if group in self.matrix["IS17"]["after_groups"] and group != next_group:
                self.liveness(group)

    def revocation(self):
        root = self.context.root / "cases/IS21"
        root.mkdir(parents=True, exist_ok=True)
        path = self.context.root.parent.parent / "source/policies/gateway-alpha-followups.json"
        original = path.read_bytes()
        state = self.revocation_baseline(path, root)
        cases = {item["id"]: item for item in self.matrix["cases"]}
        pod = self.pods["tool-gateway"]["metadata"]["name"]
        self.gate_snapshot(pod, True, root / "baseline-gate", state)
        self.revocation_step(cases["IS21-step1"], root / "step1", state)
        self.revoke_only(state, root)
        try:
            self.gate_snapshot(pod, False, root / "revoked-gate", state)
            self.revocation_step(cases["IS21-step2"], root / "step2", state)
        finally:
            require(path.read_bytes() == original, "restore authored bytes changed")
            self.policy("gateway-alpha-followups")
            save(root, "restoration-receipt.json", dict(time=gst(), authored_hash=digest(original)))
        self.gate_snapshot(pod, True, root / "restored-gate", state)
        live = self.context.obj(["get", "authorizationpolicy", "gateway-alpha-followups", "-n", "agent-tools"])
        require(live["spec"] == state["narrow"], "restored exact live spec")
        save(root, "restored-object.json", live)
        self.revocation_step(cases["IS21-step3"], root / "step3", state)
        require(self.snapshot() == state["snapshot"], "IS21 full final readback continuity")
        check_is21_end(state["initial"], state["snapshot"], cases["IS21-step1"], cases["IS21-step3"])
        save(root, "final-continuity.json", state)

    def revocation_baseline(self, path, root):
        inventory = self.context.obj(["get", "authorizationpolicies", "-n", "agent-tools"])
        retained = policy_specs(inventory["items"])
        narrow = retained.pop("gateway-alpha-followups")
        require(narrow == load(path)["spec"], "original narrow spec equals authored manifest")
        strict = self.context.obj(["get", "peerauthentication", "namespace-strict", "-n", "agent-tools"])
        require(strict["spec"] == dict(mtls=dict(mode="STRICT")), "original namespace STRICT without exceptions")
        pods = self.context.pods()
        require(pod_identities(pods) == pod_identities(self.pods), "original suite pod identities retained")
        snapshot = self.snapshot()
        state = dict(initial=snapshot, snapshot=snapshot, pods=pod_identities(pods), strict=strict,
                     retained=retained, narrow=narrow, inventory=inventory)
        save(root, "baseline-inventory.json", inventory)
        save(root, "authored-manifest.json", load(path))
        save(root, "continuity-baseline.json", state)
        return state

    def revocation_step(self, case, root, state):
        self.check_revocation_state(state)
        self.check_narrow_inventory(case["layer"] == "accepted", state)
        require(self.snapshot() == state["snapshot"], "IS21 snapshot changed before request")
        result = self.run_case(case, root)
        require(result["status"] == "PASSED", "IS21 step assertion failed; no continuation")
        observation = load(root / "observation.json")
        check_is21_step(state["snapshot"], observation, case)
        self.check_revocation_state(state)
        self.check_narrow_inventory(case["layer"] == "accepted", state)
        state["snapshot"] = observation["after"]

    def revoke_only(self, state, root):
        current = self.context.obj(["get", "authorizationpolicy", "gateway-alpha-followups", "-n", "agent-tools"])
        saved = [item for item in state["inventory"]["items"] if item["metadata"]["name"] == "gateway-alpha-followups"][0]
        require(current["metadata"]["uid"] == saved["metadata"]["uid"], "owned policy identity before delete")
        require(current["spec"] == state["narrow"], "owned original policy spec before delete")
        self.context.mutate(["delete", "authorizationpolicy", "gateway-alpha-followups", "-n", "agent-tools", "--wait=true"])
        save(root, "deletion-receipt.json", dict(time=gst(), object="agent-tools/gateway-alpha-followups"))

    def check_revocation_state(self, state):
        require(pod_identities(self.context.pods()) == state["pods"], "original pod UIDs/endpoints retained across IS21")
        strict = self.context.obj(["get", "peerauthentication", "namespace-strict", "-n", "agent-tools"])
        require(strict["metadata"]["uid"] == state["strict"]["metadata"]["uid"], "original STRICT identity retained")
        require(strict["spec"] == state["strict"]["spec"], "original STRICT spec retained across IS21")

    def gate_snapshot(self, pod, present, root, state):
        previous = self.context.deadline
        deadline = target_gate_deadline(previous, self.deadline)
        self.context.deadline = deadline
        try:
            self.gate_snapshot_body(pod, present, root, state, deadline)
            remaining(deadline)
        finally:
            self.context.deadline = previous

    def gate_snapshot_body(self, pod, present, root, state, deadline):
        self.check_revocation_state(state)
        before = self.snapshot()
        require(before == state["snapshot"], "IS21 full snapshot continuity before gate")
        self.check_narrow_inventory(present, state)
        gate = wait_gate(self.context, pod, present, root, state["retained"], deadline=deadline)
        after = self.snapshot()
        require(after == state["snapshot"], "read-only gate changed carried full audit/ledger snapshot")
        self.check_revocation_state(state)
        self.check_narrow_inventory(present, state)
        require(time.monotonic() < deadline, "IS21 complete read-only gate absolute deadline")
        save(root, "read-only-ledger.json", dict(before=before, after=after, gate=gate))

    def check_narrow_inventory(self, present, state):
        inventory = self.context.obj(["get", "authorizationpolicies", "-n", "agent-tools"])
        actual = policy_specs(inventory["items"])
        expected = dict(state["retained"])
        if present:
            expected["gateway-alpha-followups"] = state["narrow"]
        require(actual == expected, "original retained/narrow specs across IS21")

    def mutation_controls(self):
        observation = load(self.context.root / "cases/IS06-untrusted/observation.json")
        case = load(self.context.root / "cases/IS06-untrusted/case.json")
        controls = ("wrong-status", "denied-row-added", "missing-peer", "source-hash")
        for name in controls:
            changed = copy.deepcopy(observation)
            layers = copy.deepcopy(self.matrix["layers"])
            mutate_control(name, changed)
            if name == "wrong-status":
                layers["mesh-denied"]["status"] = 201
                changed = copy.deepcopy(observation)
            failed = False
            try:
                verify(case, changed, layers, self.source_hash)
            except AssertionError:
                failed = True
            require(failed, "verifier mutation accepted: " + name)
            save(self.context.root, "cases/IS18/" + name + ".json", dict(checker_only=True, rejected=failed, mutation=changed))


def mutate_control(name, changed):
    if name == "wrong-status":
        changed["response"]["status"] = 201
    if name == "denied-row-added":
        changed["after"]["ledger"]["rows"].append(dict(request_id="unexpected"))
    if name == "missing-peer":
        changed["proxy"][0]["peer"] = ""
    if name == "source-hash":
        changed["source_hash"] = "0" * 64


def pod_identities(pods):
    return {name: dict(uid=pod["metadata"]["uid"], ip=pod["status"]["podIP"]) for name, pod in pods.items()}


def main():
    raise SystemExit(2)


def wrong_context_control(context):
    wrong = dict(context.config)
    wrong["context"] = context.context + "-wrong"
    probe = Context(context.root, wrong, context.recorder)
    failed = False
    try:
        probe.guard_file()
    except AssertionError:
        failed = True
    require(failed, "wrong owned context must fail before mutation")
    save(context.root, "runtime/wrong-context-control.json", dict(rejected=True, mutated=False, wrong_context=wrong["context"]))


if __name__ == "__main__":
    main()
