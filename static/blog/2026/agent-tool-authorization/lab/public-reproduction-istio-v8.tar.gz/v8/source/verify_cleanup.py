import argparse
import pathlib
from prepare import host_guard
from evidence import Recorder, gst, load, save
from verify import require


def verify_cleanup(root, expected, monitor=None):
    require(monitor is not None, "final verify_cleanup requires guarded serial lifecycle")
    host_guard(expected)
    owner = load(root / "ownership.json")
    recorder = Recorder(root / "cleanup-verification", supervisor=monitor)
    volumes = []
    for run in owner["runs"]:
        path = root / "runs" / run["id"] / "runtime/owned-node.json"
        if path.exists():
            for volume in load(path)["volumes"]:
                missing(recorder, ["docker", "volume", "inspect", volume], "no such volume")
                volumes.append(volume)
    for run in owner["runs"]:
        missing(recorder, ["docker", "inspect", "--format", "{{.Id}}", run["node"]], "no such object")
        missing(recorder, ["docker", "network", "inspect", run["network"]], "not found")
    recorder.check_guard()
    return save(root, "cleanup-verification.json", dict(time=gst(), nodes_absent=True, networks_absent=True, owned_volumes_absent=volumes,
                                                        second_cluster_never_created=never_created(root, owner["runs"][1])))


def never_created(root, run):
    owned = root / "runs" / run["id"] / "runtime/owned-node.json"
    if owned.exists():
        return False
    if (root / "runs" / run["id"] / "runtime/owned-network.json").exists():
        return None
    path = root / "run-ownership.json"
    if not path.exists():
        return None
    state = load(path)["runs"][run["id"]]
    if state == "NOT_STARTED":
        return True
    return None


def missing(recorder, arguments, expected):
    result = recorder.run(arguments, check=False)
    require(result.returncode == 1 and expected in result.stderr.decode().lower(), "exact owned absence not established")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("expected_hostname")
    args = parser.parse_args()
    print(verify_cleanup(args.root, args.expected_hostname))


if __name__ == "__main__":
    main()
