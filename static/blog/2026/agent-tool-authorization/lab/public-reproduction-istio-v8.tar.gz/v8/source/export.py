import argparse
import pathlib
import tarfile
import re
import io
import os
import tempfile
from evidence import digest, gst, save, load
from verify import require
from public_projection import project, validate

ROOT_FILES = {"ownership.json", "case-expectations.json", "preflight-initial.json", "preflight.json", "versions.lock.json",
              "disk-projection.json", "build.json", "runtime-source-binding.json", "owned-images.json", "owned-node-index.json",
              "node-index-pre-pull.json", "run-ownership.json", "cleanup.json", "cleanup-verification.json", "final-export-receipt.json", "resource-samples.jsonl",
              "resource-stop.json", "resource-abort.json", "resource-abort-failure.json"}
SOURCE_FILES = {"Dockerfile", "app.py", "validation.py", "client.py", "observer.py", "records.py", "evidence.py", "context.py",
                "verify.py", "policy_gate.py", "pod_route.py", "e2e.py", "prepare.py", "resources.py", "render.py", "runtime.py", "export.py",
                "verify_export.py", "inspect_runtime.py", "show_rbac.py", "checker_controls.py", "finish_runtime.py",
                "verify_cleanup.py", "delete_staging.py", "process_guard.py", "public_projection.py", "public-evidence-schema.json", "dependencies.lock.json", "istio-install.json", "workloads.json"}
POLICY_FILES = {"namespace-strict.json", "gateway-allow-nothing.json", "gateway-alpha-followups.json", "sink-allow-nothing.json", "sink-gateway-effects.json"}
RUN_FILES = {"preflight.json", "results.json", "assertions.json", "failure.json", "cleanup.json", "export-receipt.json", "IS20-before-export.json", "resource-stop.json", "resource-abort.json", "resource-abort-failure.json", "resource-samples.jsonl", "monitor-teardown.json"}
CASE_FILES = {"case.json", "request.json", "request-body.bin", "observation.json", "comparison.json", "baseline-inventory.json",
              "authored-manifest.json", "deletion-receipt.json", "restoration-receipt.json", "restored-object.json", "read-only-ledger.json",
              "policies.json", "active-listeners.json", "sync.json", "gate.json", "error.json", "continuity-baseline.json", "final-continuity.json",
              "pod-route-gate.json", "wrong-status.json", "denied-row-added.json", "missing-peer.json", "source-hash.json"}
RUNTIME_FILES = {"node-cap.json", "owned-node.json", "owned-network.json", "kubernetes-version.json", "nodes.json", "istio-version.json",
                 "services.json", "endpoints.json", "podip-routes.json", "podip-route-binding.json", "context-identity.json", "wrong-context-control.json", "active-listeners.json", "policies.json", "sync.json", "gate.json", "error.json"}


def selected(root, path):
    parts = path.relative_to(root).parts
    if not path.is_file():
        return False
    if len(parts) == 1:
        return parts[0] in ROOT_FILES
    if parts[0] == "source":
        return source_file(parts)
    if len(parts) >= 3 and parts[0] == "runs":
        runs = {run["id"] for run in load(root / "ownership.json")["runs"]}
        return parts[1] in runs and run_file(parts[2:])
    return False


def source_file(parts):
    if len(parts) == 2:
        return parts[1] in SOURCE_FILES
    return len(parts) == 3 and parts[1] == "policies" and parts[2] in POLICY_FILES


def run_file(parts):
    if len(parts) == 1:
        return parts[0] in RUN_FILES
    if parts[0] == "cases":
        return case_file(parts)
    if parts[0] == "runtime":
        return runtime_file(parts[1:])
    return False


def runtime_file(parts):
    if len(parts) == 1:
        return parts[0] in RUNTIME_FILES
    if len(parts) == 2 and parts[0] in {"pods", "public-certificates"}:
        return parts[1] in {name + ".json" for name in ("tool-gateway", "action-sink", "scope-witness", "agent-alpha", "agent-untrusted", "plaintext-client")}
    return gate_file(parts)


def gate_file(parts):
    if parts[0] not in {"gateway-empty", "narrow", "sink-narrow", "baseline-gate", "revoked-gate", "restored-gate"}:
        return False
    if len(parts) == 3:
        if not re.fullmatch(r"attempt-\d{3}", parts[1]):
            return False
    elif len(parts) != 2:
        return False
    return parts[-1] in {"active-listeners.json", "policies.json", "sync.json", "gate.json", "error.json", "read-only-ledger.json", "listener-stats.json"}


def case_file(parts):
    if not re.fullmatch(r"IS(?:0[1-9]|1[0-9]|2[01])(?:-[a-zA-Z0-9_-]+)?", parts[1]):
        return False
    if len(parts) == 3:
        return parts[-1] in CASE_FILES
    if parts[1] != "IS21":
        return False
    if len(parts) == 4 and parts[2] in {"step1", "step2", "step3"}:
        return parts[-1] in {"case.json", "request.json", "request-body.bin", "observation.json", "comparison.json"}
    return gate_file(parts[2:])


def export(root, run_id, monitor=None):
    check_monitor(monitor)
    files = [path for path in sorted(root.rglob("*")) if selected(root, path)]
    require(not any(path.is_symlink() for path in files), "no symlink export")
    total = sum(path.stat().st_size for path in files)
    require(total < 1024 ** 3, "1 GiB evidence ceiling")
    snapshot = export_snapshot(root, files)
    total = sum(len(raw) for raw in snapshot.values())
    require(total < 1024 ** 3, 'snapshot evidence ceiling')
    manifest = {name: digest(raw) for name, raw in snapshot.items()}
    save(root, "export-manifest-" + run_id + ".json", dict(files=manifest, bytes=total, time=gst()))
    destination = root / ("evidence-" + run_id + ".tar.gz")
    require(not destination.exists() and not destination.is_symlink(), "new export destination")
    publish_archive(root, run_id, destination, snapshot, monitor)
    check_monitor(monitor)
    save(root, "export-archive-" + run_id + ".json", dict(archive=destination.name, sha256=digest(destination.read_bytes()), bytes=destination.stat().st_size))


def check_monitor(monitor):
    if monitor is not None:
        monitor.check()


def write_archive(output, root, run_id, snapshot, monitor):
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for name, raw in snapshot.items():
            check_monitor(monitor)
            member = tarfile.TarInfo(name)
            member.size = len(raw)
            member.mode = 0o600
            archive.addfile(member, io.BytesIO(raw))
        archive.add(root / ("export-manifest-" + run_id + ".json"), arcname="export-manifest-" + run_id + ".json")


def publish_archive(root, run_id, destination, snapshot, monitor):
    with tempfile.NamedTemporaryFile(prefix=".unpublished-" + run_id + "-", suffix=".tar.gz", dir=root, delete=False) as output:
        temporary = pathlib.Path(output.name)
        write_archive(output, root, run_id, snapshot, monitor)
        output.flush()
        os.fsync(output.fileno())
    check_monitor(monitor)
    require(not destination.exists() and not destination.is_symlink(), "new export destination at publication")
    os.link(temporary, destination)
    temporary.unlink()
    directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def export_snapshot(root, files):
    result = {}
    for path in files:
        with path.open('rb') as source:
            raw = source.read(16777217)
        require(len(raw) <= 16777216, 'single export file ceiling')
        name = str(path.relative_to(root))
        projected = project(name, raw)
        validate(name, projected)
        result[name] = projected
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("run_id")
    args = parser.parse_args()
    export(args.root, args.run_id)


if __name__ == "__main__":
    main()
