import base64
import http.client
import json
import sys
from records import gst


def request(spec):
    connection = http.client.HTTPConnection(spec["host"], 8080, timeout=10)
    result = dict(sent=gst(), status=None, error=None, body_base64="")
    body = base64.b64decode(spec["body_base64"])
    headers = dict(spec["headers"])
    headers["Connection"] = "close"
    try:
        connection.request(spec["method"], spec["target"], body, headers)
        response = connection.getresponse()
        raw = response.read(1048577)
        if len(raw) > 1048576:
            raise ValueError("response over 1 MiB")
        result.update(status=response.status, headers=response.getheaders(),
                      body_base64=base64.b64encode(raw).decode())
    except (OSError, http.client.HTTPException) as error:
        result.update(error=type(error).__name__, message=str(error))
    finally:
        connection.close()
    result["completed"] = gst()
    return result


def main():
    spec = json.loads(base64.b64decode(sys.argv[1]))
    print(json.dumps(request(spec)))


if __name__ == "__main__":
    main()
