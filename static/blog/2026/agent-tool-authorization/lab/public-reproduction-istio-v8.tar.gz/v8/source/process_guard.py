"""Linux UID/start/pidfd ownership and registration before child execution."""

import ctypes
import os
import pathlib
import signal
import time
import threading
import select
import subprocess
import sys
from evidence import raise_errors
from verify import require


def remaining(deadline, bound):
    value = min(bound, deadline - time.monotonic())
    require(value > 0, 'original lifecycle deadline exhausted')
    return value


def records():
    result = {}
    for path in pathlib.Path('/proc').glob('[0-9]*/stat'):
        try:
            result[int(path.parent.name)] = process_record(path)
        except FileNotFoundError:
            require(not path.parent.exists(), 'missing process identity observation')
            continue
    return result


def directory_uid(path):
    return path.stat().st_uid


def uid_record(path):
    rows = [line.split()[1:] for line in path.read_text().splitlines() if line.startswith('Uid:')]
    require(len(rows) == 1 and len(rows[0]) == 4, 'strict process UID observation')
    require(all(value.isdecimal() for value in rows[0]), 'numeric process UID observation')
    return tuple(map(int, rows[0]))


def process_record(path):
    first = path.read_text().rsplit(')', 1)[1].split()
    uid = uid_record(path.with_name('status'))
    second = path.read_text().rsplit(')', 1)[1].split()
    require(first[19] == second[19], 'stable process start observation')
    require(uid == uid_record(path.with_name('status')), 'stable process UID observation')
    require(directory_uid(path.parent) == uid[1], 'process directory UID binding')
    return dict(parent=int(second[1]), group=int(second[2]), state=second[0], start=int(second[19]), uid=uid)


class SpawnGate:
    def __init__(self, argv, deadline, **kwargs):
        self.deadline = deadline
        self.writer = None
        remaining(deadline, 1)
        reader, writer = os.pipe()
        self.writer = writer
        try:
            remaining(deadline, 1)
            command = [sys.executable, '-B', str(pathlib.Path(__file__).absolute()), '_gate', str(reader), str(deadline), *argv]
            self.process = subprocess.Popen(command, start_new_session=True, pass_fds=(reader,), **kwargs)
        except BaseException:
            self.close()
            raise
        finally:
            os.close(reader)

    def permit(self):
        remaining(self.deadline, 1)
        require(os.write(self.writer, b'1') == 1, 'owned child execution permission')
        self.close()

    def close(self):
        if self.writer is not None:
            os.close(self.writer)
            self.writer = None


def gated_exec(arguments):
    require(len(arguments) >= 4 and arguments[0] == '_gate', 'exact child execution gate')
    descriptor, deadline = int(arguments[1]), float(arguments[2])
    try:
        ready, _, _ = select.select([descriptor], [], [], remaining(deadline, 1e9))
        require(bool(ready) and os.read(descriptor, 1) == b'1', 'child registration not completed')
    finally:
        os.close(descriptor)
    remaining(deadline, 1)
    os.execvpe(arguments[3], arguments[3:], os.environ)


def descendants(table, parent):
    selected = {parent}
    while True:
        expanded = selected | {pid for pid, row in table.items() if row['parent'] in selected}
        if expanded == selected:
            return selected - {parent}
        selected = expanded


def synchronized(call):
    def locked(self, *args):
        with self.lock:
            return call(self, *args)
    return locked


class Owner:
    def __init__(self, deadline):
        self.lock = threading.RLock()
        self.deadline = deadline
        self.pid = os.getpid()
        self.held = {}
        self.roots = {}
        table = records()
        require(self.pid in table, 'supervisor UID identity observation')
        self.uid = table[self.pid]['uid']
        require(self.uid == (os.getuid(), os.geteuid(), os.geteuid(), os.geteuid()), 'supported supervisor UID identity')
        require(not descendants(table, self.pid), 'supervisor begins without unowned children')
        require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'required Linux child subreaper')

    @synchronized
    def refresh(self):
        table = records()
        require(table[self.pid]['uid'] == self.uid, 'supervisor UID identity drift')
        for pid, old in self.held.items():
            current = table.get(pid)
            if current is not None and current['start'] == old['start']:
                require(current['uid'] == old['uid'], 'owned process UID identity drift')
        for pid in descendants(table, self.pid):
            row = table[pid]
            old = self.held.get(pid)
            require(row['uid'] == self.uid, 'owned descendant UID identity')
            require(old is None or old['start'] == row['start'], 'owned PID identity was recycled')
            if old is None:
                self.hold(pid,row)
        return table

    def hold(self,pid,row):
        try:
            fd = os.pidfd_open(pid)
        except ProcessLookupError:
            require(pid not in records(),'vanished owned PID absence')
            return
        current = records().get(pid)
        if current is None:
            os.close(fd)
            return
        try:
            require(current['start']==row['start'],'pidfd start-time binding')
            require(current['uid'] == row['uid'] == self.uid, 'pidfd UID identity binding')
            self.held[pid] = dict(current,fd=fd)
        except BaseException:
            os.close(fd)
            raise

    @synchronized
    def track(self, process):
        require(process.pid not in self.roots, 'fresh spawned child identity')
        self.roots[process.pid] = process

    @synchronized
    def register(self, process):
        self.roots[process.pid] = process
        self.refresh()

    @synchronized
    def live(self):
        table = self.refresh()
        return {pid for pid, row in self.held.items() if table.get(pid, {}).get('start') == row['start'] and table[pid]['state'] != 'Z'}

    @synchronized
    def signal(self, selected, number):
        for pid in selected:
            try:
                signal.pidfd_send_signal(self.held[pid]['fd'], number)
            except ProcessLookupError:
                pass

    @synchronized
    def stop_all(self):
        errors = []
        self.stop_roots(errors)
        self.attempt(self.refresh, errors)
        self.attempt(lambda: self.signal(set(self.held), signal.SIGTERM), errors)
        self.attempt(self.wait_owned, errors)
        self.attempt(lambda: self.signal(set(self.held), signal.SIGKILL), errors)
        self.drain_roots(errors)
        self.attempt(self.wait_owned, errors)
        self.attempt(self.stopped, errors)
        raise_errors(errors)

    def attempt(self, call, errors):
        try:
            return call()
        except Exception as error:
            errors.append(error)

    def stop_roots(self, errors):
        for process in tuple(self.roots.values()):
            if process.poll() is None:
                self.attempt(process.terminate, errors)

    def drain_roots(self, errors):
        for process in tuple(self.roots.values()):
            self.attempt(lambda: self.drain_root(process), errors)

    def drain_root(self, process):
        try:
            streams = process.communicate(timeout=remaining(self.deadline, 5))
        except subprocess.TimeoutExpired:
            process.kill()
            streams = process.communicate(timeout=remaining(self.deadline, 5))
        require(process.returncode is not None, 'spawned child cancellation exit observed')
        require(max(0 if stream is None else len(stream) for stream in streams) <= 1048576, 'bounded spawned child cancellation drain')
        remaining(self.deadline, 1)

    def active(self):
        table = records()
        return {pid for pid, row in self.held.items() if table.get(pid, {}).get('start') == row['start'] and table[pid]['state'] != 'Z'}

    def wait_owned(self):
        end = min(self.deadline, time.monotonic() + 5)
        while self.active() and time.monotonic() < end:
            time.sleep(min(0.05, max(0, end - time.monotonic())))

    def stopped(self):
        require(not self.live(), 'all owned descendants stopped before diagnostics')
        self.reap()
        remaining(self.deadline, 1)

    @synchronized
    def release(self, process):
        table = self.refresh()
        other = set()
        for pid in self.roots:
            if pid != process.pid:
                other |= descendants(table, pid) | {pid}
        leaked = self.live() - other - {process.pid}
        if leaked:
            self.stop_all()
            raise RuntimeError('exited phase retained owned descendants')
        require(process.poll() is not None, 'natural leader exit observed before release')
        self.roots.pop(process.pid)
        self.reap()

    @synchronized
    def close(self):
        require(not self.roots and not self.live(), 'no owned descendants or phase roots at closure')
        self.reap()
        require(not self.held, 'all subreaper descendants reaped at closure')

    @synchronized
    def reap(self):
        for pid, row in tuple(self.held.items()):
            if pid not in self.roots:
                try:
                    os.waitpid(pid, os.WNOHANG)
                except ChildProcessError:
                    pass
                if pid not in records():
                    os.close(row['fd'])
                    self.held.pop(pid)


if __name__ == '__main__':
    gated_exec(sys.argv[1:])
