import argparse
import pathlib
from evidence import load, save

NAMESPACE = "agent-tools"
ROLES = {"agent-alpha": "client", "agent-untrusted": "client", "plaintext-client": "client",
         "tool-gateway": "gateway", "action-sink": "sink", "scope-witness": "witness"}


def resource(kind, name, spec=None):
    result = dict(apiVersion="v1", kind=kind, metadata=dict(name=name, namespace=NAMESPACE))
    if spec is not None:
        result["spec"] = spec
    return result


def pod(name, role, image, proxy_image):
    annotations = {"sidecar.istio.io/inject": "true", "sidecar.istio.io/proxyImage": proxy_image,
                   "sidecar.istio.io/proxyCPU": "25m", "sidecar.istio.io/proxyMemory": "64Mi",
                   "sidecar.istio.io/proxyCPULimit": "500m", "sidecar.istio.io/proxyMemoryLimit": "256Mi"}
    sa = name
    if name == "plaintext-client":
        annotations = {"sidecar.istio.io/inject": "false"}
        sa = "agent-alpha"
    limits = dict(requests={"cpu": "25m", "memory": "32Mi", "ephemeral-storage": "16Mi"},
                  limits={"cpu": "250m", "memory": "128Mi", "ephemeral-storage": "64Mi"})
    container = dict(name="app", image=image, imagePullPolicy="Never", args=[role], resources=limits,
                     securityContext=dict(allowPrivilegeEscalation=False, readOnlyRootFilesystem=True,
                                          capabilities=dict(drop=["ALL"])),
                     volumeMounts=[dict(name="data", mountPath="/data")])
    if role != "client":
        container["ports"] = [dict(name="http-api", containerPort=8080)]
    spec = dict(serviceAccountName=sa, automountServiceAccountToken=False, restartPolicy="Never",
                securityContext=dict(runAsNonRoot=True, runAsUser=10001, runAsGroup=10001, fsGroup=10001),
                containers=[container], volumes=[dict(name="data", emptyDir=dict(sizeLimit="32Mi"))])
    result = resource("Pod", name, spec)
    result["metadata"].update(labels=dict(app=name), annotations=annotations)
    return result


def workloads(root, image, proxy_image):
    items = [dict(apiVersion="v1", kind="Namespace", metadata=dict(name=NAMESPACE, labels={"istio-injection": "enabled"}))]
    for name, role in ROLES.items():
        if name != "plaintext-client":
            items.append(resource("ServiceAccount", name))
        items.append(pod(name, role, image, proxy_image))
        if role != "client":
            items.append(resource("Service", name, dict(selector=dict(app=name), ports=[dict(name="http-api", port=8080, targetPort=8080, appProtocol="http")], type="ClusterIP")))
    return save(root, "workloads.json", dict(apiVersion="v1", kind="List", items=items))


def policy(name, app, principal=None, path=None):
    spec = dict(selector=dict(matchLabels=dict(app=app)), action="ALLOW")
    if principal:
        spec["rules"] = [{"from": [{"source": {"principals": [principal]}}],
                          "to": [{"operation": {"ports": ["8080"], "methods": ["POST"], "paths": [path]}}]}]
    return dict(apiVersion="security.istio.io/v1", kind="AuthorizationPolicy",
                metadata=dict(name=name, namespace=NAMESPACE), spec=spec)


def policies(root):
    strict = dict(apiVersion="security.istio.io/v1", kind="PeerAuthentication", metadata=dict(name="namespace-strict", namespace=NAMESPACE), spec=dict(mtls=dict(mode="STRICT")))
    save(root, "policies/namespace-strict.json", strict)
    definitions = [("gateway-allow-nothing", "tool-gateway", None, None),
                   ("gateway-alpha-followups", "tool-gateway", "cluster.local/ns/agent-tools/sa/agent-alpha", "/tools/followups"),
                   ("sink-allow-nothing", "action-sink", None, None),
                   ("sink-gateway-effects", "action-sink", "cluster.local/ns/agent-tools/sa/tool-gateway", "/effects")]
    for name, app, principal, path in definitions:
        save(root, "policies/" + name + ".json", policy(name, app, principal, path))


def install(root, lock):
    access = {"correlation": "%REQ(X-LAB-REQUEST-ID)%", "path": "%REQ(:PATH)%", "method": "%REQ(:METHOD)%",
              "peer": "%DOWNSTREAM_PEER_URI_SAN%", "tls": "%DOWNSTREAM_TLS_VERSION%", "status": "%RESPONSE_CODE%",
              "details": "%RESPONSE_CODE_DETAILS%", "flags": "%RESPONSE_FLAGS%", "upstream": "%UPSTREAM_HOST%"}
    import json
    mesh = dict(pathNormalization=dict(normalization="NONE"), accessLogFile="/dev/stdout", accessLogEncoding="JSON",
                accessLogFormat=json.dumps(access), defaultConfig=dict(concurrency=1))
    values = {"global": dict(proxy=dict(image=lock["images"]["proxy"]["image"], resources=dict(requests=dict(cpu="25m", memory="64Mi"), limits=dict(cpu="500m", memory="256Mi"))),
                            proxy_init=dict(image=lock["images"]["proxy"]["image"])),
              "pilot": dict(replicaCount=1, autoscaleEnabled=False, image=lock["images"]["pilot"]["image"]),
              "gateways": dict(istio_ingressgateway=dict(enabled=False), istio_egressgateway=dict(enabled=False))}
    components = dict(pilot=dict(k8s=dict(replicaCount=1, resources=dict(requests=dict(cpu="100m", memory="256Mi"), limits=dict(cpu="1", memory="512Mi")))))
    result = dict(apiVersion="install.istio.io/v1alpha1", kind="IstioOperator", metadata=dict(name="lab-minimal", namespace="istio-system"),
                  spec=dict(profile="minimal", meshConfig=mesh, values=values, components=components))
    return save(root, "istio-install.json", result)


def kind_config(root, port):
    kubelet = dict(kind="KubeletConfiguration", apiVersion="kubelet.config.k8s.io/v1beta1", containerLogMaxSize="4Mi", containerLogMaxFiles=2)
    import json
    result = dict(kind="Cluster", apiVersion="kind.x-k8s.io/v1alpha4", networking=dict(apiServerAddress="127.0.0.1", apiServerPort=port),
                  nodes=[dict(role="control-plane", kubeadmConfigPatches=[json.dumps(kubelet)])])
    return save(root, "kind.json", result)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("lock")
    parser.add_argument("image")
    args = parser.parse_args()
    lock = load(args.lock)
    policies(args.root)
    install(args.root, lock)
    workloads(args.root, args.image, lock["images"]["proxy"]["image"])


if __name__ == "__main__":
    main()
