import json
import re
import time
from evidence import digest, gst, save
from verify import require


def descendants(value):
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from descendants(child)
    if isinstance(value, list):
        for child in value:
            yield from descendants(child)


def inbound_chains(listeners):
    chains = []
    for item in descendants(listeners):
        if not isinstance(item, dict):
            continue
        match = item.get("filterChainMatch", {})
        if match.get("destinationPort") == 8080:
            chains.append(item)
    require(chains, "active workload-port 8080 filter chains missing")
    return chains


def enforced_rules(listeners):
    result = []
    for chain in inbound_chains(listeners):
        for item in descendants(chain):
            if isinstance(item, dict) and item.get("name") == "envoy.filters.http.rbac":
                config = item["typedConfig"]
                require("rules" in config, "enforcing RBAC rules absent")
                result.append(config["rules"])
    require(result, "enforcing inbound HTTP RBAC absent")
    return result


def check_rules(listeners, present, target=None):
    target = target or dict(policy="gateway-alpha-followups", principal="cluster.local/ns/agent-tools/sa/agent-alpha", path="/tools/followups")
    rules = enforced_rules(listeners)
    for rule in rules:
        require(rule.get("action", "ALLOW") == "ALLOW", "ALLOW enforcement")
        policies = rule.get("policies", {})
        check_compiled_policies(policies, present, target)
    return rules


def check_compiled_policies(policies, present, target):
    empty = "gateway-allow-nothing"
    if target["policy"] == "sink-gateway-effects":
        empty = "sink-allow-nothing"
    empty_name = "ns[agent-tools]-policy[" + empty + "]-rule[0]"
    narrow_name = "ns[agent-tools]-policy[" + target["policy"] + "]-rule[0]"
    expected = {empty_name}
    if present:
        expected.add(narrow_name)
    require(set(policies) == expected, "exact applicable RBAC inventory")
    deny = dict(permissions=[dict(notRule=dict(any=True))], principals=[dict(notId=dict(any=True))])
    require(policies[empty_name] == deny, "allow-nothing compiles to unsatisfiable permission/principal")
    if present:
        check_narrow(policies[narrow_name], target)


def check_narrow(policy, target):
    require(len(policy["principals"]) == 1 and len(policy["permissions"]) == 1, "one ANDed identity/operation rule")
    permissions = logic_atoms(policy["permissions"][0], "andRules", "orRules", "rules")
    expected = [dict(destinationPort=8080), dict(header=dict(name=":method", stringMatch=dict(exact="POST"))),
                dict(urlPath=dict(path=dict(exact=target["path"])))]
    require(canonical_atoms(permissions) == canonical_atoms(expected), "exact ANDed port/method/path")
    principals = logic_atoms(policy["principals"][0], "andIds", "orIds", "ids")
    expected_peer = dict(authenticated=dict(principalName=dict(exact="spiffe://" + target["principal"])))
    require(principals == [expected_peer], "exact authenticated source principal")


def canonical_atoms(items):
    return sorted(json.dumps(item, sort_keys=True) for item in items)


def logic_atoms(value, and_key, or_key, list_key):
    if set(value) == {and_key}:
        result = []
        for child in value[and_key][list_key]:
            result.extend(logic_atoms(child, and_key, or_key, list_key))
        return result
    if set(value) == {or_key}:
        children = value[or_key][list_key]
        require(len(children) == 1, "no disjunctive extra grant")
        return logic_atoms(children[0], and_key, or_key, list_key)
    return [value]


def policy_specs(items):
    return {x["metadata"]["name"]: x["spec"] for x in items}


def remaining(deadline):
    budget = deadline - time.monotonic()
    require(budget > 0, "absolute propagation deadline expired")
    return budget


def normalize_synced_age(match):
    age = re.fullmatch(r"(0|[1-9][0-9]{0,2})([smhdy])(?:(0|[1-9][0-9]{0,2})([smhdy]))?", match.group(1))
    if age is None:
        return match.group(0)
    first, unit, second, tail = age.groups()
    ranges = {"s": ((0, 119), None), "m": ((2, 179), None), "h": ((3, 47), None),
              "d": ((2, 729), None), "y": ((2, 292), None), "ms": ((2, 9), (1, 59)),
              "hm": ((3, 7), (1, 59)), "dh": ((2, 7), (1, 23)), "yd": ((2, 7), (1, 364))}
    bounds = ranges.get(unit + (tail or ""))
    if bounds is None:
        return match.group(0)
    if not bounds[0][0] <= int(first) <= bounds[0][1]:
        return match.group(0)
    if second is not None and not bounds[1][0] <= int(second) <= bounds[1][1]:
        return match.group(0)
    return "SYNCED"


def check_sync(sync, pod):
    rows = [re.sub(r"\bSYNCED \(([^()\s]*)\)(?=\s|$)", normalize_synced_age, line).split() for line in sync.splitlines() if line.strip()]
    require(rows and rows[0][0] == "NAME", "named xDS header missing")
    columns = rows[0]
    matches = [row for row in rows[1:] if row[0] == pod + ".agent-tools"]
    require(len(matches) == 1 and len(matches[0]) == len(columns), "one connected target xDS row")
    state = dict(zip(columns, matches[0]))
    require(state.get("ISTIOD", "").startswith("istiod-"), "target connected to named Istiod")
    for name in ("CDS", "LDS", "EDS", "RDS"):
        require(state.get(name) == "SYNCED", "target named xDS column " + name)
    return state


def listener_values(raw):
    try:
        document = json.loads(raw)
    except (ValueError, UnicodeError) as error:
        raise AssertionError("listener stats malformed JSON") from error
    require(isinstance(document, dict) and isinstance(document.get("stats"), list), "listener stats array missing")
    values = {}
    for item in document["stats"]:
        require(isinstance(item, dict) and set(item) == {"name", "value"}, "listener stats row malformed")
        name, value = item["name"], item["value"]
        require(isinstance(name, str) and name.startswith("listener_manager."), "listener stats name malformed")
        require(type(value) is int and value >= 0, "listener stats value must be a nonnegative integer")
        require(name not in values, "listener stats duplicate name")
        values[name] = value
    return values


def listener_readiness(context, pod, root, deadline):
    arguments = ["exec", "-n", "agent-tools", pod, "-c", "istio-proxy", "--",
                 "pilot-agent", "request", "GET", "stats?format=json&filter=^listener_manager\\.(total_filter_chains_draining|total_listeners_draining|total_listeners_warming|workers_started)$"]
    raw = context.kubectl(arguments, timeout=remaining(deadline)).stdout
    remaining(deadline)
    values = listener_values(raw)
    save(root, "listener-stats.json", dict(pod=pod, container="istio-proxy", time=gst(),
                                         argv=arguments, stats=json.loads(raw), stats_sha256=digest(raw)))
    expected = {"listener_manager.total_filter_chains_draining": 0,
                "listener_manager.total_listeners_draining": 0,
                "listener_manager.total_listeners_warming": 0,
                "listener_manager.workers_started": 1}
    for name, value in expected.items():
        require(name in values, "listener readiness stat missing: " + name)
        require(values[name] == value, "listener readiness not converged: " + name)
    return dict(pod=pod, container="istio-proxy", time=gst(), values=values, stats_sha256=digest(raw))


def observe(context, pod, present, root, deadline, target=None):
    policies = context.obj(["get", "authorizationpolicies", "-n", "agent-tools"], timeout=remaining(deadline))
    listeners = json.loads(context.istio(["proxy-config", "listeners", pod + ".agent-tools", "-o", "json"], timeout=remaining(deadline)).stdout)
    sync = context.istio(["proxy-status", "--verbosity", "1"], timeout=remaining(deadline)).stdout.decode()
    comparison = context.istio(["proxy-status", pod + ".agent-tools"], timeout=remaining(deadline)).stdout.decode()
    remaining(deadline)
    save(root, "policies.json", policies)
    save(root, "active-listeners.json", listeners)
    save(root, "sync.json", dict(time=gst(), status=sync, comparison=comparison))
    rules = check_rules(listeners, present, target)
    columns = check_sync(sync, pod)
    require("Listeners Match" in comparison, "target Envoy-Istiod listener comparison")
    readiness = listener_readiness(context, pod, root, deadline)
    return dict(specs=policy_specs(policies["items"]), rules=rules, time=gst(), sync_columns=columns,
                listeners_hash=digest(json.dumps(listeners, sort_keys=True).encode()), listener_readiness=readiness)


def wait_gate(context, pod, present, root, retained, target=None, deadline=None):
    if deadline is None:
        deadline = time.monotonic() + 60
    attempt = 0
    last_error = None
    attempt_budget = 0
    while time.monotonic() < deadline:
        if last_error is not None and deadline - time.monotonic() <= attempt_budget:
            break
        attempt += 1
        started = time.monotonic()
        try:
            state = observe(context, pod, present, root / ("attempt-%03d" % attempt), deadline, target)
            specs = dict(state["specs"])
            specs.pop("gateway-alpha-followups", None)
            require(specs == retained, "retained policies changed")
            remaining(deadline)
            return save(root, "gate.json", state)
        except AssertionError as error:
            last_error = error
            attempt_budget = time.monotonic() - started
            save(root, "attempt-%03d/error.json" % attempt, dict(error=str(error), time=gst()))
            if time.monotonic() < deadline:
                time.sleep(min(1, remaining(deadline)))
    raise RuntimeError("Read-only target RBAC gate did not complete within its absolute 60-second budget; last validation: " + str(last_error)) from last_error
