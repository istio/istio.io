import json
import pathlib
import sqlite3
from records import digest


def ledger(path):
    connection = sqlite3.connect("file:%s?mode=ro" % path, uri=True)
    connection.execute("PRAGMA query_only=ON")
    rows = connection.execute("SELECT tenant_id,resource_id,operation,request_id FROM actions ORDER BY request_id").fetchall()
    connection.close()
    keys = ("tenant_id", "resource_id", "operation", "request_id")
    values = [dict(zip(keys, row)) for row in rows]
    encoded = json.dumps(values, separators=(",", ":"), sort_keys=True).encode()
    return dict(rows=values, count=len(values), sha256=digest(encoded))


def audit(path):
    raw = pathlib.Path(path).read_bytes()
    if len(raw) > 4194304:
        raise ValueError("audit over 4 MiB")
    return [json.loads(line) for line in raw.splitlines()]


def main():
    import sys
    handlers = {"ledger": ledger, "audit": audit}
    print(json.dumps(handlers[sys.argv[1]](sys.argv[2])))


if __name__ == "__main__":
    main()
