import argparse
import base64
import json
from evidence import digest, load


def require(value, message):
    if not value:
        raise AssertionError(message)


def check_rows(case, observation, expected):
    before = observation["before"]["ledger"]
    after = observation["after"]["ledger"]
    require(before["count"] == len(before["rows"]), "before count")
    require(after["count"] == len(after["rows"]), "after count")
    for ledger in (before, after):
        encoded = json.dumps(ledger["rows"], separators=(",", ":"), sort_keys=True).encode()
        require(ledger["sha256"] == digest(encoded), "ledger hash")
    if expected["row_delta"] == 0:
        require(before == after, "denied ledger changed")
        return
    row = json.loads(case["body_utf8"])
    require(row not in before["rows"], "positive ID not fresh")
    rows = sorted(before["rows"] + [row], key=row_key)
    require(after["rows"] == rows, "exact appended row")


def row_key(row):
    return row["request_id"]


def check_is21_step(carried, observation, case):
    require(observation["before"] == carried, "IS21 completed snapshot continuity")
    accepted = case["layer"] == "accepted"
    check_rows(case, observation, dict(row_delta=int(accepted)))
    expected = {"tool-gateway": ["handler", "accepted", "downstream"], "action-sink": ["handler", "accepted", "committed"], "scope-witness": []}
    correlation = json.loads(case["body_utf8"])["request_id"]
    for role, events in expected.items():
        if not accepted:
            events = []
        check_full_audit(carried[role], observation["after"][role], events, correlation)


def check_full_audit(before, after, events, correlation):
    require(after[:len(before)] == before, "full original audit prefix changed")
    appended = after[len(before):]
    require([item["event"] for item in appended] == events, "exact full IS21 audit additions")
    require(all(item["correlation"] == correlation for item in appended), "unexpected IS21 audit correlation")


def check_is21_end(initial, final, first, third):
    rows = initial["ledger"]["rows"] + [json.loads(first["body_utf8"]), json.loads(third["body_utf8"])]
    ordered = sorted(rows, key=row_key)
    encoded = json.dumps(ordered, separators=(",", ":"), sort_keys=True).encode()
    expected = dict(rows=ordered, count=len(ordered), sha256=digest(encoded))
    require(final["ledger"] == expected, "IS21 final ledger equals initial plus exactly step1 and step3")


def count_event(audit, event, correlation):
    return sum(1 for item in audit if item["event"] == event and item["correlation"] == correlation)


def audit_delta(observation, role, event, correlation):
    before = count_event(observation["before"][role], event, correlation)
    after = count_event(observation["after"][role], event, correlation)
    return after - before


def check_audit(case, observation, expected):
    correlation = observation["correlation"]
    role = case["destination"]
    mappings = [(role, "handler", "handler_delta"),
                ("tool-gateway", "accepted", "accepted_delta"),
                ("tool-gateway", "downstream", "downstream_delta")]
    if role != "action-sink":
        mappings.append(("action-sink", "handler", "sink_handler_delta"))
    for name, event, key in mappings:
        actual = audit_delta(observation, name, event, correlation)
        require(actual == expected[key], "audit %s/%s: %s" % (name, event, actual))


def match_proxy(item, case, correlation):
    return item.get("correlation") == correlation and item.get("path") == case["target"]


def check_proxy(case, observation):
    if case["layer"] == "plaintext-rejected":
        return
    matches = [x for x in observation["proxy"] if match_proxy(x, case, observation["correlation"])]
    require(len(matches) == 1, "one attributable destination proxy response")
    proxy = matches[0]
    source_sa = case["source"]
    peer = "spiffe://cluster.local/ns/agent-tools/sa/" + source_sa
    require(proxy.get("peer") == peer, "observed certificate peer")
    require(proxy.get("tls") in ("TLSv1.2", "TLSv1.3"), "observed TLS")
    if case["layer"] == "mesh-denied":
        require("rbac_access_denied" in proxy.get("details", ""), "RBAC denial details")
    if case["layer"] == "accepted":
        sink = observation["sink_proxy"]
        require(len(sink) == 1, "one sink response")
        require(sink[0].get("peer") == "spiffe://cluster.local/ns/agent-tools/sa/tool-gateway", "gateway sink peer")


def verify(case, observation, layers, source_hash):
    expected = dict(layers[case["layer"]])
    if "status" in case:
        expected["status"] = case["status"]
    require(observation["source_hash"] == source_hash, "source hash")
    response = observation["response"]
    require(response["status"] == expected["status"], "literal status")
    if case["layer"] == "plaintext-rejected":
        require(response["error"] in expected["allowed_transport_errors"], "plaintext transport evidence")
    if case["layer"] == "mesh-denied":
        require(base64.b64decode(response["body_base64"]) == b"RBAC: access denied", "mesh response bytes")
    check_rows(case, observation, expected)
    check_audit(case, observation, expected)
    check_proxy(case, observation)
    return dict(id=case["id"], status="PASSED", expected=expected,
                actual=response, observation_sha256=digest(json.dumps(observation, sort_keys=True).encode()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("case")
    parser.add_argument("observation")
    parser.add_argument("matrix")
    parser.add_argument("source_hash")
    args = parser.parse_args()
    print(json.dumps(verify(load(args.case), load(args.observation), load(args.matrix)["layers"], args.source_hash)))


if __name__ == "__main__":
    main()
