import argparse
import os
import pathlib
import shutil
from evidence import Recorder, load
from prepare import host_guard, safe_root
from verify import require
from resources import initial_baseline
from verify_cleanup import missing


def delete(root, expected):
    host_guard(expected)
    safe_root(root)
    initial_baseline(root)
    from runtime import validate_bindings
    validate_bindings(root)
    owner = load(root / "ownership.json")
    require(str(root) == owner["remote_root"], "exact owned root")
    receipt = load(root / "final-export-receipt.json")
    require(receipt["verified"] and receipt["run_id"] == "cleanup-verified", "exact final cleanup export verified")
    require(load(root / "cleanup-verification.json")["nodes_absent"], "owned cleanup verification required")
    require(load(root / "cleanup.json")["images_removed"], "images teardown recorded")
    os.environ["DOCKER_CONFIG"] = str(root / "docker-config")
    recorder = Recorder(root / "staging-delete")
    for run in owner["runs"]:
        missing(recorder, ["docker", "inspect", "--format", "{{.Id}}", run["node"]], "no such object")
        missing(recorder, ["docker", "network", "inspect", run["network"]], "not found")
    require(not any(path.is_symlink() for path in root.rglob("*")), "symlink staging residue")
    shutil.rmtree(root)
    require(not root.exists(), "staging root removed")
    print("Exact owned staging root removed; both named nodes/networks absent")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("expected_hostname")
    args = parser.parse_args()
    delete(args.root, args.expected_hostname)


if __name__ == "__main__":
    main()
