import datetime
import hashlib
import json
import pathlib
import subprocess


def gst():
    zone = datetime.timezone(datetime.timedelta(hours=4))
    return datetime.datetime.now(zone).strftime("%Y-%m-%d %H:%M:%S.%f GST")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(root, name, value):
    target = pathlib.Path(root) / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    return value


def load(path):
    return json.loads(pathlib.Path(path).read_text())


class Recorder:
    def __init__(self, root):
        self.root = pathlib.Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        journal = self.root / "commands.jsonl"
        self.sequence = 0
        if journal.exists():
            self.sequence = len(journal.read_text().splitlines())

    def run(self, argv, timeout=30, check=True, env=None):
        self.sequence += 1
        prefix = "commands/%05d" % self.sequence
        started = gst()
        result = subprocess.run(argv, capture_output=True, timeout=timeout, env=env)
        if max(len(result.stdout), len(result.stderr)) > 1048576:
            raise RuntimeError("Command response exceeded 1 MiB")
        self.write_streams(prefix, result)
        record = dict(argv=argv, cwd=str(pathlib.Path.cwd()), start=started,
                      end=gst(), exit=result.returncode, timeout=timeout,
                      stdout=prefix + ".stdout", stderr=prefix + ".stderr",
                      environment="inherited; no credentials recorded")
        with (self.root / "commands.jsonl").open("a") as output:
            output.write(json.dumps(record) + "\n")
        if check and result.returncode:
            raise RuntimeError("Command failed: %s; see %s" % (argv[0], prefix))
        return result

    def write_streams(self, prefix, result):
        destination = self.root / prefix
        destination.parent.mkdir(exist_ok=True)
        destination.with_suffix(".stdout").write_bytes(result.stdout)
        destination.with_suffix(".stderr").write_bytes(result.stderr)
