from pod_route import install as install_pod_routes
import argparse
import json
import os
import pathlib
import socket
import signal
import subprocess
import threading
import time
from context import Context
from e2e import Suite, wrong_context_control
from prepare import NODE, IMAGES, host_guard, safe_root, verify_binaries
from evidence import Recorder, digest, gst, load, save, save_once, raise_errors
from render import install, kind_config, policies, workloads
from resources import baseline, docker_json, same_baseline, sample, initial_baseline
from verify import require
from verify_cleanup import missing
from export import export
from process_guard import Owner, SpawnGate, remaining

NETWORK_REFERENCE_FORMAT = '{"id":{{json .Id}},"name":{{json .Name}},"mode":{{json .HostConfig.NetworkMode}},"networks":{{json .NetworkSettings.Networks}}}'


def source_binding(root):
    files = {}
    for item in sorted((root / "source").rglob("*")):
        if item.is_file() and "__pycache__" not in item.parts:
            files[str(item.relative_to(root))] = digest(item.read_bytes())
    return dict(files=files, sha256=digest(json.dumps(files, sort_keys=True).encode()))


def validate_bindings(root):
    binding = load(root / "runtime-source-binding.json")
    require(source_binding(root) == binding["source"], "source bytes changed against immutable binding")
    initial_baseline(root)
    require(digest((root / "build.json").read_bytes()) == binding["build_sha256"], "immutable image build binding")
    build_state = load(root / "build.json")
    require(digest((root / 'versions.lock.json').read_bytes()) == binding['versions_lock_sha256'], 'immutable prepared image/launcher lock')
    validate_prepared_inputs(root, load(root / 'versions.lock.json'))
    for name in ("app.py", "client.py", "observer.py", "records.py", "validation.py", "Dockerfile"):
        key = "source/" + name
        require(digest((root / key).read_bytes()) == build_state["source"]["files"][key], "application bytes differ from built image")


def validate_prepared_inputs(root, lock):
    verify_binaries(root, lock['binaries'])
    for name, expected in IMAGES.items():
        image = lock['images'][name]
        require((image['repository'], image['reference']) == expected, 'frozen preparation image input')
        raw = (root / image['config_artifact']).read_bytes()
        require('sha256:' + digest(raw) == image['config_digest'], 'retained raw image config binding')
        require(json.loads(raw) == image['config'], 'parsed image config equals retained bytes')
    kind = lock['binaries']['kind']
    require(kind['custom'] is True, 'reviewed bounded launcher contract required')
    require(digest((root / 'bin/kind').read_bytes()) == kind['binary_sha256'], 'selected kind launcher unchanged')
    require(digest((root / 'launcher.lock.json').read_bytes()) == kind['contract_sha256'], 'selected launcher contract unchanged')


class Monitor:
    def __init__(self, root, initial_free, config=None, parent=None):
        self.deadline = __import__("resources").lifecycle_deadline
        self.owner = Owner(self.deadline) if parent is None else None
        self.root = root
        self.initial_free = initial_free
        self.node_id = None
        self.error = None
        self.config = config
        self.parent = parent
        self.owned_root = root
        self.state_lock = threading.Lock()
        self.cancelled = threading.Event()
        self.cancelled.set()
        self.processes = {}
        self.sample_lock = threading.Lock()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.loop)

    def loop(self):
        while not self.stop.is_set():
            try:
                with self.sample_lock:
                    sample(self.root, self.initial_free, self.node_id)
            except Exception as error:
                self.cancel(error)
                return
            self.stop.wait(5)

    def start(self):
        self.thread.start()

    def close(self):
        self.stop.set()
        self.thread.join(timeout=remaining(self.deadline, 40))
        require(not self.thread.is_alive(), "original deadline monitor drain")
        self.check()
        try:
            with self.sample_lock:
                sample(self.root, self.initial_free, self.node_id)
        except Exception as error:
            self.cancel(error)
        self.check()

    def check(self):
        if self.parent is not None:
            self.parent.check()
        with self.state_lock:
            failed = self.error is not None
        if failed:
            self.cancelled.wait(timeout=max(0, min(40, self.deadline - time.monotonic())))
            raise self.error
        remaining(self.deadline, 1)
        if self.owner is not None:
            self.owner.refresh()

    def bind_owned(self, root, config):
        self.check()
        with self.state_lock:
            require(self.error is None, 'resource failure blocks workload binding')
            require(self.config is None, 'no overlapping owned workload')
            self.owned_root, self.config = root, config

    def clear_owned(self, root):
        self.check()
        with self.state_lock:
            require(self.error is None, 'resource failure retains ownership')
            require(self.owned_root == root, 'clear exact owned workload')
            self.config = None

    def launch_process(self, argv, **kwargs):
        if self.parent is not None:
            return self.parent.launch_process(argv, **kwargs)
        self.check()
        registration_error = None
        with self.state_lock:
            if self.error is None:
                remaining(self.deadline, 1)
                gate = SpawnGate(argv, self.deadline, **kwargs)
                process = gate.process
                self.processes[process.pid] = process
                try:
                    self.owner.register(process)
                except BaseException as error:
                    registration_error = error
            else:
                raise RuntimeError('resource failure blocks command launch')
        try:
            if registration_error is not None:
                raise registration_error
            self.check()
            gate.permit()
            return process
        except BaseException as error:
            errors = [error]
            try:
                gate.close()
            except Exception as close_error:
                errors.append(close_error)
            self.cancel(registration_failure(errors))
            raise self.error from error

    def release_process(self, process):
        if self.parent is not None:
            return self.parent.release_process(process)
        self.owner.release(process)
        with self.state_lock:
            self.processes.pop(process.pid, None)

    def stop_process(self, process):
        if self.parent is not None:
            return self.parent.stop_process(process)
        self.owner.stop_all()

    def stop_processes(self, processes, errors):
        try:
            self.owner.stop_all()
        except Exception as error:
            errors.append(error)

    def begin_node_teardown(self, node_id):
        self.check()
        try:
            with self.sample_lock:
                require(self.node_id == node_id, 'teardown exact monitored node')
                final_sample = sample(self.root, self.initial_free, self.node_id)
                self.node_id = None
        except Exception as error:
            self.cancel(error)
            raise
        save(self.root, 'monitor-teardown.json', dict(node_id=node_id, time=gst(), final_node_sample=final_sample, host_monitor_continues=True))

    def abort_owned(self):
        if self.config is None:
            return
        return stop_owned_node(self.owned_root, self.config)

    def cancel(self, budget_error):
        if self.parent is not None:
            return self.parent.cancel(budget_error)
        with self.state_lock:
            active = self.error is None
            if active:
                self.cancelled.clear()
                self.error = budget_error
                processes = tuple(self.processes.values())
        if not active:
            self.cancelled.wait(timeout=max(0, min(40, self.deadline - time.monotonic())))
            require(self.cancelled.is_set(), 'original deadline cancellation drain')
            return
        try:
            self.complete_cancellation(budget_error, processes)
        finally:
            self.cancelled.set()

    def complete_cancellation(self, budget_error, processes):
        errors = [budget_error]
        self.stop_processes(processes, errors)
        outcome = dict(stop_attempted=False, stopped=False)
        try:
            outcome = self.abort_owned() or outcome
        except Exception as error:
            errors.append(error)
            outcome = getattr(error, "outcome", outcome)
        self.persist_failure("resource-stop.json", dict(error=str(budget_error), time=gst(), status="FAILED"), errors)
        self.persist_failure("resource-abort-failure.json", dict(outcome=outcome, errors=[str(item) for item in errors], time=gst()), errors)
        try:
            raise_errors(errors, outcome)
        except RuntimeError as error:
            self.error = error

    def persist_failure(self, name, value, errors):
        try:
            save(self.root, name, value)
        except Exception as error:
            errors.append(error)


def registration_failure(errors):
    try:
        raise_errors(errors)
    except RuntimeError as error:
        return error


def stop_owned_node(root, config):
    recorder = Recorder(root / "resource-abort", defer_persistence=True)
    outcome = dict(stop_attempted=False, stopped=False)
    errors = []
    try:
        node = owned_node(root, config, recorder)
        if node is not None:
            outcome.update(node_id=node["Id"], stop_attempted=True)
            result = recorder.run(["docker", "stop", "--time", "0", node["Id"]], timeout=10, check=False)
            outcome["stop_exit"] = result.returncode
            require(result.returncode == 0, "exact owned node stop failed: exit " + str(result.returncode))
            outcome["stopped"] = True
    except Exception as error:
        errors.append(error)
    outcome["commands"] = recorder.results
    recorder.flush_persistence()
    recorder.persist(save, root, "resource-abort.json", dict(outcome, time=gst(), errors=[str(item) for item in errors + recorder.persistence_errors]))
    recorder.flush_persistence()
    raise_errors(errors + recorder.persistence_errors, outcome)
    return outcome


def owned_node(root, config, recorder):
    proof = load(root / "runtime/owned-node.json")
    network = load(root / "runtime/owned-network.json")
    require(network["Name"] == config["network"], "recorded owned network name")
    result = recorder.run(["docker", "inspect", proof["id"]], check=False)
    if result.returncode == 1:
        require(b"no such object:" in result.stderr, "owned node absence not established")
        return None
    require(result.returncode == 0, "owned node inspection failed")
    node = json.loads(result.stdout)[0]
    require(node["Id"] == proof["id"], "original owned node ID")
    require(node["Name"] == "/" + config["node"], "original owned node name")
    require(node["NetworkSettings"]["Networks"][config["network"]]["NetworkID"] == network["Id"], "abort original network ID")
    require(node["Config"]["Labels"]["io.x-k8s.kind.cluster"] == config["cluster"], "abort exact owned cluster")
    require(set(node["NetworkSettings"]["Networks"]) == {config["network"]}, "abort exact owned network")
    return node


def image_exists(recorder, image):
    result = recorder.run(["docker", "image", "inspect", "--format", "{{.Id}}", image], check=False)
    require(result.returncode in (0, 1), "image existence probe failed")
    if result.returncode == 1:
        require(b"No such image:" in result.stderr, "image absence not proven")
    return result.returncode == 0


def pull_images(root, lock, recorder, monitor):
    owned = []
    if (root / "owned-images.json").exists():
        owned = load(root / "owned-images.json")
    index_existed = image_exists(recorder, NODE)
    save_once(root, "node-index-pre-pull.json", dict(image=NODE, preexisting=index_existed, observed=gst()))
    for key in ("node", "pilot", "proxy", "base"):
        monitor.check()
        image = lock["images"][key]["image"]
        existed = image_exists(recorder, image)
        recorder.run(["docker", "pull", "--platform", "linux/amd64", image], 180)
        inspected = docker_json(recorder, ["image", "inspect", image])[0]
        require(inspected["Id"] == lock["images"][key]["manifest_digest"], "Docker containerd manifest identity")
        require(inspected["RootFS"]["Layers"] == lock["images"][key]["config"]["rootfs"]["diff_ids"], "actual image rootfs identity")
        owned.append(dict(key=key, image=image, id=inspected["Id"], preexisting=existed, size=inspected["Size"], ownership_proven=not existed))
        save(root, "owned-images.json", owned)
    before_index_pull = image_exists(recorder, NODE)
    recorder.run(["docker", "pull", "--platform", "linux/amd64", NODE], 180)
    release_node = docker_json(recorder, ["image", "inspect", NODE])[0]
    require(release_node["Id"] == lock["images"]["node"]["index_digest"], "frozen node index identity")
    save(root, "owned-node-index.json", dict(image=NODE, id=release_node["Id"], preexisting=index_existed,
                                            pre_pull_existed=before_index_pull, ownership_proven=not index_existed))
    return owned


def build(root, lock, recorder):
    before = source_binding(root)
    tag = "istio-lab:source-" + before["sha256"][:20]
    require(not image_exists(recorder, tag), "application image collision")
    recorder.run(["docker", "build", "--network", "none", "--pull=false", "--platform", "linux/amd64", "--build-arg", "BASE_IMAGE=" + lock["images"]["base"]["image"], "-t", tag, str(root / "source")], 180)
    image = docker_json(recorder, ["image", "inspect", tag])[0]
    save_once(root, "build.json", dict(tag=tag, id=image["Id"], source=before, image=image, time=gst(), preexisting=False, ownership_proven=True))
    recorder.run(["docker", "save", "-o", str(root / "application-image.tar"), tag], 60)
    return tag


def setup(root, config, expected):
    host_guard(expected)
    safe_root(root)
    from resources import filesystem
    monitor = Monitor(root, filesystem('/')['available'])
    monitor.start()
    try:
        recorder = Recorder(root / "setup", supervisor=monitor)
        before = baseline(root, config, recorder)
        save_once(root, "preflight-initial.json", before)
        owner = load(root / "ownership.json")
        save_once(root, "run-ownership.json", dict(runs={item["id"]: "NOT_STARTED" for item in owner["runs"]}))
        lock = load(root / "versions.lock.json")
        validate_prepared_inputs(root, lock)
        pull_images(root, lock, recorder, monitor)
        tag = build(root, lock, recorder)
        policies(root / "source")
        install(root / "source", lock)
        workloads(root / "source", tag, lock["images"]["proxy"]["image"])
        save_once(root, "runtime-source-binding.json", dict(source=source_binding(root),
                  initial_baseline_sha256=digest((root / "preflight-initial.json").read_bytes()), build_sha256=digest((root / "build.json").read_bytes()), versions_lock_sha256=digest((root / 'versions.lock.json').read_bytes())))
        validate_prepared_inputs(root, lock)
    except Exception as error:
        monitor.cancel(error)
        raise
    finally:
        monitor.close()


def reserve_port(port):
    test = socket.socket()
    try:
        test.bind(("127.0.0.1", port))
    finally:
        test.close()


def docker_environment(root):
    environment = dict(os.environ)
    environment["DOCKER_CONFIG"] = str(root / "docker-config")
    return environment


def cap_node(root, config, recorder):
    inspected = docker_json(recorder, ["inspect", config["node"]])[0]
    require(inspected['Name'] == '/' + config['node'], 'exact task-owned node name')
    require(inspected["Config"]["Labels"]["io.x-k8s.kind.cluster"] == config["cluster"], "owned kind label")
    require(set(inspected["NetworkSettings"]["Networks"]) == {config["network"]}, "exact private node network")
    require(inspected['NetworkSettings']['Networks'][config['network']]['NetworkID'] == load(root / 'runtime/owned-network.json')['Id'], 'original task-owned node network ID')
    save_once(root, "runtime/owned-node.json", dict(id=inspected["Id"], node=config["node"], cluster=config["cluster"], network=config["network"],
              volumes=[mount["Name"] for mount in inspected["Mounts"] if mount["Type"] == "volume"]))
    created = inspected["Created"]
    recorder.run(["docker", "update", "--memory", "8g", "--memory-swap", "8g", "--cpus", "3", inspected["Id"]])
    capped = docker_json(recorder, ["inspect", inspected["Id"]])[0]
    limits = capped["HostConfig"]
    require(limits["Memory"] == 8 * 1024 ** 3, "node memory cap")
    require(limits["MemorySwap"] == 8 * 1024 ** 3, "node memory+swap cap")
    require(limits["NanoCpus"] == 3 * 10 ** 9, "node CPU cap")
    save(root, "runtime/node-cap.json", dict(created_utc=created, observed=gst(), capped=gst(), node_id=inspected["Id"], host_config=limits,
                                           limit="startup before Docker update was not bounded by this cap"))
    check_node_logging(limits["LogConfig"])
    return capped


def check_node_logging(config):
    require(config["Type"] == "json-file", "named runtime log driver")
    options = config["Config"]
    require("max-size" in options and "max-file" in options, "node container log rotation is not configured; host changes forbidden")
    require(options["max-size"] == "4m", "exact approved node log segment")
    require(options["max-file"] == "2", "exact approved node log files")


def supervise_create(root, context, config, recorder, monitor):
    verify_binaries(root.parent.parent, load(root.parent.parent / 'versions.lock.json')['binaries'])
    env = docker_environment(root.parent.parent)
    env.update(KIND_EXPERIMENTAL_DOCKER_NETWORK=config["network"], KUBECONFIG=context.kubeconfig)
    kind_config(root, config["api_port"])
    argv = [str(context.bin / "kind"), "create", "cluster", "--name", config["cluster"], "--kubeconfig", context.kubeconfig,
            "--image", NODE, "--config", str(root / "kind.json"), "--wait", "300s", "--retain"]
    started = gst()
    stdout = (root / "kind-create.stdout").open("wb")
    stderr = (root / "kind-create.stderr").open("wb")
    monitor.check()
    process = monitor.launch_process(argv, stdout=stdout, stderr=stderr, env=env)
    try:
        supervise_node(process, root, config, recorder, monitor)
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=remaining(monitor.deadline, 10))
        monitor.release_process(process)
        stdout.close()
        stderr.close()
        verify_binaries(root.parent.parent, load(root.parent.parent / 'versions.lock.json')['binaries'])
    with (root / "commands.jsonl").open("a") as output:
        output.write(json.dumps(dict(argv=argv, start=started, end=gst(), exit=process.returncode, timeout=300,
                                     environment=dict(KIND_EXPERIMENTAL_DOCKER_NETWORK=config["network"], KUBECONFIG="dedicated owned file"),
                                     cwd=str(root), stdout="kind-create.stdout", stderr="kind-create.stderr")) + "\n")
    require(process.returncode == 0, "kind creation failed; preserved stdout/stderr")


def supervise_node(process, root, config, recorder, monitor):
    deadline = min(monitor.deadline, time.monotonic() + 300)
    capped = False
    while process.poll() is None:
        monitor.check()
        require(time.monotonic() < deadline, "cluster bootstrap deadline")
        if not capped:
            inspect = recorder.run(["docker", "inspect", config["node"]], timeout=5, check=False)
            if inspect.returncode == 0:
                state = cap_node(root, config, recorder)
                monitor.node_id = state["Id"]
                capped = True
        time.sleep(0.25)
    require(capped, "bootstrap cap not established")


def network_create(root, config, recorder):
    mark_run_started(root, config)
    recorder.run(["docker", "network", "create", "--driver", "bridge", "--label", "technical-blogs.run=" + config["id"], config["network"]])
    network = docker_json(recorder, ["network", "inspect", config["network"]])[0]
    require(network["Driver"] == "bridge" and not network["Containers"], "fresh dedicated bridge")
    return save(root, "runtime/owned-network.json", network)


def mark_run_started(run, config):
    root = run.parent.parent
    state = load(root / "run-ownership.json")
    require(state["runs"][config["id"]] == "NOT_STARTED", "fresh run ownership")
    state["runs"][config["id"]] = "CREATION_ATTEMPTED"
    save(root, "run-ownership.json", state)


def cluster_inventory(context):
    root = context.root
    context.guard()
    save(root, "runtime/kubernetes-version.json", json.loads(context.kubectl(["version", "-o", "json"]).stdout))
    nodes = context.obj(["get", "nodes"])
    save(root, "runtime/nodes.json", nodes)
    conditions = {x["type"]: x["status"] for x in nodes["items"][0]["status"]["conditions"]}
    require(conditions.get("DiskPressure") == "False", "Kubelet DiskPressure product guard")
    require(conditions.get("MemoryPressure") == "False", "Kubelet MemoryPressure product guard")
    version = nodes["items"][0]["status"]["nodeInfo"]["kubeletVersion"]
    require(version == "v1.36.4", "actual server pin")


def install_istio(context):
    root = context.root
    path = root.parent.parent / "source/istio-install.json"
    context.guard()
    context.istio(["manifest", "generate", "-f", str(path), "--output", str(root / "runtime/generated-istio.yaml")])
    context.guard()
    context.istio(["install", "-y", "-f", str(path), "--readiness-timeout", "180s"], 180)
    context.kubectl(["rollout", "status", "deployment/istiod", "-n", "istio-system", "--timeout=180s"], 180)
    save(root, "runtime/istio-version.json", json.loads(context.istio(["version", "-o", "json"]).stdout))
    context.mutate(["apply", "-f", str(root.parent.parent / "source/workloads.json")])
    context.mutate(["apply", "-f", str(root.parent.parent / "source/policies/namespace-strict.json")])
    context.kubectl(["wait", "--for=condition=Ready", "pods", "--all", "-n", "agent-tools", "--timeout=180s"], 180)


def validate_workloads(context, lock):
    pods = context.pods()
    for name, pod in pods.items():
        containers = {x["name"]: x for x in pod["spec"]["containers"]}
        statuses = pod["status"]["containerStatuses"] + pod["status"].get("initContainerStatuses", [])
        require(all(x["restartCount"] == 0 for x in statuses), "without restarts")
        require(all(x["ready"] for x in pod["status"]["containerStatuses"]), "ready application")
        require(not pod["spec"].get("hostNetwork", False), "no host network")
        if name != "plaintext-client":
            init = {x["name"]: x for x in pod["spec"].get("initContainers", [])}
            require(init["istio-proxy"]["restartPolicy"] == "Always", "native Kubernetes sidecar")
            require(init["istio-proxy"]["image"] == lock["images"]["proxy"]["image"], "running pinned proxy")
            require(init["istio-init"]["image"] == lock["images"]["proxy"]["image"], "pinned init interception")
            proxy_status = {x["name"]: x for x in pod["status"]["initContainerStatuses"]}
            require(proxy_status["istio-proxy"]["imageID"] == lock["images"]["proxy"]["image"], "actual proxy manifest ID")
            require(proxy_status["istio-init"]["imageID"] == lock["images"]["proxy"]["image"], "actual init manifest ID")
        save(context.root, "runtime/pods/" + name + ".json", pod)
    services = context.obj(["get", "services", "-n", "agent-tools"])
    save(context.root, "runtime/services.json", services)
    endpoints = context.obj(["get", "endpointslices", "-n", "agent-tools"])
    save(context.root, "runtime/endpoints.json", endpoints)


def public_certificates(context):
    for name, pod in context.pods().items():
        if name == "plaintext-client":
            continue
        raw = context.exec(pod["metadata"]["name"], ["pilot-agent", "request", "GET", "certs"], "istio-proxy").stdout
        save(context.root, "runtime/public-certificates/" + name + ".json", json.loads(raw))


def run_cluster(root, config, expected, outer=None):
    host_guard(expected)
    safe_root(root)
    validate_bindings(root)
    run = root / "runs" / config["id"]
    run.mkdir(parents=True, exist_ok=False)
    monitor = Monitor(run, initial_baseline(root)["root"]["available"], config, parent=outer)
    if outer is not None:
        outer.bind_owned(run, config)
    recorder = Recorder(run, supervisor=monitor)
    monitor.start()
    try:
        before = baseline(run, config, recorder)
        reserve_port(config["api_port"])
        context = Context(run, config, recorder)
        network_create(run, config, recorder)
        supervise_create(run, context, config, recorder, monitor)
        cluster_inventory(context)
        environment = docker_environment(root)
        environment["KUBECONFIG"] = context.kubeconfig
        recorder.run([str(root / "bin/kind"), "load", "image-archive", str(root / "application-image.tar"), "--name", config["cluster"]], 120, env=environment)
        install_istio(context)
        validate_workloads(context, load(root / "versions.lock.json"))
        public_certificates(context)
        install_pod_routes(context)
        validate_bindings(root)
        suite = Suite(context, load(root / "case-expectations.json"), load(root / "runtime-source-binding.json")["source"]["sha256"], monitor.check)
        wrong_context_control(context)
        suite.run_stages()
        suite.revocation()
        suite.mutation_controls()
        save(run, "results.json", suite.results)
        require(all(x["status"] == "PASSED" for x in suite.results), "live failures")
        cluster_inventory(context)
        validate_workloads(context, load(root / "versions.lock.json"))
        validate_bindings(root)
        save(run, "IS20-before-export.json", dict(source=source_binding(root), baseline=same_baseline(before, recorder), time=gst()))
        export_and_cleanup(root, config, expected, monitor)
    except Exception as error:
        monitor.cancel(error)
        save(run, "failure.json", dict(error=type(error).__name__, message=str(error), time=gst()))
        raise
    finally:
        monitor.close()
        if outer is not None:
            outer.clear_owned(run)


def export_and_cleanup(root, config, expected, monitor):
    export_id = config['id'] + '-before-teardown'
    monitor.check()
    validate_bindings(root)
    export(root, export_id, monitor)
    validate_bindings(root)
    binding = load(root / ('export-archive-' + export_id + '.json'))
    receipt = root / 'runs' / config['id'] / 'export-receipt.json'
    wait_export_receipt(receipt, config['id'], binding['sha256'], monitor)
    validate_bindings(root)
    cleanup(root, config, expected, monitor)
    monitor.check()


def wait_export_receipt(path, run_id, archive_sha256, monitor):
    deadline = min(monitor.deadline, time.monotonic() + 180)
    while not path.exists():
        monitor.check()
        require(time.monotonic() < deadline, 'verified export receipt deadline')
        time.sleep(1)
    monitor.check()
    require(time.monotonic() < deadline, 'verified export receipt arrived late')
    require(not path.is_symlink(), 'regular export receipt')
    receipt = load(path)
    require(receipt['run_id'] == run_id and receipt['verified'] is True, 'exact independently verified export receipt')
    require(receipt['archive_sha256'] == archive_sha256, 'receipt immutable archive binding')


def serial_lifecycle(root, config, expected):
    from finish_runtime import finish
    from verify_cleanup import verify_cleanup
    host_guard(expected)
    safe_root(root)
    validate_bindings(root)
    monitor = Monitor(root, initial_baseline(root)['root']['available'])
    monitor.start()
    try:
        for declared in load(root / 'ownership.json')['runs']:
            monitor.check()
            run_cluster(root, declared, expected, monitor)
        monitor.check()
        finish(root, expected, monitor)
        monitor.check()
        verify_cleanup(root, expected, monitor)
        monitor.check()
        validate_bindings(root)
        export(root, 'cleanup-verified', monitor)
        validate_bindings(root)
        binding = load(root / 'export-archive-cleanup-verified.json')
        wait_export_receipt(root / 'final-export-receipt.json', 'cleanup-verified', binding['sha256'], monitor)
        validate_bindings(root)
    except Exception as error:
        monitor.cancel(error)
        raise
    finally:
        monitor.close()


def cleanup(root, config, expected, monitor=None):
    host_guard(expected)
    safe_root(root)
    before = initial_baseline(root)
    run = root / "runs" / config["id"]
    receipt = load(run / "export-receipt.json")
    require(receipt["run_id"] == config["id"] and receipt["verified"], "verified evidence export required")
    recorder = Recorder(run / "teardown", defer_persistence=True, supervisor=monitor)
    outcome = dict(acceptance_restored=False, node_deleted=None, network_deleted=None)
    errors = []
    try:
        cleanup_owned(root, run, config, before, recorder, outcome, monitor)
    except Exception as error:
        errors.append(error)
    outcome["commands"] = recorder.results
    recorder.flush_persistence()
    recorder.persist(save, run, "cleanup.json", dict(outcome, time=gst(), errors=[str(item) for item in errors + recorder.persistence_errors]))
    recorder.flush_persistence()
    raise_errors(errors + recorder.persistence_errors, outcome)
    return outcome


def validate_network_record(record):
    require(set(record) == {"id", "name", "mode", "networks"}, "constrained container network fields")
    require(isinstance(record["id"], str) and bool(record["id"]), "known container ID")
    require(isinstance(record["name"], str) and record["name"].startswith("/") and len(record["name"]) > 1, "known container name")
    require(isinstance(record["mode"], str) and bool(record["mode"]), "known container network mode")


def references_network(record, network):
    validate_network_record(record)
    require(isinstance(record["networks"], dict), "known configured container networks")
    found = False
    for name, attachment in record["networks"].items():
        require(isinstance(name, str) and bool(name), "known configured network name")
        require(isinstance(attachment, dict), "known configured network attachment")
        identifier = attachment["NetworkID"]
        require(isinstance(identifier, str) and bool(identifier), "known configured network ID")
        if name == network["Name"] or identifier == network["Id"]:
            require(name == network["Name"] and identifier == network["Id"], "exact configured network reference")
            found = True
    return found


def namespace_target(record, records):
    mode = record["mode"]
    if not mode.startswith("container:"):
        return None
    target = mode.removeprefix("container:")
    require(bool(target), "known container namespace target")
    matches = {item["id"] for item in records if item["id"].startswith(target) or item["name"].removeprefix("/") == target.removeprefix("/")}
    require(len(matches) == 1, "unique resolved container namespace target")
    return matches.pop()


def namespace_references(identifier, targets, members):
    visited = set()
    found = False
    while identifier is not None:
        require(identifier not in visited, "acyclic container namespace dependency")
        visited.add(identifier)
        found = found or identifier in members
        identifier = targets[identifier]
    return found


def validate_network_references(recorder, network, allowed):
    ids = recorder.run(["docker", "ps", "-aq", "--no-trunc"]).stdout.decode().split()
    require(len(ids) == len(set(ids)), "unique all-container inventory")
    records = []
    if ids:
        raw = recorder.run(["docker", "inspect", "--format", NETWORK_REFERENCE_FORMAT] + ids).stdout
        records = [json.loads(line) for line in raw.splitlines()]
    require(len(records) == len(ids) and {item["id"] for item in records} == set(ids), "complete constrained network inventory")
    members = {item["id"] for item in records if references_network(item, network)}
    targets = {item["id"]: namespace_target(item, records) for item in records}
    require(members == allowed, "only proven owned configured network references; retain unrelated containers")
    dependents = {identifier for identifier in targets if namespace_references(identifier, targets, members)}
    require(dependents == allowed, "only proven owned network namespace dependencies; retain unrelated containers")


def cleanup_owned(root, run, config, before, recorder, outcome, monitor=None):
    node = owned_node(run, config, recorder)
    require(node is not None, "original owned node identity required; no deletion")
    network = docker_json(recorder, ["network", "inspect", config["network"]])[0]
    require(network["Id"] == load(run / "runtime/owned-network.json")["Id"], "cleanup original owned network ID")
    require(network["Name"] == config["network"], "exact owned network name")
    require(isinstance(node["State"]["Running"], bool), "known owned node running state")
    active = {node["Id"]} if node["State"]["Running"] else set()
    require(set(network["Containers"]) == active, "owned active network membership matches node state")
    validate_network_references(recorder, network, {node["Id"]})
    cluster = recorder.run(["docker", "ps", "-aq", "--no-trunc", "--filter", "label=io.x-k8s.kind.cluster=" + config["cluster"]]).stdout.decode().split()
    require(cluster == [node["Id"]], "one original owned Docker cluster node")
    context = Context(run, config, recorder)
    context.guard_file()
    env = docker_environment(root)
    env["KUBECONFIG"] = context.kubeconfig
    if monitor is not None:
        monitor.begin_node_teardown(node['Id'])
    recorder.run([str(root / "bin/kind"), "delete", "cluster", "--name", config["cluster"]], 60, env=env)
    missing(recorder, ["docker", "inspect", "--format", "{{.Id}}", node["Id"]], "no such object")
    outcome["node_deleted"] = node["Id"]
    remaining = docker_json(recorder, ["network", "inspect", network["Id"]])[0]
    require(not remaining["Containers"], "network empty after deletion")
    require(remaining["Id"] == network["Id"] and remaining["Name"] == network["Name"], "original network retained after deletion")
    validate_network_references(recorder, network, set())
    recorder.run(["docker", "network", "rm", network["Id"]])
    missing(recorder, ["docker", "network", "inspect", network["Id"]], "not found")
    outcome["network_deleted"] = network["Id"]
    outcome["baseline"] = same_baseline(before, recorder)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("setup", "run", "cleanup", "serial"))
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("expected_hostname")
    parser.add_argument("run_index", type=int)
    args = parser.parse_args()
    owner = load(args.root / "ownership.json")
    require(owner["remote_root"] == str(args.root) and owner["expected_hostname"] == args.expected_hostname, "exact provided ownership input")
    require(len(owner["runs"]) == 2 and args.run_index in (0, 1), "exact two declared fresh runs")
    os.environ["DOCKER_CONFIG"] = str(args.root / "docker-config")
    config = owner["runs"][args.run_index]
    operations = {"setup": setup, "run": run_cluster, "cleanup": cleanup, 'serial': serial_lifecycle}
    operations[args.phase](args.root, config, args.expected_hostname)


if __name__ == "__main__":
    main()
