import argparse
import pathlib
from policy_gate import enforced_rules
from evidence import load, save


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("listeners")
    parser.add_argument("destination", type=pathlib.Path)
    args = parser.parse_args()
    print(save(args.destination.parent, args.destination.name, enforced_rules(load(args.listeners))))


if __name__ == "__main__":
    main()
