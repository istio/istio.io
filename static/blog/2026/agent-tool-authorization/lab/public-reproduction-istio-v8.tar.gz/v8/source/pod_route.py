"""Exact owned PodIP HTTP registration and read-only selected mTLS route proof."""

import datetime
import ipaddress
import json
import time
from evidence import digest, gst, load, save
from policy_gate import check_sync, listener_readiness, remaining
from verify import require


def identity(pod):
    role = pod["metadata"]["labels"]["app"]
    require(role in {"agent-alpha", "agent-untrusted", "tool-gateway", "action-sink"}, "owned route workload role")
    require(pod["metadata"]["namespace"] == "agent-tools", "owned route namespace")
    require(pod["metadata"]["name"] == role and pod["spec"]["serviceAccountName"] == role, "exact owned workload and service account")
    require(isinstance(pod["metadata"]["uid"], str) and pod["metadata"]["uid"], "owned route pod UID")
    address = pod["status"]["podIP"]
    require(str(ipaddress.IPv4Address(address)) == address, "canonical owned IPv4 PodIP")
    return dict(name=role, uid=pod["metadata"]["uid"], ip=address,
                spiffe="spiffe://cluster.local/ns/agent-tools/sa/" + role)


def fixture(pod):
    target = identity(pod)
    require(target["name"] in {"tool-gateway", "action-sink"}, "only owned gateway/sink route targets")
    alias = "owned-podip-" + target["name"] + ".juryv8.invalid"
    metadata = dict(name="owned-podip-" + target["name"], namespace="agent-tools")
    entry = dict(apiVersion="networking.istio.io/v1", kind="ServiceEntry", metadata=metadata,
                 spec=dict(hosts=[alias], addresses=[target["ip"]], location="MESH_INTERNAL", resolution="STATIC", exportTo=["."],
                           ports=[dict(number=8080, name="http-podip", protocol="HTTP", targetPort=8080)],
                           endpoints=[dict(address=target["ip"], ports={"http-podip": 8080})], subjectAltNames=[target["spiffe"]]))
    rule = dict(apiVersion="networking.istio.io/v1", kind="DestinationRule", metadata=metadata,
                spec=dict(host=alias, exportTo=["."], trafficPolicy=dict(portLevelSettings=[dict(port=dict(number=8080),
                          tls=dict(mode="ISTIO_MUTUAL", sni=alias, subjectAltNames=[target["spiffe"]]))])))
    virtual = dict(apiVersion="networking.istio.io/v1", kind="VirtualService", metadata=metadata,
                   spec=dict(hosts=[alias], exportTo=["."], gateways=["mesh"], http=[dict(retries=dict(attempts=0),
                             route=[dict(destination=dict(host=alias, port=dict(number=8080)))])]))
    return [entry, rule, virtual]


def object_specs(items):
    result = {}
    for item in items:
        key = item["kind"] + "/" + item["metadata"]["name"]
        require(key not in result, "duplicate routing object")
        require(item["metadata"]["namespace"] == "agent-tools", "routing object namespace")
        result[key] = dict(uid=item["metadata"].get("uid"), spec=item["spec"])
    return result


def invariants(context, deadline):
    pods = context.pods()
    services = context.obj(["get", "services", "-n", "agent-tools"], timeout=remaining(deadline))
    policies = context.obj(["get", "authorizationpolicies", "-n", "agent-tools"], timeout=remaining(deadline))
    strict = context.obj(["get", "peerauthentication", "namespace-strict", "-n", "agent-tools"], timeout=remaining(deadline))
    require(strict["spec"] == dict(mtls=dict(mode="STRICT")), "route requires unchanged namespace STRICT")
    return dict(pods={role: dict(uid=pod["metadata"]["uid"], ip=pod["status"]["podIP"]) for role, pod in pods.items()},
                services=object_specs(services["items"]), policies=object_specs(policies["items"]),
                strict=dict(uid=strict["metadata"]["uid"], spec=strict["spec"]))


def live_objects(context, deadline):
    return object_specs(context.obj(["get", "serviceentries,destinationrules,virtualservices", "-n", "agent-tools"],
                                    timeout=remaining(deadline))["items"])


def install(context):
    previous = context.deadline
    deadline = min(time.monotonic() + 60, previous if previous is not None else float("inf"))
    context.deadline = deadline
    try:
        before = invariants(context, deadline)
        require(not live_objects(context, deadline), "owned routing namespace must have no preexisting fixtures")
        pods = context.pods()
        items = fixture(pods["tool-gateway"]) + fixture(pods["action-sink"])
        manifest = dict(apiVersion="v1", kind="List", items=items)
        path = context.root / "runtime/podip-routes.json"
        save(context.root, "runtime/podip-routes.json", manifest)
        context.istio(["validate", "-f", str(path)], timeout=remaining(deadline))
        context.kubectl(["apply", "--dry-run=server", "-f", str(path), "-o", "json"], timeout=remaining(deadline))
        context.mutate(["apply", "-f", str(path)], timeout=remaining(deadline))
        live = live_objects(context, deadline)
        require({key: value["spec"] for key, value in live.items()} ==
                {key: value["spec"] for key, value in object_specs(items).items()}, "exact live HTTP IP/TLS fixture specs")
        require(all(value["uid"] for value in live.values()), "live fixture UIDs required")
        require(invariants(context, deadline) == before, "routing install changed original pods/services/policies/STRICT")
        remaining(deadline)
        save(context.root, "runtime/podip-route-binding.json", dict(time=gst(), original=before, objects=live,
             manifest_sha256=digest(path.read_bytes()), targets={name: identity(pods[name]) for name in ("tool-gateway", "action-sink")}))
    finally:
        context.deadline = previous


def one(items, message):
    require(isinstance(items, list) and len(items) == 1, message)
    return items[0]


def section(document, name):
    require(isinstance(document, dict) and isinstance(document.get("configs"), list), "Envoy config dump array missing/malformed")
    value = one([item for item in document["configs"] if item.get("@type") == "type.googleapis.com/envoy.admin.v3." + name],
                "exact pinned Envoy config section missing: " + name)
    require(all(key == key.lower() for key in value), "exact raw snake_case admin envelope; ambiguous names rejected")
    return value


def capture_listener(active, ip):
    addresses = [item["address"]["socket_address"] for item in active]
    require(not any(item.get("address") == ip and item.get("port_value") == 8080 for item in addresses), "unexpected overriding exact PodIP listener")
    original = one([item for item in active if item["name"] == "virtualOutbound"], "original destination capture listener missing")
    require(original["address"]["socket_address"] == dict(address="0.0.0.0", port_value=15001) and original.get("use_original_dst") is True,
            "original destination listener capture")


def http_listener(active):
    listener = one([item for item in active if item["address"]["socket_address"] == dict(address="0.0.0.0", port_value=8080)],
                   "one pinned outbound HTTP port listener")
    chain = one(listener["filter_chains"], "one selected outbound HTTP filter chain")
    require(chain["filter_chain_match"] == dict(application_protocols=["http/1.1", "h2c"], transport_protocol="raw_buffer"), "literal HTTP chain selection")
    hcm = one([item["typed_config"] for item in chain["filters"] if item["name"] == "envoy.filters.network.http_connection_manager"], "HTTP connection manager missing")
    require(hcm["@type"] == "type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager", "pinned HTTP manager type")
    require(hcm["rds"]["route_config_name"] == "8080" and hcm["rds"]["config_source"]["ads"] == {}, "selected HTTP RDS subscription")
    return listener


def listeners(document, ip):
    entries = section(document, "ListenersConfigDump")["dynamic_listeners"]
    require(all(set(item).isdisjoint({"warming_state", "draining_state"}) for item in entries), "source listener warming/draining state")
    active = [item["active_state"]["listener"] for item in entries]
    capture_listener(active, ip)
    return http_listener(active)


def selected_route(document, ip, alias, cluster):
    routes = [item["route_config"] for item in section(document, "RoutesConfigDump")["dynamic_route_configs"]]
    config = one([item for item in routes if item["name"] == "8080"], "selected RDS port route missing")
    require(config["ignore_port_in_host_matching"] is True, "literal PodIP:8080 authority requires pinned port-ignore matching")
    authority = ip + ":8080"
    host = one([item for item in config["virtual_hosts"] if authority in item["domains"] or ip in item["domains"]], "exact literal IP HTTP domain missing/ambiguous")
    require(len(host["domains"]) == 3 and set(host["domains"]) == {ip, alias, alias + "."}, "exact pinned IP, alias and absolute FQDN domains without duplicates/alternates")
    route = one(host["routes"], "one unconditional HTTP route required")
    require(route["match"] == dict(prefix="/"), "literal request unconditional path route")
    require(set(route) <= {"name", "match", "route", "decorator", "metadata"}, "no extra request mutation or mirroring")
    action = route["route"]
    require(action.get("cluster") == cluster and set(action) <= {"cluster", "timeout", "max_grpc_timeout"}, "exact single cluster route without retries/rewrites")
    require(not set(host).intersection({"request_headers_to_add", "request_headers_to_remove"}), "no virtual host request rewrite")
    require(not set(config).intersection({"request_headers_to_add", "request_headers_to_remove"}), "no route config request rewrite")
    return host


def sds(secret, name):
    require(secret["name"] == name, "exact mutual TLS SDS secret " + name)
    services = secret["sds_config"]["api_config_source"]["grpc_services"]
    require(one(services, "one owned SDS service")["envoy_grpc"] == dict(cluster_name="sds-grpc"), "owned local SDS transport")


def selected_cluster(document, name, alias, san):
    values = [item["cluster"] for item in section(document, "ClustersConfigDump")["dynamic_active_clusters"]]
    cluster = one([item for item in values if item["name"] == name], "selected outbound cluster missing/ambiguous")
    require(cluster["type"] == "EDS" and cluster["eds_cluster_config"]["service_name"] == name and
            cluster["eds_cluster_config"]["eds_config"]["ads"] == {}, "exact pinned EDS cluster subscription")
    require("transport_socket_matches" not in cluster, "no alternate plaintext transport socket")
    socket = cluster["transport_socket"]
    require(socket["name"] == "envoy.transport_sockets.tls", "selected upstream is TLS")
    tls = socket["typed_config"]
    require(tls["@type"] == "type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.UpstreamTlsContext" and tls["sni"] == alias,
            "exact upstream TLS context/SNI")
    common = tls["common_tls_context"]
    sds(one(common["tls_certificate_sds_secret_configs"], "one client identity SDS certificate"), "default")
    validation = common["combined_validation_context"]
    require(validation["default_validation_context"] == dict(match_subject_alt_names=[dict(exact=san)]), "exact destination SPIFFE SAN verification")
    sds(validation["validation_context_sds_secret_config"], "ROOTCA")
    return cluster


def selected_endpoint(document, cluster, ip):
    values = [item["endpoint_config"] for item in section(document, "EndpointsConfigDump")["dynamic_endpoint_configs"]]
    config = one([item for item in values if item["cluster_name"] == cluster], "selected EDS endpoints missing/ambiguous")
    locality = one(config["endpoints"], "one owned endpoint locality")
    endpoint = one(locality["lb_endpoints"], "one owned endpoint without alternates")
    require(endpoint["health_status"] == "HEALTHY", "owned endpoint health readiness")
    address = endpoint["endpoint"]["address"]["socket_address"]
    require(address == dict(address=ip, port_value=8080), "exact original PodIP:8080 endpoint")
    require("additional_addresses" not in endpoint["endpoint"], "no alternate endpoint address")
    return config


def prove_certificate(document, expected):
    require(isinstance(document, dict) and isinstance(document.get("certificates"), list), "actual public certificate metadata malformed")
    chains = [leaf for item in document["certificates"] for leaf in item.get("cert_chain", [])]
    require(chains, "actual active identity certificate absent")
    now = datetime.datetime.now(datetime.timezone.utc)
    for leaf in chains:
        require(leaf["subject_alt_names"] == [dict(uri=expected)], "actual workload SPIFFE identity mismatch")
        start = datetime.datetime.fromisoformat(leaf["valid_from"].replace("Z", "+00:00"))
        end = datetime.datetime.fromisoformat(leaf["expiration_time"].replace("Z", "+00:00"))
        require(start <= now < end, "actual identity certificate validity")
    return expected


def prove_config(document, source, target, source_cert, target_cert):
    try:
        client, server = identity(source), identity(target)
        require(client["name"] in {"agent-alpha", "agent-untrusted"}, "only in-mesh literal IP clients")
        require(server["name"] in {"tool-gateway", "action-sink"}, "only owned direct IP destinations")
        alias = "owned-podip-" + server["name"] + ".juryv8.invalid"
        cluster = "outbound|8080||" + alias
        selected = dict(listener=listeners(document, server["ip"]), route=selected_route(document, server["ip"], alias, cluster),
                        cluster=selected_cluster(document, cluster, alias, server["spiffe"]), endpoint=selected_endpoint(document, cluster, server["ip"]))
        return dict(source=client, target=server, authority=server["ip"] + ":8080", cluster=cluster,
                    endpoint=dict(address=server["ip"], port_value=8080), selected=selected,
                    source_spiffe=prove_certificate(source_cert, client["spiffe"]), target_spiffe=prove_certificate(target_cert, server["spiffe"]))
    except (KeyError, TypeError, ValueError, AttributeError) as error:
        raise AssertionError("missing/malformed/unsupported pinned PodIP Envoy route or certificate metadata: " + str(error)) from error


def admin(context, pod, resource, deadline):
    raw = context.kubectl(["exec", "-n", "agent-tools", pod, "-c", "istio-proxy", "--", "pilot-agent", "request", "GET", resource],
                          timeout=remaining(deadline)).stdout
    remaining(deadline)
    return json.loads(raw), digest(raw)


def observe(context, source, target, binding, root, deadline):
    before = invariants(context, deadline)
    expected = binding["original"]
    require(before["pods"] == expected["pods"] and before["services"] == expected["services"] and before["strict"] == expected["strict"],
            "original route pods/services/STRICT retained")
    require(live_objects(context, deadline) == binding["objects"], "original exact route fixture UIDs/specs retained")
    require_narrow_inventory(context, before)
    source_name, target_name = identity(source)["name"], identity(target)["name"]
    require(before["pods"][source_name] == dict(uid=source["metadata"]["uid"], ip=source["status"]["podIP"]), "original in-mesh source pod identity")
    sync = context.istio(["proxy-status", "--verbosity", "1"], timeout=remaining(deadline)).stdout.decode()
    columns = {name: check_sync(sync, name) for name in (source_name, target_name)}
    readiness = {name: listener_readiness(context, name, root / name, deadline) for name in (source_name, target_name)}
    config, config_hash = admin(context, source_name, "config_dump?include_eds", deadline)
    client_cert, client_hash = admin(context, source_name, "certs", deadline)
    server_cert, server_hash = admin(context, target_name, "certs", deadline)
    proof = prove_config(config, source, target, client_cert, server_cert)
    require(invariants(context, deadline) == before, "read-only route gate changed original inventory")
    require(live_objects(context, deadline) == binding["objects"], "route fixtures changed during read-only proof")
    remaining(deadline)
    return dict(time=gst(), proof=proof, sync_columns=columns, listener_readiness=readiness,
                source_configuration=dict(configs=[section(config, name) for name in
                    ("ListenersConfigDump", "RoutesConfigDump", "ClustersConfigDump", "EndpointsConfigDump")]),
                public_certificate_metadata=dict(source=client_cert, target=server_cert),
                config_sha256=config_hash, source_certificate_metadata_sha256=client_hash,
                target_certificate_metadata_sha256=server_hash, retained=before)


def require_narrow_inventory(context, state):
    directory = context.root.parent.parent / "source/policies"
    names = ("gateway-allow-nothing", "gateway-alpha-followups", "sink-allow-nothing", "sink-gateway-effects")
    expected = {"AuthorizationPolicy/" + name: load(directory / (name + ".json"))["spec"] for name in names}
    actual = {name: item["spec"] for name, item in state["policies"].items()}
    require(actual == expected, "exact retained narrow-stage policies without extra grants")


def wait_route(context, source, target, root, deadline):
    binding = load(context.root / "runtime/podip-route-binding.json")
    path = context.root / "runtime/podip-routes.json"
    require(digest(path.read_bytes()) == binding["manifest_sha256"], "original owned route manifest retained")
    require(identity(target) == binding["targets"][target["metadata"]["name"]], "exact registered target pod identity")
    attempts, budget, last_error = [], 0, None
    while time.monotonic() < deadline:
        if last_error is not None and deadline - time.monotonic() <= budget:
            break
        started = time.monotonic()
        try:
            state = observe(context, source, target, binding, root / "pod-route-readiness", deadline)
            remaining(deadline)
            return save(root, "pod-route-gate.json", dict(attempts=attempts, accepted=state))
        except AssertionError as error:
            last_error, budget = error, time.monotonic() - started
            attempts.append(dict(time=gst(), error=str(error)))
            save(root, "pod-route-gate.json", dict(attempts=attempts, accepted=None))
            if time.monotonic() < deadline:
                time.sleep(min(1, remaining(deadline)))
    raise RuntimeError("Read-only literal PodIP mTLS route gate failed within original absolute60 budget: " + str(last_error)) from last_error
