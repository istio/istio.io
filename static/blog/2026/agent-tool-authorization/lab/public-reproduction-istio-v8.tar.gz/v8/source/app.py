import argparse
import http.client
import json
import pathlib
import signal
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from records import digest, gst
from validation import authorize, parse


def write_audit(event, correlation, **values):
    path = pathlib.Path("/data/audit.jsonl")
    if path.stat().st_size > 4194304:
        raise RuntimeError("audit budget exhausted")
    item = dict(event=event, correlation=correlation, time=gst(), **values)
    with path.open("a") as stream:
        stream.write(json.dumps(item, sort_keys=True) + "\n")


def initialize(role):
    pathlib.Path("/data/audit.jsonl").touch(exist_ok=False)
    if role == "sink":
        connection = sqlite3.connect("/data/ledger.sqlite")
        connection.execute("CREATE TABLE actions (tenant_id TEXT NOT NULL, resource_id TEXT NOT NULL, operation TEXT NOT NULL, request_id TEXT NOT NULL)")
        connection.commit()
        connection.close()


def commit(body):
    connection = sqlite3.connect("/data/ledger.sqlite", timeout=5)
    connection.execute("INSERT INTO actions VALUES (?,?,?,?)", tuple(body[key] for key in ("tenant_id", "resource_id", "operation", "request_id")))
    connection.commit()
    connection.close()


def downstream(body, correlation):
    connection = http.client.HTTPConnection("action-sink.agent-tools.svc.cluster.local", 8080, timeout=10)
    raw = json.dumps(body, separators=(",", ":")).encode()
    write_audit("downstream", correlation, body_sha256=digest(raw))
    try:
        connection.request("POST", "/effects", raw, {"Content-Type": "application/json", "X-Lab-Request-ID": correlation, "Connection": "close"})
        response = connection.getresponse()
        payload = response.read(8193)
        if response.status != 201 or len(payload) > 8192:
            raise RuntimeError("sink did not acknowledge 201")
        if json.loads(payload) != body:
            raise RuntimeError("sink acknowledgement mismatch")
    finally:
        connection.close()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, format, *args):
        return

    def reply(self, status, payload):
        raw = json.dumps(payload, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)
        self.close_connection = True

    def headers_check(self):
        if self.headers.get("Content-Type") != "application/json":
            return 415
        if self.headers.get("Transfer-Encoding") is not None:
            return 400
        length = self.headers.get("Content-Length", "")
        if not length.isdecimal():
            return 400
        if int(length) > 8192:
            return 413
        return None

    def arguments(self):
        length = int(self.headers["Content-Length"])
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise ValueError("incomplete body")
        return parse(raw)

    def dispatch(self):
        correlation = self.headers.get("X-Lab-Request-ID", "")[:128]
        write_audit("handler", correlation, method=self.command, target=self.path)
        if self.command == "GET" and self.path == "/healthz":
            self.reply(200, {"healthy": True})
            return
        route = {"gateway": "/tools/followups", "sink": "/effects"}.get(self.server.role)
        if self.command != "POST" or self.path != route:
            self.reject(400, correlation, "literal route required")
            return
        status = self.headers_check()
        if status is not None:
            self.reject(status, correlation, "headers/body size")
            return
        self.action(correlation)

    def reject(self, status, correlation, reason):
        write_audit("rejected", correlation, status=status, reason=reason)
        self.reply(status, {"error": reason})

    def action(self, correlation):
        try:
            body = self.arguments()
            authorize(body)
            write_audit("accepted", correlation, arguments=body)
            operations = {"gateway": downstream, "sink": sink_action}
            operations[self.server.role](body, correlation)
            self.reply(201, body)
        except (ValueError, UnicodeError) as error:
            self.reject(400, correlation, str(error))
        except PermissionError as error:
            self.reject(403, correlation, str(error))
        except (OSError, http.client.HTTPException, RuntimeError) as error:
            self.reject(502, correlation, type(error).__name__)

    def do_GET(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch()

    def do_PUT(self):
        self.dispatch()

    def do_DELETE(self):
        self.dispatch()


def sink_action(body, correlation):
    commit(body)
    write_audit("committed", correlation, arguments=body)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("role", choices=("gateway", "sink", "witness", "client"))
    args = parser.parse_args()
    if args.role == "client":
        signal.pause()
        return
    initialize(args.role)
    server = HTTPServer(("0.0.0.0", 8080), Handler)
    server.role = args.role
    server.serve_forever()


if __name__ == "__main__":
    main()
