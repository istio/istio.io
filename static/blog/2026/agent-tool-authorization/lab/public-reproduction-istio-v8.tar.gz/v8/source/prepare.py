import argparse
import gzip
import hashlib
import io
import json
import os
import pathlib
import platform
import re
import socket
import shutil
import tarfile
import urllib.request
import zlib
from evidence import Recorder, digest, gst, load, save
from verify import require

NODE = "kindest/node:v1.36.4@sha256:099e049362a1526b2db71494e1947aae99bd16290d7c895f2b7ea312e3cbfaed"
IMAGES = {"node": ("kindest/node", NODE.split("@")[1]),
          "pilot": ("istio/pilot", "sha256:aeda10476eecca07f7d3a2776eda30d0452c133ea87b40335bc6031fb01de789"),
          "proxy": ("istio/proxyv2", "sha256:dc3e45795272bf93b30b8b1968e279fbfd5dcc05154cc35e0d13734d23c5b524"),
          "base": ("library/python", "sha256:b4d66d07136c546f1765eae2bfcce9a64fa95f37c717c02bedd06d0476d1dbbd")}
BINARY_URLS = {
    'kind_official': 'https://github.com/kubernetes-sigs/kind/releases/download/v0.33.0/kind-linux-amd64',
    'kubectl': 'https://dl.k8s.io/release/v1.36.4/bin/linux/amd64/kubectl',
    'istio': 'https://github.com/istio/istio/releases/download/1.31.1/istio-1.31.1-linux-amd64.tar.gz',
}
ISTIO_ARCHIVE_BYTES = 29786135
ISTIO_ARCHIVE_SHA256 = 'cb4af2e8a099acfc51368c1d15d4deab8321ae628554d4ee5c74f62ebe775857'
ISTIO_BINARY_BYTES = 105619618
ISTIO_BINARY_SHA256 = '8972b3c0e7d49ffd7c95d85d94a54296075c2aeeb03f01e23c3bbdf3f907689a'


def host_guard(expected):
    require(socket.gethostname() == expected, "exact primary hostname")
    require(platform.system() == "Linux", "Linux required")
    require(platform.machine() == "x86_64", "amd64 required")


def safe_root(root):
    target = pathlib.Path(root)
    require(target.is_absolute(), "absolute owned root")
    require(target.parent == pathlib.Path("/var/tmp"), "owned /var/tmp root")
    require(target.name.startswith("technical-blogs-20261009-istio-"), "owned prefix")
    for ancestor in (target, *target.parents):
        require(not ancestor.is_symlink(), "symlink ancestor")
    return target


def fetch(url, target):
    request = urllib.request.Request(url, headers={"User-Agent": "Istio-Contract-Verification"})
    with urllib.request.urlopen(request, timeout=30) as response:
        raw = response.read(104857601)
        require(len(raw) <= 104857600, "download size ceiling")
        pathlib.Path(target).write_bytes(raw)
        return dict(url=url, final_url=response.url, status=response.status,
                    sha256=digest(raw), bytes=len(raw), retrieved=gst())


def checked_binary(root, name, url, checksum_url):
    target = root / "bin" / name
    receipt = fetch(url, target)
    checksum = root / "downloads" / (name + ".sha256")
    official = fetch(checksum_url, checksum)
    expected = checksum.read_text().split()[0]
    require(receipt["sha256"] == expected, "official checksum mismatch: " + name)
    target.chmod(0o700)
    return dict(download=receipt, checksum=official, expected=expected)


def binaries(root, recorder):
    kind_url = "https://github.com/kubernetes-sigs/kind/releases/download/v0.33.0/kind-linux-amd64"
    kube_url = "https://dl.k8s.io/release/v1.36.4/bin/linux/amd64/kubectl"
    istio_url = "https://github.com/istio/istio/releases/download/1.31.1/istio-1.31.1-linux-amd64.tar.gz"
    result = {}
    result['kind_official'] = checked_binary(root, 'kind-official', kind_url, kind_url + '.sha256sum')
    result['kind'] = approved_kind(root)
    result["kubectl"] = checked_binary(root, "kubectl", kube_url, kube_url + ".sha256")
    archive = root / "downloads/istio.tar.gz"
    download = fetch(istio_url, archive)
    checksum = root / "downloads/istio.sha256"
    checksum_receipt = fetch(istio_url + ".sha256", checksum)
    require(download["sha256"] == checksum.read_text().split()[0], "Istio archive checksum")
    raw = extracted_istio(root)
    cli = root / "bin/istioctl"
    cli.write_bytes(raw)
    cli.chmod(0o700)
    result["istio"] = dict(download=download, checksum=checksum_receipt, binary_sha256=digest(raw))
    verify_binaries(root, result)
    save(root, 'versions.lock.json', dict(binaries=result, images={}))
    first = load(root / "ownership.json")["runs"][0]
    isolated = ["--kubeconfig", str(root / "runs" / first["id"] / "kubeconfig"), "--context", first["context"]]
    for name, arguments in (("kind", ["version"]), ("kubectl", isolated + ["version", "--client", "-o", "json"]), ("istioctl", isolated + ["version", "--remote=false"])):
        result[name + "_version"] = recorder.run([str(root / "bin" / name)] + arguments).stdout.decode()
    require(result['kind_version'].strip() == result['kind']['version'], 'custom launcher release/version semantics')
    verify_binaries(root, result)
    return result


def verify_download(path, receipt, url):
    require(not path.is_symlink() and path.is_file(), 'regular retained binary provenance')
    raw = path.read_bytes()
    require(receipt['url'] == url and receipt['status'] == 200, 'exact official download source')
    require(bool(receipt['final_url']), 'retained actual final download URL')
    require(len(raw) == receipt['bytes'] and digest(raw) == receipt['sha256'], 'actual retained download bytes: ' + path.name)
    return raw


def verify_checksum(root, binding, artifact, url):
    raw = verify_download(root / artifact, binding['checksum'], url)
    expected = raw.decode().split()[0]
    require(re.fullmatch('[0-9a-f]{64}', expected) is not None, 'official SHA256 syntax')
    require(binding['download']['sha256'] == expected, 'download equals retained official checksum')
    return expected


def extracted_istio(root):
    path = root / 'downloads/istio.tar.gz'
    require(not path.is_symlink() and path.is_file(), 'regular retained Istio release archive')
    require(path.stat().st_size == ISTIO_ARCHIVE_BYTES, 'exact Istio 1.31.1 archive size')
    require(digest(path.read_bytes()) == ISTIO_ARCHIVE_SHA256, 'exact Istio 1.31.1 archive SHA256')
    with tarfile.open(path) as archive:
        members = [item for item in archive.getmembers() if item.name == 'istio-1.31.1/bin/istioctl']
        require(len(members) == 1, 'unique actual extracted Istio executable')
        member = members[0]
        require(member.isfile() and not member.issparse(), 'regular actual Istio executable')
        require(member.size == ISTIO_BINARY_BYTES, 'exact Istio 1.31.1 executable size')
        raw = archive.extractfile(member).read(ISTIO_BINARY_BYTES + 1)
        require(len(raw) == ISTIO_BINARY_BYTES, 'complete exact Istio 1.31.1 executable')
        require(digest(raw) == ISTIO_BINARY_SHA256, 'exact Istio 1.31.1 executable SHA256')
        return raw


def verify_binaries(root, bindings):
    for key, name, suffix in [('kind_official', 'kind-official', '.sha256sum'), ('kubectl', 'kubectl', '.sha256')]:
        binding = bindings[key]
        raw = verify_download(root / 'bin' / name, binding['download'], BINARY_URLS[key])
        expected = verify_checksum(root, binding, 'downloads/' + name + '.sha256', BINARY_URLS[key] + suffix)
        require(digest(raw) == binding['expected'] == expected, 'official executable identity: ' + name)
    binding = bindings['istio']
    verify_download(root / 'downloads/istio.tar.gz', binding['download'], BINARY_URLS['istio'])
    verify_checksum(root, binding, 'downloads/istio.sha256', BINARY_URLS['istio'] + '.sha256')
    require(digest(extracted_istio(root)) == binding['binary_sha256'], 'retained extracted Istio identity')
    for name in ('kind', 'kubectl', 'istioctl'):
        verify_consumed_binary(root, name, bindings)


def verify_consumed_binary(root, name, bindings=None):
    if bindings is None:
        bindings = load(root / 'versions.lock.json')['binaries']
    binding_path = root / 'runtime-source-binding.json'
    if binding_path.exists():
        require(digest((root / 'versions.lock.json').read_bytes()) == load(binding_path)['versions_lock_sha256'], 'immutable executable provenance lock')
    keys = {'kind': ('kind', 'binary_sha256'), 'kubectl': ('kubectl', 'expected'), 'istioctl': ('istio', 'binary_sha256')}
    key, field = keys[name]
    path = root / 'bin' / name
    require(not path.is_symlink() and path.is_file(), 'regular consumed executable')
    require(digest(path.read_bytes()) == bindings[key][field], 'consumed executable unchanged: ' + name)
    if name == 'kind':
        verify_kind_binding(root, bindings[key])


def verify_kind_binding(root, binding):
    binary = '55ccf762eb3975ad00f7d51fbc37d0b813c93a93ac4f84eb6f61c548e46ecfa2'
    require(binding['custom'] is True and binding['binary_sha256'] == binary, 'same exact approved custom kind')
    require(digest((root / 'approved-kind-linux-amd64').read_bytes()) == binary, 'retained approved custom executable')
    contract = load(root / 'launcher.lock.json')
    authorization = load(root / 'launcher-authorization.json')
    require(authorization['approved'] is True and authorization['binary_sha256'] == binary, 'actual exact custom authorization')
    require(contract['binary_sha256'] == binary, 'unchanged custom contract executable')
    require(digest((root / 'launcher.lock.json').read_bytes()) == binding['contract_sha256'] == authorization['contract_sha256'], 'actual prepared custom contract binding')


def approved_kind(root):
    contract = load(root / 'launcher.lock.json')
    authorization = load(root / 'launcher-authorization.json')
    require(authorization['approved'] is True, 'explicit human launcher authorization required')
    require(authorization['contract_sha256'] == digest((root / 'launcher.lock.json').read_bytes()), 'approved exact launcher contract')
    require(contract['upstream_commit'] == '407a9675e6d9af1200b5f57f9ca52ec6cdacce74', 'exact kind v0.33.0 release commit')
    require(contract['logging_args'] == ['--log-driver=json-file', '--log-opt=max-size=4m', '--log-opt=max-file=2'], 'reviewed narrow logging contract')
    binary = root / 'approved-kind-linux-amd64'
    require(not binary.is_symlink(), 'regular task-local launcher binary')
    require(digest(binary.read_bytes()) == contract['binary_sha256'], 'externally frozen custom launcher checksum')
    target = root / 'bin/kind'
    require(not target.exists(), 'fresh custom launcher installation')
    shutil.copyfile(binary, target)
    target.chmod(0o700)
    return dict(custom=True, binary_sha256=contract['binary_sha256'], contract_sha256=authorization['contract_sha256'], upstream_release='v0.33.0', version=contract['version'], official_release_binary_is_distinct=True)


def registry_auth(repository):
    url = "https://auth.docker.io/token?service=registry.docker.io&scope=repository:" + repository + ":pull"
    with urllib.request.urlopen(url, timeout=30) as response:
        return json.load(response)["token"]


def registry_get(repository, ref, token, kind="manifests"):
    url = "https://registry-1.docker.io/v2/%s/%s/%s" % (repository, kind, ref)
    accept = ", ".join(("application/vnd.oci.image.index.v1+json", "application/vnd.docker.distribution.manifest.list.v2+json", "application/vnd.oci.image.manifest.v1+json", "application/vnd.docker.distribution.manifest.v2+json"))
    request = urllib.request.Request(url, headers={"Authorization": "Bearer " + token, "Accept": accept})
    return urllib.request.urlopen(request, timeout=30)


def registry_json(repository, ref, token):
    with registry_get(repository, ref, token) as response:
        raw = response.read(1048577)
        require(len(raw) <= 1048576, "manifest ceiling")
        return json.loads(raw), "sha256:" + digest(raw)


def linux_manifest(repository, reference, token):
    index, identity = registry_json(repository, reference, token)
    require(identity == reference, 'frozen immutable image reference')
    if "manifests" not in index:
        return index, identity, index, identity
    matches = [x for x in index["manifests"] if x.get("platform", {}).get("os") == "linux" and x.get("platform", {}).get("architecture") == "amd64"]
    require(len(matches) == 1, "unique Linux amd64 manifest")
    manifest, selected = registry_json(repository, matches[0]["digest"], token)
    require(selected == matches[0]["digest"], "selected manifest digest")
    return index, identity, manifest, selected


def layer_size(repository, layer, token):
    decompressor = zlib.decompressobj(16 + zlib.MAX_WBITS)
    total = 0
    hashed = hashlib.sha256()
    with registry_get(repository, layer["digest"], token, "blobs") as response:
        while True:
            data = response.read(65536)
            if not data:
                break
            hashed.update(data)
            total += len(decompressor.decompress(data))
            require(total <= 8 * 1024 ** 3, "single image layer exceeds shared budget")
    total += len(decompressor.flush())
    require("sha256:" + hashed.hexdigest() == layer["digest"], "registry blob digest")
    return dict(digest=layer["digest"], compressed=layer["size"], unpacked_tar_bytes=total)


def verified_config(root, name, repository, descriptor, token):
    require(0 < descriptor['size'] <= 1048576, 'config descriptor size ceiling')
    with registry_get(repository, descriptor['digest'], token, 'blobs') as response:
        raw = response.read(1048577)
    require(len(raw) <= 1048576, 'config raw byte ceiling')
    require(len(raw) == descriptor['size'], 'config descriptor byte length')
    require('sha256:' + digest(raw) == descriptor['digest'], 'raw config descriptor digest')
    target = root / 'references' / ('registry-' + name + '-config.json')
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as output:
        output.write(raw)
    return json.loads(raw)


def image_lock(root, name, repository, reference):
    token = registry_auth(repository)
    index, index_hash, manifest, selected = linux_manifest(repository, reference, token)
    config = verified_config(root, name, repository, manifest['config'], token)
    require(config["architecture"] == "amd64" and config["os"] == "linux", "image platform")
    layers = [layer_size(repository, item, token) for item in manifest["layers"]]
    raw = dict(repository=repository, reference=reference, index=index, index_digest=index_hash,
               manifest=manifest, manifest_digest=selected, config=config, layers=layers,
               image="docker.io/" + repository + "@" + selected, config_digest=manifest["config"]["digest"], config_artifact='references/registry-' + name + '-config.json',
               unpacked_tar_bytes=sum(x["unpacked_tar_bytes"] for x in layers), retrieved=gst())
    save(root, "references/registry-" + name + ".json", raw)
    return raw


def prepare(root, expected):
    host_guard(expected)
    safe_root(root)
    recorder = Recorder(root / "preparation")
    (root / "bin").mkdir(exist_ok=False)
    (root / "downloads").mkdir(exist_ok=False)
    lock = dict(binaries=binaries(root, recorder), images={})
    save(root, "versions.lock.json", lock)
    for name, (repository, reference) in IMAGES.items():
        lock["images"][name] = image_lock(root, name, repository, reference)
        save(root, "versions.lock.json", lock)
    projection = sum(x["unpacked_tar_bytes"] for x in lock["images"].values())
    require(projection + 2 * 1024 ** 3 <= 8 * 1024 ** 3, "uncompressed image/build/evidence budget")
    save(root, "disk-projection.json", dict(image_tar_bytes=projection, build_evidence_reserve=2 * 1024 ** 3, ceiling=8 * 1024 ** 3))
    verify_binaries(root, lock['binaries'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("expected_hostname")
    args = parser.parse_args()
    try:
        prepare(args.root, args.expected_hostname)
    except Exception as error:
        save(args.root, "preparation-failure.json", dict(error=type(error).__name__, message=str(error), time=gst()))
        raise


if __name__ == "__main__":
    main()
