import json
import re

KEYS = frozenset(("tenant_id", "resource_id", "operation", "request_id"))
ALLOWED = {"tenant_id": "alpha", "resource_id": "ticket-1042", "operation": "create_followup"}
REQUEST_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z", re.ASCII)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def bounded_string(value):
    return isinstance(value, str) and 0 < len(value) <= 128


def parse(raw):
    body = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object)
    if not isinstance(body, dict):
        raise ValueError("JSON object required")
    if frozenset(body) != KEYS:
        raise ValueError("exact required keys")
    if not all(bounded_string(value) for value in body.values()):
        raise ValueError("bounded strings required")
    if REQUEST_ID.fullmatch(body["request_id"]) is None:
        raise ValueError("unsafe request ID")
    return body


def authorize(body):
    if any(body[key] != value for key, value in ALLOWED.items()):
        raise PermissionError("arguments unauthorized")
    return body
