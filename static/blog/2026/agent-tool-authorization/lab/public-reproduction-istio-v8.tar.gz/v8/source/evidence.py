import datetime
import hashlib
import json
import pathlib
import subprocess
import os
import time


def gst():
    zone = datetime.timezone(datetime.timedelta(hours=4))
    return datetime.datetime.now(zone).strftime("%Y-%m-%d %H:%M:%S.%f GST")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(root, name, value):
    target = pathlib.Path(root) / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    return value


def publish_json(root, name, value):
    target = pathlib.Path(root) / name
    pending = target.with_name(target.name + '.pending')
    with pending.open('x') as output:
        output.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
        output.flush()
        os.fsync(output.fileno())
    os.link(pending, target)
    pending.unlink()
    descriptor = os.open(target.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    return value


def save_once(root, name, value):
    target = pathlib.Path(root) / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x") as output:
        output.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
    return value


def load(path):
    return json.loads(pathlib.Path(path).read_text())


def raise_errors(errors, outcome=None):
    if not errors:
        return
    error = RuntimeError("; ".join(type(item).__name__ + ": " + str(item) for item in errors))
    error.errors = tuple(errors)
    error.outcome = outcome or {}
    raise error


class Recorder:
    def __init__(self, root, defer_persistence=False, supervisor=None):
        self.root = pathlib.Path(root)
        self.sequence = 0
        self.supervisor = supervisor
        self.guard = supervisor.check if supervisor is not None else None
        self.check_guard()
        self.defer_persistence = defer_persistence
        self.persistence_errors = []
        self.results = []
        self.pending = []
        self.flushing = False
        self.capture_id = str(time.time_ns())
        self.persist(self.initialize)

    def initialize(self):
        self.root.mkdir(parents=True, exist_ok=True)
        journal = self.root / "commands.jsonl"
        if not self.defer_persistence and journal.exists():
            self.sequence = len(journal.read_text().splitlines())

    def persist(self, call, *args):
        if self.defer_persistence and not self.flushing:
            self.pending.append((call, args))
            return
        try:
            return call(*args)
        except Exception as error:
            if not self.defer_persistence:
                raise
            self.persistence_errors.append(error)

    def flush_persistence(self):
        pending, self.pending = self.pending, []
        self.flushing = True
        try:
            for call, args in pending:
                self.persist(call, *args)
        finally:
            self.flushing = False

    def command_prefix(self):
        prefix = "commands/%05d" % self.sequence
        if self.defer_persistence:
            prefix += "-" + self.capture_id
        return prefix

    def run(self, argv, timeout=30, check=True, env=None, deadline=None):
        self.sequence += 1
        prefix = self.command_prefix()
        started = gst()
        result, error = self.execute(argv, timeout, env, deadline)
        self.persist(self.write_streams, prefix, result)
        record = dict(argv=argv, cwd=str(pathlib.Path.cwd()), start=started,
                      end=gst(), exit=result.returncode, timeout=timeout,
                      stdout=prefix + ".stdout", stderr=prefix + ".stderr",
                      environment=dict(uid=os.geteuid(), PATH_sha256=digest(os.environ.get("PATH", "").encode()),
                                       DOCKER_CONFIG=os.environ.get("DOCKER_CONFIG"), credentials="not recorded"))
        self.results.append(record)
        self.persist(self.write_journal, record)
        if error is not None:
            self.persist(save, self.root, prefix + ".stop.json", dict(reason=type(error).__name__, message=str(error), actual_exit=result.returncode))
            raise error
        if result.returncode is None:
            raise RuntimeError("Command deadline exceeded; captured streams preserved")
        if max(len(result.stdout), len(result.stderr)) > 1048576:
            self.persist(save, self.root, prefix + ".overflow.json", dict(stdout_bytes=len(result.stdout), stderr_bytes=len(result.stderr), stdout_hash=digest(result.stdout), stderr_hash=digest(result.stderr)))
            raise RuntimeError("Command response exceeded 1 MiB; prefixes and hashes preserved")
        if check and result.returncode:
            raise RuntimeError("Command failed: %s; see %s" % (argv[0], prefix))
        return result

    def write_journal(self, record):
        with (self.root / "commands.jsonl").open("a") as output:
            output.write(json.dumps(record) + "\n")

    def check_guard(self):
        if self.guard is not None:
            self.guard()

    def execute(self, argv, timeout, env, deadline):
        from process_guard import remaining
        lifecycle = __import__("resources").lifecycle_deadline
        deadline = min(lifecycle - 15, deadline) if deadline is not None else lifecycle - 15
        remaining(deadline, timeout)
        self.check_guard()
        self.check_binary(argv)
        if deadline is not None and time.monotonic() >= deadline:
            raise subprocess.TimeoutExpired(argv, timeout)
        process = self.launch_process(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        error = None
        try:
            stdout, stderr = self.wait(process, timeout, deadline)
            self.check_binary(argv)
            self.check_guard()
        except Exception as stopped:
            error = stopped
            stdout, stderr = self.terminate(process)
        finally:
            self.release_process(process)
        return subprocess.CompletedProcess(argv, process.returncode, stdout, stderr), error

    def check_binary(self, argv):
        path = pathlib.Path(argv[0])
        if path.parent.name == 'bin' and path.name in {'kind', 'kubectl', 'istioctl'}:
            from prepare import verify_consumed_binary
            verify_consumed_binary(path.parent.parent, path.name)

    def launch_process(self, argv, **kwargs):
        from process_guard import remaining
        remaining(__import__('resources').lifecycle_deadline, 1)
        if self.supervisor is not None:
            return self.supervisor.launch_process(argv, **kwargs)
        return subprocess.Popen(argv, **kwargs)

    def release_process(self, process):
        if self.supervisor is not None:
            self.supervisor.release_process(process)

    def wait(self, process, timeout, absolute_deadline):
        deadline = time.monotonic() + timeout
        if absolute_deadline is not None:
            deadline = min(deadline, absolute_deadline)
        while True:
            self.check_guard()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise subprocess.TimeoutExpired(process.args, timeout)
            try:
                streams = process.communicate(timeout=min(0.05, remaining))
                if time.monotonic() >= deadline:
                    raise subprocess.TimeoutExpired(process.args, timeout)
                return streams
            except subprocess.TimeoutExpired:
                continue

    def terminate(self, process):
        from process_guard import remaining
        deadline = __import__("resources").lifecycle_deadline
        if self.supervisor is not None:
            self.supervisor.stop_process(process)
        elif process.poll() is None:
            process.terminate()
        try:
            return process.communicate(timeout=remaining(deadline, 5))
        except subprocess.TimeoutExpired:
            process.kill()
            return process.communicate(timeout=remaining(deadline, 5))

    def write_streams(self, prefix, result):
        destination = self.root / prefix
        destination.parent.mkdir(exist_ok=True)
        for suffix, raw in ((".stdout", result.stdout), (".stderr", result.stderr)):
            self.persist(self.write_stream, destination.with_suffix(suffix), raw[:1048576])

    def write_stream(self, path, raw):
        with path.open("xb") as output:
            output.write(raw)
