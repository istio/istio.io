import argparse
import pathlib
import shutil
import os
from prepare import host_guard, safe_root
from evidence import Recorder, gst, load, save
from resources import docker_json, same_baseline, initial_baseline
from verify import require
from verify_cleanup import never_created


def candidates(root):
    entries = load(root / "owned-images.json")
    entries.append(load(root / "owned-node-index.json"))
    build = load(root / "build.json")
    entries.append(dict(build, image=build["tag"]))
    images = {x["image"] for x in entries if x.get("preexisting") is False and x.get("ownership_proven") is True}
    return sorted(images)


def finish(root, expected, monitor=None):
    require(monitor is not None, "final finish requires guarded serial lifecycle")
    host_guard(expected)
    safe_root(root)
    before = initial_baseline(root)
    for config in load(root / "ownership.json")["runs"]:
        validate_run_cleanup(root, config)
    os.environ["DOCKER_CONFIG"] = str(root / "docker-config")
    recorder = Recorder(root / "final-teardown", supervisor=monitor)
    removed = []
    for image in candidates(root):
        recorder.run(["docker", "image", "rm", "--no-prune", image])
        removed.append(image)
    state = dict(images_removed=removed, time=gst(), baseline=same_baseline(before, recorder),
                 build_cache="not pruned; exact cache ownership was not recorded", remote_root=str(root))
    recorder.check_guard()
    save(root, "cleanup.json", state)


def validate_run_cleanup(root, config):
    unstarted = never_created(root, config)
    require(unstarted is not None, "run creation ownership unknown; retain resources")
    if unstarted:
        return
    run = root / "runs" / config["id"]
    receipt = load(run / "export-receipt.json")
    require(receipt["verified"] and receipt["run_id"] == config["id"], "each created run exported before final cleanup")
    node = load(run / "runtime/owned-node.json")
    network = load(run / "runtime/owned-network.json")
    cleanup = load(run / "cleanup.json")
    require(cleanup["node_deleted"] == node["id"], "exact owned node cleanup receipt")
    require(cleanup["network_deleted"] == network["Id"], "exact owned network cleanup receipt")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("expected_hostname")
    args = parser.parse_args()
    finish(args.root, args.expected_hostname)


if __name__ == "__main__":
    main()
