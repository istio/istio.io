import argparse
import pathlib
from context import Context
from evidence import Recorder, load, save


def inspect(root, index):
    config = load(root / "ownership.json")["runs"][index]
    run = root / "runs" / config["id"]
    context = Context(run, config, Recorder(run))
    context.guard()
    queries = [("pods", ["get", "pods", "-n", "agent-tools"]),
               ("namespace", ["get", "namespace", "agent-tools"]),
               ("webhooks", ["get", "mutatingwebhookconfigurations"]),
               ("injector", ["get", "configmap", "istio-sidecar-injector", "-n", "istio-system"]),
               ("istiod", ["get", "deployment", "istiod", "-n", "istio-system"]),
               ("mesh", ["get", "configmap", "istio", "-n", "istio-system"])]
    for name, args in queries:
        save(run, "diagnostics/" + name + ".json", context.obj(args))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=pathlib.Path)
    parser.add_argument("index", type=int)
    args = parser.parse_args()
    inspect(args.root, args.index)


if __name__ == "__main__":
    main()
