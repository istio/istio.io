"""Neutral package, operator and receipt boundaries."""

import hashlib
import json
import os
import pathlib
import re
import tarfile

CAP = 8 * 1024 ** 3
SOURCE_PIN = 'acb7da37f0d22b5df42170ce7ac36f5d4de20abd611f45b834b7bf995206da40'
KIND_PIN = '55ccf762eb3975ad00f7d51fbc37d0b813c93a93ac4f84eb6f61c548e46ecfa2'
RENDERED = {'source/istio-install.json', 'source/workloads.json', 'source/policies/namespace-strict.json',
            'source/policies/gateway-allow-nothing.json', 'source/policies/gateway-alpha-followups.json',
            'source/policies/sink-allow-nothing.json', 'source/policies/sink-gateway-effects.json'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def regular_path(path):
    path = pathlib.Path(path)
    require(path.is_absolute(), 'absolute path required')
    for part in (path, *path.parents):
        require(not part.is_symlink(), 'no symlink path: ' + str(path))
    return path


def sha(path):
    hashed = hashlib.sha256()
    with regular_path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(65536), b''):
            hashed.update(chunk)
    return hashed.hexdigest()


def unique_object(pairs):
    result = {}
    for name, value in pairs:
        require(name not in result, 'duplicate JSON key')
        result[name] = value
    return result


def read_json(path):
    raw = regular_path(path).read_bytes()
    require(len(raw) <= 1048576, 'bounded JSON input')
    return json.loads(raw, object_pairs_hook=unique_object)


def atomic_json(path, value):
    path = regular_path(path)
    pending = path.with_name(path.name + '.pending')
    require(not path.exists(), 'fresh receipt target')
    with pending.open('x') as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())
    require(not path.exists(), 'receipt destination collision')
    os.link(pending, path)
    pending.unlink()
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def check_file(path, expected):
    require(re.fullmatch('[0-9a-f]{64}', expected) is not None, 'SHA256 syntax')
    require(sha(path) == expected, 'file binding mismatch: ' + str(path))


def source_boundary(root, prepared=False):
    check_file(root / 'SOURCE_MANIFEST.json', SOURCE_PIN)
    manifest = read_json(root / 'SOURCE_MANIFEST.json')
    actual = {p.relative_to(root).as_posix() for p in (root / 'source').rglob('*') if p.is_file()}
    require(actual == {n for n in manifest['files'] if n.startswith('source/')}, 'exact V8 source inventory')
    for name, expected in manifest['files'].items():
        regular_path(root / name)
        if not prepared or name not in RENDERED:
            check_file(root / name, expected)
    if prepared:
        from runtime import validate_bindings
        validate_bindings(root)


def package_boundary(package, expected):
    check_file(package / 'PUBLIC_MANIFEST.json', expected)
    manifest = read_json(package / 'PUBLIC_MANIFEST.json')
    require(len(manifest['files']) <= 100, 'bounded package inventory')
    actual = {p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file()}
    require(actual == set(manifest['files']) | {'PUBLIC_MANIFEST.json'}, 'exact public package inventory')
    for name, pin in manifest['files'].items():
        relative = pathlib.PurePosixPath(name)
        require(not relative.is_absolute() and '..' not in relative.parts, 'safe package member')
        check_file(package / name, pin)
    source_boundary(package / 'v8')
    check_file(package / 'launcher/kind-linux-amd64', KIND_PIN)
    return manifest


def archive_boundary(archive_path, expected, package, manifest):
    check_file(archive_path, expected)
    require(archive_path.stat().st_size < 32 * 1024 ** 2, 'small public archive')
    pins = dict(manifest['files'], **{'PUBLIC_MANIFEST.json': sha(package / 'PUBLIC_MANIFEST.json')})
    with tarfile.open(archive_path) as archive:
        members = archive.getmembers()
        require(len(members) == len(pins), 'exact public archive member count')
        names = set()
        for member in members:
            require(member.isfile() and not member.issparse(), 'regular public archive members')
            require(member.name not in names and member.name in pins, 'exact unique package archive member')
            require(0 <= member.size <= 16 * 1024 ** 2, 'public member byte ceiling')
            names.add(member.name)
            raw = archive.extractfile(member).read()
            require(hashlib.sha256(raw).hexdigest() == pins[member.name], 'archive equals fresh extracted package')
        require(names == set(pins), 'complete public archive')


def authorization(value, config_sha, package):
    require(value['approved'] is True, 'explicit human launcher approval')
    require(value['operator_config_sha256'] == config_sha, 'approval bound to exact operator data')
    require(bool(value['actor']) and bool(value['provenance']), 'external human grant provenance')
    require(value['binary_sha256'] == KIND_PIN, 'exact launcher grant')
    require(value['contract_sha256'] == sha(package / 'launcher/launcher.lock.json'), 'exact launcher contract grant')


def run_config(value):
    require(set(value) == {'id', 'cluster', 'network', 'node', 'context', 'api_port'}, 'exact owned run fields')
    for key in ['id', 'cluster', 'network']:
        require(re.fullmatch('[a-z][a-z0-9-]{1,49}', value[key]) is not None, 'safe owned identity')
    require(value['cluster'] == value['network'], 'kind isolated network equals cluster')
    require(value['node'] == value['cluster'] + '-control-plane', 'exact kind node identity')
    require(value['context'] == 'kind-' + value['cluster'], 'exact kind context identity')
    require(type(value['api_port']) is int and 1024 <= value['api_port'] <= 65535, 'explicit unprivileged port')


def operator(value):
    require(value['schema'] == 'istio-public-operator-v1', 'operator schema')
    require(value['execution_approved'] is True, 'explicit owned lifecycle approval')
    require(value['preserve_current_foreign'] is True, 'explicit current foreign preservation')
    root = regular_path(value['root'])
    require(root.parent == pathlib.Path('/var/tmp'), 'owned staging parent')
    require(re.fullmatch('technical-blogs-20261009-istio-[a-z0-9-]{1,80}', root.name) is not None, 'unchanged V8 safe-root prefix')
    require(len(value['runs']) == 2, 'exact two serial runs')
    for run in value['runs']:
        run_config(run)
    for key in ['id', 'cluster', 'api_port']:
        require(len({r[key] for r in value['runs']}) == 2, 'distinct serial identities and ports')
    require(bool(value['hostname']), 'explicit own hostname')
    require(value['prior_owned_absence']['separately_verified'] is True, 'old owned cleanup separately completed')
    return root


def require_foreign(before, current):
    for identifier, state in before['containers'].items():
        require(current['containers'].get(identifier) == state, 'current foreign container changed: ' + identifier)
    for identifier, state in before['networks'].items():
        require(current['networks'].get(identifier) == state, 'current foreign network changed: ' + identifier)
    for group in ['images', 'volumes']:
        require(set(before[group]) <= set(current[group]), 'foreign ' + group + ' removed')
    require(before['vm_max_map_count'] == current['vm_max_map_count'], 'host setting changed')


def export_binding(archive, run_id):
    from evidence import digest
    from verify_export import safe_members, validated_snapshot
    with tarfile.open(archive) as source:
        snapshot, name = validated_snapshot(source, safe_members(source), run_id)
    return dict(archive_sha256=sha(archive), manifest_sha256=digest(snapshot[name]), files=len(snapshot) - 1)


def validate_receipt(value, run_id, expected):
    require(set(value) == {'run_id', 'verified', 'archive_sha256', 'files', 'manifest_sha256'}, 'exact receipt fields')
    require(value['verified'] is True and value['run_id'] == run_id, 'exact verified export identity')
    require(type(value['files']) is int and value['files'] > 0, 'verified nonempty export')
    for field in ['archive_sha256', 'manifest_sha256', 'files']:
        require(value[field] == expected[field], 'actual export receipt binding: ' + field)


def returned_receipt(value, run_id, expected, manifest_sha, checker_sha):
    require(set(value) == {'receipt', 'checker'}, 'exact returned verifier envelope')
    validate_receipt(value['receipt'], run_id, expected)
    closure = value['checker']
    keys = {'actual_exit', 'natural_exit', 'drained', 'timed_out', 'archive_sha256', 'receipt_sha256',
            'public_manifest_sha256', 'checker_sha256', 'stdout_sha256', 'stderr_sha256'}
    require(set(closure) == keys, 'exact checker closure fields')
    require(type(closure['actual_exit']) is int and closure['actual_exit'] == 0, 'observed checker actual zero exit')
    require(type(closure['natural_exit']) is int and closure['natural_exit'] == 0, 'observed checker natural zero exit')
    require(closure['drained'] is True and closure['timed_out'] is False, 'actual checker output drain')
    require(closure['public_manifest_sha256'] == manifest_sha and closure['checker_sha256'] == checker_sha, 'exact public checker bytes')
    require(closure['archive_sha256'] == expected['archive_sha256'], 'checker archive binding')
    for name in ['stdout_sha256', 'stderr_sha256', 'receipt_sha256']:
        require(re.fullmatch('[0-9a-f]{64}', closure[name]) is not None, 'checker closure SHA syntax')
    return value['receipt']
