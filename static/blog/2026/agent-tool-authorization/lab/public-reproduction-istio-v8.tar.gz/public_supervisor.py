"""All-phase monitor, exact process cancellation and independent export bridge."""

import os
import pathlib
import signal
import threading
import time
from public_common import atomic_json, read_json, require, require_foreign, sha, export_binding, returned_receipt
from public_budget import enforce_budget, measure
from public_host import foreign


class Bridge:
    def __init__(self, root, exchange, config, manifest_sha):
        self.deadline = __import__("resources").lifecycle_deadline
        self.checker_sha = sha(pathlib.Path(__file__).parent / "v8/source/verify_export.py")
        self.root, self.exchange = root, exchange
        self.manifest_sha = manifest_sha
        self.entries = [(run['id'] + '-before-teardown', run['id'], root / 'runs' / run['id'] / 'export-receipt.json') for run in config['runs']]
        self.entries.append(('cleanup-verified', 'cleanup-verified', root / 'final-export-receipt.json'))
        self.completed = []
        self.advertised = set()
        self.bindings = {}
        self.lock = threading.Lock()

    def pump(self, check):
        if not self.lock.acquire(blocking=False):
            return
        try:
            if len(self.completed) == 3:
                return
            entry = self.entries[len(self.completed)]
            self.advance(entry, check)
        finally:
            self.lock.release()

    def advance(self, entry, check):
        name, run_id, target = entry
        archive = self.root / ('evidence-' + name + '.tar.gz')
        binding_path = self.root / ('export-archive-' + name + '.json')
        if not archive.exists():
            return
        if name not in self.advertised:
            binding = export_binding(archive, name)
            self.publish(name, archive, binding, check)
            self.bindings[name] = binding
            self.advertised.add(name)
        binding = self.bindings[name]
        receipt_path = self.exchange / ('receipt-' + name + '.json')
        if not receipt_path.exists():
            return
        check()
        envelope = read_json(receipt_path)
        receipt = returned_receipt(envelope, run_id, binding, self.manifest_sha, self.checker_sha)
        from evidence import digest
        canonical = (__import__("json").dumps(receipt, indent=2, sort_keys=True) + "\n").encode()
        require(envelope["checker"]["receipt_sha256"] == digest(canonical), "exact child receipt bytes")
        require(read_json(binding_path)['sha256'] == binding['archive_sha256'], 'actual runtime export binding before receipt return')
        require(sha(archive) == binding['archive_sha256'], 'original export unchanged before receipt return')
        require(sha(self.exchange / archive.name) == binding['archive_sha256'], 'exchange archive unchanged')
        atomic_json(target, receipt)
        self.completed.append(dict(export_id=name, receipt=receipt, receipt_sha256=sha(receipt_path)))

    def publish(self, name, archive, binding, check):
        target = self.exchange / archive.name
        pending = target.with_name(target.name + '.pending')
        with archive.open('rb') as source, pending.open('xb') as output:
            for chunk in iter(lambda: source.read(65536), b''):
                check()
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        require(sha(pending) == binding['archive_sha256'], 'exchange copy integrity')
        os.link(pending, target)
        pending.unlink()
        atomic_json(self.exchange / ('request-' + name + '.json'), dict(archive=str(target), run_id=name,
                    receipt_target=str(self.exchange / ('receipt-' + name + '.json')), public_manifest_sha256=self.manifest_sha,
                    archive_sha256=binding['archive_sha256'], receipt_wait_seconds=180, original_deadline=self.deadline))
        print('VERIFY_REQUEST ' + str(self.exchange / ('request-' + name + '.json')), flush=True)


def make_monitor(runtime, root, exchange, initial_free, config, before, budget, deadline, bridge):
    from process_guard import remaining
    class LifecycleMonitor(runtime.Monitor):
        def __init__(self):
            super().__init__(exchange, initial_free)
            self.started = False
            self.closing = False
            self.peaks = {key: budget[key]['latest_peak_used_bytes'] for key in ['root', 'docker']}
            self.journal = (exchange / 'whole-lifecycle-resources.jsonl').open('x')

        def base_check(self):
            super().check()
            require(time.monotonic() < deadline, 'original whole lifecycle deadline')
            if self.started and not self.closing:
                require(self.thread.is_alive(), 'whole lifecycle monitor died')

        def check(self):
            self.base_check()
            bridge.pump(self.base_check)
            self.base_check()

        def observe(self):
            import json
            from resources import available_memory, enforce, filesystem
            measured = measure()
            peaks = enforce_budget(budget, measured)
            self.peaks = {key: max(self.peaks[key], peaks[key]) for key in self.peaks}
            state = dict(root=filesystem('/'), available_memory=available_memory())
            enforce(state, initial_free)
            require_foreign(before, foreign(self))
            self.journal.write(json.dumps(dict(monotonic=time.monotonic(), state=state, measured=measured, peaks=self.peaks)) + '\n')
            self.journal.flush()
            self.base_check()

        def loop(self):
            while not self.stop.is_set():
                try:
                    self.observe()
                except Exception as error:
                    self.cancel(error)
                    return
                self.stop.wait(5)

        def start(self):
            self.observe()
            super().start()
            self.started = True
            self.check()

        def abort_owned(self):
            outcomes = []
            for declared in config['runs']:
                run = root / 'runs' / declared['id']
                if (run / 'runtime/owned-node.json').exists():
                    outcomes.append(runtime.stop_owned_node(run, declared))
            return dict(owned=outcomes, stopped=all(item['stopped'] for item in outcomes))

        def close(self):
            self.base_check()
            self.closing = True
            self.stop.set()
            self.thread.join(timeout=remaining(deadline, 40))
            require(not self.thread.is_alive(), 'bounded monitor drain')
            self.observe()
            self.owner.close()
            self.base_check()
            self.journal.close()
            self.base_check()

    return LifecycleMonitor()
