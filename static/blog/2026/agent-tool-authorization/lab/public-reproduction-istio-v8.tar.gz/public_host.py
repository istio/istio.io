"""Bounded read-only host observations and declared fresh ownership."""

import json
import os
import pathlib
import platform
import socket
import subprocess
import sys
from public_common import read_json, require

CONTAINERS = '{"id":{{json .Id}},"name":{{json .Name}},"running":{{json .State.Running}},"image":{{json .Image}},"mode":{{json .HostConfig.NetworkMode}},"networks":{{json .NetworkSettings.Networks}}}'


def output(argv, supervisor=None):
    import time
    from process_guard import remaining
    deadline = supervisor.deadline if supervisor is not None else __import__("resources").lifecycle_deadline
    remaining(deadline, 30)
    if supervisor is None:
        process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    else:
        process = supervisor.launch_process(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        stdout, stderr = process.communicate(timeout=remaining(deadline, 30))
        require(time.monotonic() < deadline, 'original deadline after host probe')
        require(process.returncode == 0, 'read-only host probe failed: ' + argv[1])
        require(max(len(stdout), len(stderr)) <= 1048576, 'bounded host inventory output')
        return stdout.decode().splitlines()
    except BaseException:
        process.kill()
        process.communicate(timeout=remaining(deadline, 5))
        raise
    finally:
        if supervisor is not None:
            supervisor.release_process(process)


def foreign(supervisor=None):
    ids = output(['docker', 'ps', '-aq', '--no-trunc'], supervisor)
    require(len(ids) <= 1000 and len(set(ids)) == len(ids), 'bounded unique current containers')
    containers = {}
    if ids:
        records = output(['docker', 'inspect', '--format', CONTAINERS, *ids], supervisor)
        containers = {item['id']: item for item in map(json.loads, records)}
        require(set(containers) == set(ids), 'complete current foreign inventory')
    network_lines = output(['docker', 'network', 'ls', '--no-trunc', '--format', '{{json .}}'], supervisor)
    networks = {item['ID']: item['Name'] for item in map(json.loads, network_lines)}
    images = sorted(set(output(['docker', 'image', 'ls', '-aq', '--no-trunc'], supervisor)))
    volumes = sorted(output(['docker', 'volume', 'ls', '-q'], supervisor))
    return dict(containers=containers, networks=networks, images=images, volumes=volumes,
                vm_max_map_count=pathlib.Path('/proc/sys/vm/max_map_count').read_text().strip())


def tools(hostname):
    require(socket.gethostname() == hostname, 'exact operator hostname')
    require(platform.system() == 'Linux' and platform.machine() == 'x86_64', 'Linux amd64 required')
    require(sys.executable == '/usr/bin/python3' and sys.version_info[:3] == (3, 10, 12), 'exact system Python3.10.12')
    require(pathlib.Path('/var/lib/docker').is_dir(), 'required original Docker filesystem')
    require('DOCKER_HOST' not in os.environ and 'DOCKER_CONTEXT' not in os.environ, 'local Docker only')
    root = output(['docker', 'info', '--format', '{{.DockerRootDir}}'])
    require(root == ['/var/lib/docker'], 'same unchanged Docker data path')


def free_port(port):
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', port))


def prior_absent(value, state):
    require(value['separately_verified'] is True, 'separate prior owned cleanup')
    for key in ['containers', 'networks', 'volumes']:
        require(not set(value[key]) & set(state[key]), 'old owned residue retained; separate cleanup required')
    names = {item['name'].lstrip('/') for item in state['containers'].values()}
    require(not names & set(value['node_names']), 'old owned node name remains')
    require(not set(state['networks'].values()) & set(value['network_names']), 'old owned network name remains')


def fresh(config, state):
    prior_absent(config['prior_owned_absence'], state)
    names = {item['name'].lstrip('/') for item in state['containers'].values()}
    for run in config['runs']:
        require(run['node'] not in names, 'owned node collision')
        require(run['network'] not in state['networks'].values(), 'owned network collision')
        require(not output(['docker', 'ps', '-aq', '--filter', 'label=io.x-k8s.kind.cluster=' + run['cluster']]), 'owned cluster collision')
        free_port(run['api_port'])
    require(not output(['docker', 'ps', '-aq', '--filter', 'label=technical-blog-run']), 'other lab runtime collision')
    require(not output(['docker', 'network', 'ls', '-q', '--filter', 'label=technical-blog-run']), 'other lab network collision')


def capture(config, resources):
    tools(config['hostname'])
    state = foreign()
    fresh(config, state)
    resource = dict(root=resources.filesystem('/'), docker=resources.filesystem('/var/lib/docker'),
                    available_memory=resources.available_memory())
    return state, resource
