"""Explicit immutable budget provenance. No inferred replacement baseline."""

import os
import pathlib
from public_common import CAP, read_json, require


def read_budget(path, hostname):
    value = read_json(path)
    require(value['schema'] == 'istio-budget-v1' and value['hostname'] == hostname, 'original budget host binding')
    require(type(value['cap_bytes']) is int and value['cap_bytes'] == CAP, 'unchanged cumulative 8 GiB cap')
    require(bool(value['provenance']) and bool(value['captured_at_gst']), 'original measurement provenance required')
    for group in ['root', 'docker']:
        entry = value[group]
        require(all(type(entry[key]) is int for key in ['device', 'baseline_used_bytes', 'latest_peak_used_bytes']), 'integer original budget fields')
        require(0 < entry['baseline_used_bytes'] <= entry['latest_peak_used_bytes'], 'original baseline and monotone carried peak')
        require(entry['latest_peak_used_bytes'] - entry['baseline_used_bytes'] <= CAP, 'carried peak already over cap')
    return value


def measure():
    result = {}
    for key, path in [('root', '/'), ('docker', '/var/lib/docker')]:
        state = os.statvfs(path)
        result[key] = dict(device=os.stat(path).st_dev, used=(state.f_blocks - state.f_bfree) * state.f_frsize)
    return result


def enforce_budget(value, measured):
    peaks = {}
    for key in ['root', 'docker']:
        entry = value[key]
        require(measured[key]['device'] == entry['device'], 'original ' + key + ' filesystem device')
        peak = max(entry['latest_peak_used_bytes'], measured[key]['used'])
        require(peak - entry['baseline_used_bytes'] <= CAP, 'original cumulative 8 GiB ' + key + ' budget')
        peaks[key] = peak
    return peaks


def install_enforcement(value, resources, initial_free, deadline):
    import time
    original = resources.enforce
    resources.lifecycle_deadline = deadline

    def enforce(sample, unused_free, bootstrap=False):
        require(time.monotonic() < deadline, 'original whole lifecycle deadline')
        original(sample, initial_free, bootstrap)
        enforce_budget(value, measure())
        require(time.monotonic() < deadline, "original deadline after budget observation")

    resources.enforce = enforce
    return original
